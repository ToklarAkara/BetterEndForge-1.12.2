package git.jbredwards.nether_api.api.structure;

import javax.annotation.*;
import java.util.function.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.world.gen.structure.*;

public interface INetherAPIStructureEntry
{
    @Nonnull
    String getCommandName();
    
    @Nonnull
    Function<INetherAPIChunkGenerator, MapGenStructure> getStructureFactory();
}
