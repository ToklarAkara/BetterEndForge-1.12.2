package git.jbredwards.nether_api.api.structure;

import net.minecraft.entity.*;
import javax.annotation.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import java.util.*;
import net.minecraft.world.biome.*;

public interface ISpawningStructure
{
    @Nonnull
    List<Biome.SpawnListEntry> getPossibleCreatures(@Nonnull final EnumCreatureType p0, @Nonnull final World p1, @Nonnull final BlockPos p2);
}
