package git.jbredwards.nether_api.api.structure;

import net.minecraft.world.gen.structure.*;
import net.minecraft.entity.*;
import net.minecraft.world.biome.*;
import javax.annotation.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import java.util.*;

public abstract class MapGenSpawningStructure extends MapGenStructure implements ISpawningStructure
{
    @Nonnull
    public final Map<EnumCreatureType, List<Biome.SpawnListEntry>> spawnableCreatures;
    
    public MapGenSpawningStructure() {
        this.spawnableCreatures = new EnumMap<EnumCreatureType, List<Biome.SpawnListEntry>>(EnumCreatureType.class);
    }
    
    public void addSpawnableCreature(@Nonnull final EnumCreatureType type, @Nonnull final Biome.SpawnListEntry... entries) {
        this.spawnableCreatures.computeIfAbsent(type, typeIn -> new LinkedList()).addAll(Arrays.asList(entries));
    }
    
    @Nonnull
    public List<Biome.SpawnListEntry> getPossibleCreatures(@Nonnull final EnumCreatureType type, @Nonnull final World world, @Nonnull final BlockPos pos) {
        if (!this.spawnableCreatures.isEmpty()) {
            final List<Biome.SpawnListEntry> creatures = this.spawnableCreatures.computeIfAbsent(type, typeIn -> new LinkedList());
            if (!creatures.isEmpty() && (this.isInsideStructure(pos) || this.isPositionInStructure(world, pos)) && this.isBlockBelowValidForSpawns(type, world, pos.down())) {
                return creatures;
            }
        }
        return Collections.emptyList();
    }
    
    protected abstract boolean isBlockBelowValidForSpawns(@Nonnull final EnumCreatureType p0, @Nonnull final World p1, @Nonnull final BlockPos p2);
}
