package git.jbredwards.nether_api.api.registry;

import javax.annotation.*;
import java.util.*;

public interface INetherAPIRegistryListener
{
    default void onAddedToRegistry(@Nonnull final INetherAPIRegistry registry, @Nonnull final OptionalInt newWeight) {
    }
    
    default void onRemovedFromRegistry(@Nonnull final INetherAPIRegistry registry, @Nonnull final OptionalInt oldWeight) {
    }
}
