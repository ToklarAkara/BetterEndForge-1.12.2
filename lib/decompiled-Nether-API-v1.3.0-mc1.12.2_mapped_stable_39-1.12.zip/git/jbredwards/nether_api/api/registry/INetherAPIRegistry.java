package git.jbredwards.nether_api.api.registry;

import javax.annotation.*;
import net.minecraftforge.common.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.structure.*;
import java.util.function.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.world.gen.structure.*;
import java.util.*;

public interface INetherAPIRegistry
{
    @Nonnull
    public static final List<INetherAPIRegistry> REGISTRIES = new LinkedList<INetherAPIRegistry>();
    
    List<BiomeManager.BiomeEntry> getBiomeEntries();
    
    void registerBiome(@Nonnull final Biome p0, final int p1);
    
    boolean removeBiome(@Nonnull final Biome p0);
    
    void clear();
    
    List<INetherAPIStructureEntry> getStructures();
    
    void registerStructure(@Nonnull final INetherAPIStructureEntry p0);
    
    void registerStructure(@Nonnull final String p0, @Nonnull final Function<INetherAPIChunkGenerator, MapGenStructure> p1);
    
    boolean removeStructure(@Nonnull final String p0);
    
    default boolean isEmpty() {
        return this.getBiomeEntries().isEmpty() && this.getStructures().isEmpty();
    }
}
