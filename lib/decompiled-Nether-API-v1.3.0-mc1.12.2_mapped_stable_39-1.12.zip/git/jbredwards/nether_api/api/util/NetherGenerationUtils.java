package git.jbredwards.nether_api.api.util;

import net.minecraft.world.*;
import javax.annotation.*;
import java.util.*;
import net.minecraft.world.chunk.*;
import net.minecraft.block.state.*;
import net.minecraft.init.*;
import git.jbredwards.nether_api.mod.*;
import git.jbredwards.nether_api.mod.common.compat.netherex.*;
import net.minecraft.block.material.*;

public final class NetherGenerationUtils
{
    public static void buildSurfaceAndSoulSandGravel(@Nonnull final World world, @Nonnull final Random rand, @Nonnull final ChunkPrimer primer, final int x, final int z, final double[] soulSandNoise, final double[] gravelNoise, final double[] depthBuffer, @Nonnull final IBlockState stateToFill, @Nonnull final IBlockState topBlockIn, @Nonnull final IBlockState fillerBlockIn, @Nonnull final IBlockState liquidBlockIn) {
        buildSurfaceAndSoulSandGravel(world, rand, primer, x, z, soulSandNoise, gravelNoise, depthBuffer, stateToFill, topBlockIn, fillerBlockIn, liquidBlockIn, Blocks.GRAVEL.getDefaultState(), Blocks.SOUL_SAND.getDefaultState());
    }
    
    public static void buildSurfaceAndSoulSandGravel(@Nonnull final World world, @Nonnull final Random rand, @Nonnull final ChunkPrimer primer, final int x, final int z, final double[] soulSandNoise, final double[] gravelNoise, final double[] depthBuffer, @Nonnull final IBlockState stateToFill, @Nonnull final IBlockState topBlockIn, @Nonnull final IBlockState fillerBlockIn, @Nonnull final IBlockState liquidBlockIn, @Nonnull final IBlockState gravelIn, @Nonnull final IBlockState sandIn) {
        final boolean soulSand = (!NetherAPI.isNetherExLoaded || NetherExHandler.doesSoulSandGenerate() || sandIn.getBlock() != Blocks.SOUL_SAND) && soulSandNoise[x << 4 | z] + rand.nextDouble() * 0.2 > 0.0;
        final boolean gravel = (!NetherAPI.isNetherExLoaded || NetherExHandler.doesGravelGenerate() || gravelIn.getBlock() != Blocks.GRAVEL) && gravelNoise[x << 4 | z] + rand.nextDouble() * 0.2 > 0.0;
        final int depth = (int)(depthBuffer[x << 4 | z] / 3.0 + 3.0 + rand.nextDouble() * 0.25);
        int depthRemaining = -1;
        final int seaLevel = world.getSeaLevel() + 1;
        IBlockState topBlock = topBlockIn;
        IBlockState fillerBlock = fillerBlockIn;
        IBlockState prevCheckState = Blocks.AIR.getDefaultState();
        for (int y = world.getActualHeight() - 1; y >= 0; --y) {
            final IBlockState checkState = primer.getBlockState(x, y, z);
            if (checkState.getMaterial() != Material.AIR) {
                if (checkState == stateToFill) {
                    if (depthRemaining == -1) {
                        if (depth <= 0) {
                            fillerBlock = fillerBlockIn;
                        }
                        else if (y >= seaLevel - 4 && y <= seaLevel + 1) {
                            topBlock = topBlockIn;
                            fillerBlock = fillerBlockIn;
                            if (gravel) {
                                topBlock = gravelIn;
                            }
                            if (soulSand) {
                                topBlock = sandIn;
                                fillerBlock = sandIn;
                            }
                        }
                        if (y < seaLevel && topBlock.getMaterial() == Material.AIR) {
                            topBlock = liquidBlockIn;
                        }
                        depthRemaining = depth;
                        if (prevCheckState.getMaterial() == Material.AIR) {
                            primer.setBlockState(x, y, z, topBlock);
                            prevCheckState = topBlock;
                        }
                        else {
                            primer.setBlockState(x, y, z, fillerBlock);
                            prevCheckState = fillerBlock;
                        }
                    }
                    else if (depthRemaining > 0) {
                        --depthRemaining;
                        primer.setBlockState(x, y, z, fillerBlock);
                        prevCheckState = fillerBlock;
                    }
                    else {
                        prevCheckState = checkState;
                    }
                }
                else {
                    prevCheckState = checkState;
                }
            }
            else {
                depthRemaining = -1;
                prevCheckState = checkState;
            }
        }
    }
}
