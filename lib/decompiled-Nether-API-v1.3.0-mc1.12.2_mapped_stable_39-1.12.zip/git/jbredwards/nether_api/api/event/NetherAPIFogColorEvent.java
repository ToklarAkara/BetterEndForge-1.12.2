package git.jbredwards.nether_api.api.event;

import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.world.biome.*;
import javax.annotation.*;
import net.minecraft.world.*;

@Cancelable
@SideOnly(Side.CLIENT)
public abstract class NetherAPIFogColorEvent extends Event
{
    @Nonnull
    public final Biome biome;
    @Nonnull
    public final World world;
    public final float celestialAngle;
    public final float partialTicks;
    public double fogR;
    public double fogG;
    public double fogB;
    
    protected NetherAPIFogColorEvent(@Nonnull final Biome biomeIn, @Nonnull final World worldIn, final float celestialAngleIn, final float partialTicksIn) {
        this.biome = biomeIn;
        this.world = worldIn;
        this.celestialAngle = celestialAngleIn;
        this.partialTicks = partialTicksIn;
    }
    
    @Cancelable
    @SideOnly(Side.CLIENT)
    public static class End extends NetherAPIFogColorEvent
    {
        public End(@Nonnull final Biome biomeIn, @Nonnull final World worldIn, final float celestialAngleIn, final float partialTicksIn) {
            super(biomeIn, worldIn, celestialAngleIn, partialTicksIn);
        }
    }
    
    @Cancelable
    @SideOnly(Side.CLIENT)
    public static class Nether extends NetherAPIFogColorEvent
    {
        public Nether(@Nonnull final Biome biomeIn, @Nonnull final World worldIn, final float celestialAngleIn, final float partialTicksIn) {
            super(biomeIn, worldIn, celestialAngleIn, partialTicksIn);
        }
    }
}
