package git.jbredwards.nether_api.api.event;

import net.minecraftforge.fml.common.eventhandler.*;
import git.jbredwards.nether_api.api.registry.*;
import javax.annotation.*;
import net.minecraft.world.*;
import com.google.common.base.*;

public abstract class NetherAPIRegistryEvent extends Event
{
    @Nonnull
    public final INetherAPIRegistry registry;
    @Nonnull
    public final World world;
    
    public NetherAPIRegistryEvent(@Nonnull final INetherAPIRegistry registryIn, @Nonnull final World worldIn) {
        Preconditions.checkState(registryIn.isEmpty());
        this.registry = registryIn;
        this.world = worldIn;
    }
    
    public static class End extends NetherAPIRegistryEvent
    {
        public End(@Nonnull final INetherAPIRegistry registryIn, @Nonnull final World worldIn) {
            super(registryIn, worldIn);
        }
    }
    
    public static class Nether extends NetherAPIRegistryEvent
    {
        public Nether(@Nonnull final INetherAPIRegistry registryIn, @Nonnull final World worldIn) {
            super(registryIn, worldIn);
        }
    }
}
