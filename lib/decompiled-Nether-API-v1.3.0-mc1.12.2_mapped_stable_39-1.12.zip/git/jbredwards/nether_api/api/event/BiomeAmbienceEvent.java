package git.jbredwards.nether_api.api.event;

import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.world.biome.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import javax.annotation.*;

@Cancelable
public class BiomeAmbienceEvent<T> extends GenericEvent<T>
{
    @Nonnull
    public final Biome biome;
    @Nonnull
    public final World world;
    @Nonnull
    public final BlockPos pos;
    @Nullable
    public T ambience;
    
    public BiomeAmbienceEvent(@Nonnull final Class<T> typeIn, @Nonnull final Biome biomeIn, @Nonnull final World worldIn, @Nonnull final BlockPos posIn) {
        super((Class)typeIn);
        this.biome = biomeIn;
        this.world = worldIn;
        this.pos = posIn;
    }
}
