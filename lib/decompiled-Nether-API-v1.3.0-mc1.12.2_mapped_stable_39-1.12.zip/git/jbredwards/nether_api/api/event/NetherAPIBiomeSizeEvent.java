package git.jbredwards.nether_api.api.event;

import net.minecraftforge.event.terraingen.*;
import net.minecraft.world.*;
import javax.annotation.*;

public abstract class NetherAPIBiomeSizeEvent extends WorldTypeEvent
{
    public int biomeSize;
    
    public NetherAPIBiomeSizeEvent(@Nonnull final WorldType worldTypeIn, final int biomeSizeIn) {
        super(worldTypeIn);
        this.biomeSize = biomeSizeIn;
    }
    
    public static class End extends NetherAPIBiomeSizeEvent
    {
        public End(@Nonnull final WorldType worldTypeIn, final int biomeSizeIn) {
            super(worldTypeIn, biomeSizeIn);
        }
    }
    
    public static class Nether extends NetherAPIBiomeSizeEvent
    {
        public Nether(@Nonnull final WorldType worldTypeIn, final int biomeSizeIn) {
            super(worldTypeIn, biomeSizeIn);
        }
    }
}
