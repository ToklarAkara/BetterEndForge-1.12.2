package git.jbredwards.nether_api.api.event;

import net.minecraftforge.event.terraingen.*;
import net.minecraft.world.gen.layer.*;
import javax.annotation.*;
import net.minecraft.world.*;

public abstract class NetherAPIInitBiomeGensEvent extends WorldTypeEvent
{
    @Nonnull
    public GenLayer[] biomeGenerators;
    public final long seed;
    
    public NetherAPIInitBiomeGensEvent(@Nonnull final WorldType worldTypeIn, final long seedIn, @Nonnull final GenLayer[] originalGeneratorsIn) {
        super(worldTypeIn);
        this.seed = seedIn;
        this.biomeGenerators = originalGeneratorsIn;
    }
    
    public static class End extends NetherAPIInitBiomeGensEvent
    {
        public End(@Nonnull final WorldType worldTypeIn, final long seedIn, @Nonnull final GenLayer[] originalGeneratorsIn) {
            super(worldTypeIn, seedIn, originalGeneratorsIn);
        }
    }
    
    public static class Nether extends NetherAPIInitBiomeGensEvent
    {
        public Nether(@Nonnull final WorldType worldTypeIn, final long seedIn, @Nonnull final GenLayer[] originalGeneratorsIn) {
            super(worldTypeIn, seedIn, originalGeneratorsIn);
        }
    }
}
