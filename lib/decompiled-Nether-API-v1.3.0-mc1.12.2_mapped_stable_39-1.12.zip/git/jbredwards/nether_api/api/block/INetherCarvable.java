package git.jbredwards.nether_api.api.block;

import net.minecraft.block.state.*;
import javax.annotation.*;
import net.minecraft.world.chunk.*;

public interface INetherCarvable
{
    boolean canNetherCarveThrough(@Nonnull final IBlockState p0, @Nonnull final ChunkPrimer p1, final int p2, final int p3, final int p4);
}
