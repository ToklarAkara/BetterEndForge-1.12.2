package git.jbredwards.nether_api.api.audio.impl;

import git.jbredwards.nether_api.api.audio.*;
import javax.annotation.*;
import net.minecraft.util.*;
import net.minecraft.init.*;

public class DarkSoundAmbience extends SoundAmbience implements IDarkSoundAmbience
{
    @Nonnull
    public static final DarkSoundAmbience DEFAULT_CAVE;
    protected final int lightSearchRadius;
    protected final double soundOffset;
    
    public DarkSoundAmbience(@Nonnull final SoundEvent soundEventIn, final double chancePerTickIn, final int lightSearchRadiusIn, final double soundOffsetIn) {
        super(soundEventIn, chancePerTickIn);
        this.lightSearchRadius = lightSearchRadiusIn;
        this.soundOffset = soundOffsetIn;
    }
    
    @Override
    public int getLightSearchRadius() {
        return this.lightSearchRadius;
    }
    
    @Override
    public double getSoundOffset() {
        return this.soundOffset;
    }
    
    static {
        DEFAULT_CAVE = new DarkSoundAmbience(SoundEvents.AMBIENT_CAVE, 1.6666666666666666E-4, 8, 2.0);
    }
}
