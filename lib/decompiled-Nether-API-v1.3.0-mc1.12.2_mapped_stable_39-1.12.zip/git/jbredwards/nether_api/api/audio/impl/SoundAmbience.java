package git.jbredwards.nether_api.api.audio.impl;

import git.jbredwards.nether_api.api.audio.*;
import net.minecraft.util.*;
import javax.annotation.*;

public class SoundAmbience implements ISoundAmbience
{
    @Nonnull
    protected final SoundEvent soundEvent;
    protected final double chancePerTick;
    
    public SoundAmbience(@Nonnull final SoundEvent soundEventIn, final double chancePerTickIn) {
        this.soundEvent = soundEventIn;
        this.chancePerTick = chancePerTickIn;
    }
    
    @Nonnull
    @Override
    public SoundEvent getSoundEvent() {
        return this.soundEvent;
    }
    
    @Override
    public double getChancePerTick() {
        return this.chancePerTick;
    }
}
