package git.jbredwards.nether_api.api.audio.impl;

import git.jbredwards.nether_api.api.audio.*;
import net.minecraft.client.audio.*;
import net.minecraftforge.fml.relauncher.*;
import javax.annotation.*;
import java.util.*;

public class VanillaMusicType implements IMusicType
{
    @Nonnull
    @SideOnly(Side.CLIENT)
    public final MusicTicker.MusicType musicType;
    
    @SideOnly(Side.CLIENT)
    public VanillaMusicType(@Nullable final MusicTicker.MusicType musicTypeIn) {
        this.musicType = Objects.requireNonNull(musicTypeIn, "MusicType cannot be null!");
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    @Override
    public MusicTicker.MusicType getMusicType() {
        return this.musicType;
    }
    
    @SideOnly(Side.CLIENT)
    @Override
    public boolean replacesCurrentMusic(@Nonnull final MusicTicker.MusicType currentlyPlaying) {
        return false;
    }
}
