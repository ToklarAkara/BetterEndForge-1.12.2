package git.jbredwards.nether_api.api.audio;

import net.minecraft.util.*;
import javax.annotation.*;

public interface ISoundAmbience
{
    @Nonnull
    SoundEvent getSoundEvent();
    
    double getChancePerTick();
}
