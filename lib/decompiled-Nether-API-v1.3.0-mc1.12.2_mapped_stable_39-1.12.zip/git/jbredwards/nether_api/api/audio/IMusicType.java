package git.jbredwards.nether_api.api.audio;

import net.minecraft.client.audio.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;

public interface IMusicType
{
    @Nonnull
    @SideOnly(Side.CLIENT)
    MusicTicker.MusicType getMusicType();
    
    @SideOnly(Side.CLIENT)
    boolean replacesCurrentMusic(@Nonnull final MusicTicker.MusicType p0);
}
