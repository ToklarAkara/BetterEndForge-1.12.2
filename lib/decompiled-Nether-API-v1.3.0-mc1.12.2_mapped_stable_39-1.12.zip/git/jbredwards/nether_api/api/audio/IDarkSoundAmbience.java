package git.jbredwards.nether_api.api.audio;

public interface IDarkSoundAmbience extends ISoundAmbience
{
    int getLightSearchRadius();
    
    double getSoundOffset();
}
