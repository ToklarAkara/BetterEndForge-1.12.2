package git.jbredwards.nether_api.api.world;

import net.minecraft.world.gen.*;
import net.minecraft.world.*;
import javax.annotation.*;
import java.util.*;
import net.minecraft.world.chunk.*;

public interface INetherAPIChunkGenerator extends IChunkGenerator
{
    @Nonnull
    World getWorld();
    
    @Nonnull
    Random getRand();
    
    boolean areStructuresEnabled();
    
    void populateWithVanilla(final int p0, final int p1);
    
    void setBlocksInPrimer(final int p0, final int p1, @Nonnull final ChunkPrimer p2);
}
