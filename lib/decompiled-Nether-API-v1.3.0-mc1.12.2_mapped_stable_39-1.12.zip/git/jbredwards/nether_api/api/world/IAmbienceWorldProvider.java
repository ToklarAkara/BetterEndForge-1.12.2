package git.jbredwards.nether_api.api.world;

import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.world.biome.*;
import java.util.function.*;
import git.jbredwards.nether_api.api.biome.*;
import javax.annotation.*;
import git.jbredwards.nether_api.api.event.*;
import net.minecraftforge.common.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.client.particle.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import git.jbredwards.nether_api.api.audio.*;
import git.jbredwards.nether_api.api.audio.impl.*;

public interface IAmbienceWorldProvider
{
    @Nullable
    default <T> T getAmbienceOrFallback(@Nonnull final World world, @Nonnull final BlockPos pos, @Nonnull final Biome biome, @Nonnull final Class<T> ambienceType, @Nonnull final BiFunction<IAmbienceWorldProvider, Biome, T> pFun, @Nonnull final Function<IAmbienceBiome, T> bFun, @Nullable final T fallback) {
        final BiomeAmbienceEvent<T> event = new BiomeAmbienceEvent<T>(ambienceType, biome, world, pos);
        if (MinecraftForge.EVENT_BUS.post((Event)event)) {
            return event.ambience;
        }
        return (world.provider instanceof IAmbienceWorldProvider) ? pFun.apply((IAmbienceWorldProvider)world.provider, biome) : ((biome instanceof IAmbienceBiome) ? bFun.apply((IAmbienceBiome)biome) : fallback);
    }
    
    @Nullable
    @SideOnly(Side.CLIENT)
    default IParticleFactory[] getAmbientParticles(@Nonnull final Biome biome) {
        return (biome instanceof IAmbienceBiome) ? ((IAmbienceBiome)biome).getAmbientParticles() : null;
    }
    
    @Nullable
    default SoundEvent getAmbientSound(@Nonnull final Biome biome) {
        return (biome instanceof IAmbienceBiome) ? ((IAmbienceBiome)biome).getAmbientSound() : null;
    }
    
    @Nullable
    default ISoundAmbience getRandomAmbientSound(@Nonnull final Biome biome) {
        return (biome instanceof IAmbienceBiome) ? ((IAmbienceBiome)biome).getRandomAmbientSound() : null;
    }
    
    @Nullable
    default IDarkSoundAmbience getDarkAmbienceSound(@Nonnull final Biome biome) {
        return (biome instanceof IAmbienceBiome) ? ((IAmbienceBiome)biome).getDarkAmbienceSound() : DarkSoundAmbience.DEFAULT_CAVE;
    }
}
