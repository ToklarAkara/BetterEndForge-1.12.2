package git.jbredwards.nether_api.api.biome;

import net.minecraftforge.common.*;
import java.util.*;
import javax.annotation.*;

public interface INetherAPIBiomeProvider
{
    @Nonnull
    default List<BiomeManager.BiomeEntry> getSubBiomes() {
        return Collections.emptyList();
    }
    
    @Nonnull
    default List<BiomeManager.BiomeEntry> getEdgeBiomes(final int neighborBiomeId) {
        return Collections.emptyList();
    }
}
