package git.jbredwards.nether_api.api.biome;

import git.jbredwards.nether_api.api.world.*;
import javax.annotation.*;
import net.minecraft.world.chunk.*;
import net.minecraft.world.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.api.audio.*;
import net.minecraft.client.audio.*;
import git.jbredwards.nether_api.api.audio.impl.*;

public interface IEndBiome
{
    void buildSurface(@Nonnull final INetherAPIChunkGenerator p0, final int p1, final int p2, @Nonnull final ChunkPrimer p3, final int p4, final int p5, final double p6);
    
    default void populate(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ) {
        chunkGenerator.populateWithVanilla(chunkX, chunkZ);
    }
    
    default boolean generateIslands(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, final float islandHeight) {
        return true;
    }
    
    default boolean generateChorusPlants(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, final float islandHeight) {
        return true;
    }
    
    default boolean generateEndCity(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, final int islandHeight) {
        return islandHeight >= 60;
    }
    
    @SideOnly(Side.CLIENT)
    default boolean hasExtraXZFog(@Nonnull final World world, final int x, final int z) {
        return false;
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    default Vec3d getFogColor(final float celestialAngle, final float partialTicks) {
        return new Vec3d(0.09411766, 0.07529412, 0.09411766);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    default IMusicType getMusicType() {
        return new VanillaMusicType(MusicTicker.MusicType.END);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    default IMusicType getBossMusicType() {
        return new VanillaMusicType(MusicTicker.MusicType.END_BOSS);
    }
}
