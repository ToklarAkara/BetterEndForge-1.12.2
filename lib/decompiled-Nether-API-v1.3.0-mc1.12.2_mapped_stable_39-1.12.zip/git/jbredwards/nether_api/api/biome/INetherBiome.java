package git.jbredwards.nether_api.api.biome;

import git.jbredwards.nether_api.api.world.*;
import javax.annotation.*;
import net.minecraft.world.chunk.*;
import net.minecraft.util.math.*;
import net.minecraftforge.fml.relauncher.*;
import git.jbredwards.nether_api.api.audio.*;
import net.minecraft.client.audio.*;
import git.jbredwards.nether_api.api.audio.impl.*;

public interface INetherBiome
{
    void buildSurface(@Nonnull final INetherAPIChunkGenerator p0, final int p1, final int p2, @Nonnull final ChunkPrimer p3, final int p4, final int p5, final double[] p6, final double[] p7, final double[] p8, final double p9);
    
    default void populate(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ) {
        chunkGenerator.populateWithVanilla(chunkX, chunkZ);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    default Vec3d getFogColor(final float celestialAngle, final float partialTicks) {
        return new Vec3d(0.2, 0.03, 0.03);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    default IMusicType getMusicType() {
        return new VanillaMusicType(MusicTicker.MusicType.NETHER);
    }
}
