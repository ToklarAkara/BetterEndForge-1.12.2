package git.jbredwards.nether_api.api.biome;

import net.minecraft.util.math.*;
import javax.annotation.*;

public interface ILavaTintBiome
{
    int getBiomeLavaColor(@Nonnull final BlockPos p0);
}
