package git.jbredwards.nether_api.api.biome;

public interface INoSpawnBiome
{
}
