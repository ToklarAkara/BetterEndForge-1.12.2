package git.jbredwards.nether_api.api.biome;

import net.minecraft.client.particle.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import git.jbredwards.nether_api.api.audio.*;
import git.jbredwards.nether_api.api.audio.impl.*;

public interface IAmbienceBiome
{
    @Nullable
    @SideOnly(Side.CLIENT)
    default IParticleFactory[] getAmbientParticles() {
        return null;
    }
    
    @Nullable
    default SoundEvent getAmbientSound() {
        return null;
    }
    
    @Nullable
    default ISoundAmbience getRandomAmbientSound() {
        return null;
    }
    
    @Nullable
    default IDarkSoundAmbience getDarkAmbienceSound() {
        return DarkSoundAmbience.DEFAULT_CAVE;
    }
}
