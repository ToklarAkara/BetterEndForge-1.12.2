package git.jbredwards.nether_api;

public class Tags
{
    private Tags() {
    }
}
