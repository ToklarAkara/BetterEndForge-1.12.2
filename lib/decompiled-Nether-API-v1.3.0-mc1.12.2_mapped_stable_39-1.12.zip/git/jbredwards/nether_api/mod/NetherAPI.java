package git.jbredwards.nether_api.mod;

import javax.annotation.*;
import git.jbredwards.nether_api.mod.common.compat.betternether.*;
import git.jbredwards.nether_api.mod.common.compat.journey_into_the_light.*;
import git.jbredwards.nether_api.mod.common.compat.nethercraft.*;
import git.jbredwards.nether_api.mod.common.network.*;
import net.minecraftforge.fml.common.network.simpleimpl.*;
import git.jbredwards.nether_api.mod.common.compat.stygian_end.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.world.*;
import net.minecraftforge.common.*;
import git.jbredwards.nether_api.mod.common.world.*;
import net.minecraftforge.fml.common.event.*;
import git.jbredwards.nether_api.api.registry.*;
import net.minecraftforge.fml.common.*;
import net.minecraftforge.fml.common.network.*;

@Mod(modid = "nether_api", name = "Nether API", version = "1.3.0", dependencies = "after:betternether@[0.1.8.6,);after:biomesoplenty@[7.0.1.2444,);after:journey@1.0.6.11;after:natura@1.12.2-4.3.2.69;after:nethercraft@1.0.2;after:netherex@2.2.5;after:stygian@[1.0.4,);")
public final class NetherAPI
{
    @Nonnull
    public static final String MODID = "nether_api";
    @Nonnull
    public static final String NAME = "Nether API";
    @Nonnull
    public static final String VERSION = "1.3.0";
    @Nonnull
    public static final String DEPENDENCIES = "after:betternether@[0.1.8.6,);after:biomesoplenty@[7.0.1.2444,);after:journey@1.0.6.11;after:natura@1.12.2-4.3.2.69;after:nethercraft@1.0.2;after:netherex@2.2.5;after:stygian@[1.0.4,);";
    public static final boolean isBetterNetherLoaded;
    public static final boolean isBiomesOPlentyLoaded;
    public static final boolean isJourneyIntoTheLightLoaded;
    public static final boolean isNethercraftLoaded;
    public static final boolean isNetherExLoaded;
    public static final boolean isStygianEndLoaded;
    @Nonnull
    public static final SimpleNetworkWrapper WRAPPER;
    public static int messageId;
    
    @Mod.EventHandler
    static void construct(@Nonnull final FMLConstructionEvent event) {
        if (NetherAPI.isBetterNetherLoaded) {
            MinecraftForge.EVENT_BUS.register((Object)BetterNetherHandler.class);
        }
        if (NetherAPI.isJourneyIntoTheLightLoaded) {
            MinecraftForge.EVENT_BUS.register((Object)JITLHandler.class);
        }
        if (NetherAPI.isNethercraftLoaded) {
            MinecraftForge.EVENT_BUS.register((Object)NethercraftHandler.class);
        }
    }
    
    @Mod.EventHandler
    static void preInit(@Nonnull final FMLPreInitializationEvent event) {
        NetherAPI.WRAPPER.registerMessage((IMessageHandler)MessageTeleportFX.Handler.INSTANCE, (Class)MessageTeleportFX.class, NetherAPI.messageId++, Side.CLIENT);
    }
    
    @Mod.EventHandler
    static void init(@Nonnull final FMLInitializationEvent event) {
        if (NetherAPI.isBetterNetherLoaded) {
            BetterNetherHandler.init();
        }
        if (NetherAPI.isJourneyIntoTheLightLoaded) {
            JITLHandler.init();
        }
        if (NetherAPI.isNethercraftLoaded) {
            NethercraftHandler.init();
        }
        if (NetherAPI.isStygianEndLoaded) {
            StygianEndHandler.init();
        }
    }
    
    @SideOnly(Side.CLIENT)
    @Mod.EventHandler
    static void initClient(@Nonnull final FMLInitializationEvent event) {
        if (NetherAPI.isStygianEndLoaded) {
            StygianEndHandler.initClient();
        }
    }
    
    @Mod.EventHandler
    static void serverAboutToStart(@Nonnull final FMLServerAboutToStartEvent event) {
        DimensionManager.getProviderType(DimensionType.NETHER.getId()).clazz = WorldProviderNether.class;
        DimensionManager.getProviderType(DimensionType.THE_END.getId()).clazz = WorldProviderTheEnd.class;
    }
    
    @Mod.EventHandler
    static void serverStopping(@Nonnull final FMLServerStoppingEvent event) {
        INetherAPIRegistry.REGISTRIES.forEach(INetherAPIRegistry::clear);
    }
    
    static {
        isBetterNetherLoaded = Loader.isModLoaded("betternether");
        isBiomesOPlentyLoaded = Loader.isModLoaded("biomesoplenty");
        isJourneyIntoTheLightLoaded = Loader.isModLoaded("journey");
        isNethercraftLoaded = Loader.isModLoaded("nethercraft");
        isNetherExLoaded = Loader.isModLoaded("netherex");
        isStygianEndLoaded = Loader.isModLoaded("stygian");
        WRAPPER = NetworkRegistry.INSTANCE.newSimpleChannel("nether_api");
        NetherAPI.messageId = 0;
    }
}
