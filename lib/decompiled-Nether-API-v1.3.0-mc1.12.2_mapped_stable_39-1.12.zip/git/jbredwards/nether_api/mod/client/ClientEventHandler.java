package git.jbredwards.nether_api.mod.client;

import net.minecraftforge.fml.common.*;
import net.minecraftforge.client.event.*;
import javax.annotation.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import net.minecraft.client.renderer.color.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.block.state.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.biome.*;

@Mod.EventBusSubscriber(modid = "nether_api", value = { Side.CLIENT })
final class ClientEventHandler
{
    @SideOnly(Side.CLIENT)
    @SubscribeEvent(priority = EventPriority.LOWEST)
    static void applyLavaColors(@Nonnull final ColorHandlerEvent.Block event) {
        final BiomeColorHelper.ColorResolver resolver = (biome, pos) -> (biome instanceof ILavaTintBiome) ? ((ILavaTintBiome)biome).getBiomeLavaColor(pos) : -1;
        final IBlockColor colorHandler = (state, world, pos, tintIndex) -> (world != null && pos != null) ? BiomeColorHelper.getColorAtPos(world, pos, resolver) : -1;
        event.getBlockColors().registerBlockColorHandler(colorHandler, new Block[] { (Block)Blocks.FLOWING_LAVA, (Block)Blocks.LAVA });
    }
}
