package git.jbredwards.nether_api.mod.client.audio;

import net.minecraft.client.audio.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.entity.*;
import javax.annotation.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;

@SideOnly(Side.CLIENT)
public class FadingSound extends MovingSound
{
    @Nonnull
    protected final EntityPlayerSP player;
    protected int fadeSpeed;
    protected int fadeInTicks;
    
    public FadingSound(@Nonnull final EntityPlayerSP playerIn, @Nonnull final SoundEvent soundIn, @Nonnull final SoundCategory category) {
        super(soundIn, category);
        this.player = playerIn;
        this.repeat = true;
    }
    
    public void update() {
        if (this.fadeInTicks < 0 || this.player.isDead || !this.player.isAddedToWorld()) {
            this.donePlaying = true;
            this.repeat = false;
        }
        this.xPosF = (float)this.player.posX;
        this.yPosF = (float)this.player.posY;
        this.zPosF = (float)this.player.posZ;
        this.fadeInTicks += this.fadeSpeed;
        this.volume = MathHelper.clamp(this.fadeInTicks / 40.0f, 0.0f, 1.0f);
    }
    
    public void fadeOut() {
        this.fadeInTicks = Math.min(this.fadeInTicks, 40);
        this.fadeSpeed = -1;
    }
    
    public void fadeIn() {
        this.fadeInTicks = Math.max(0, this.fadeInTicks);
        this.fadeSpeed = 1;
    }
}
