package git.jbredwards.nether_api.mod.client.audio;

import net.minecraftforge.fml.relauncher.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.world.biome.*;
import net.minecraft.client.*;
import javax.annotation.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.api.world.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.util.*;
import net.minecraft.client.audio.*;
import git.jbredwards.nether_api.api.audio.*;
import git.jbredwards.nether_api.api.audio.impl.*;
import net.minecraft.world.*;
import net.minecraftforge.fml.common.eventhandler.*;
import java.util.*;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = "nether_api", value = { Side.CLIENT })
final class BiomeAmbienceHandler
{
    @Nonnull
    static final Map<Biome, FadingSound> activeBiomeAmbientSounds;
    @Nonnull
    static final Minecraft mc;
    @Nullable
    static Biome currentBiome;
    static float caveAmbienceChance;
    
    @SubscribeEvent
    static void onPlayerTick(@Nonnull final TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && !BiomeAmbienceHandler.mc.isGamePaused()) {
            if (BiomeAmbienceHandler.mc.player != null && BiomeAmbienceHandler.mc.world != null) {
                final BlockPos pos = new BlockPos(ActiveRenderInfo.projectViewFromEntity((Entity)BiomeAmbienceHandler.mc.player, (double)BiomeAmbienceHandler.mc.getRenderPartialTicks()));
                final Biome biome = BiomeAmbienceHandler.mc.world.getBiome(pos);
                BiomeAmbienceHandler.activeBiomeAmbientSounds.values().removeIf(MovingSound::isDonePlaying);
                if (biome != BiomeAmbienceHandler.currentBiome) {
                    BiomeAmbienceHandler.currentBiome = biome;
                    BiomeAmbienceHandler.activeBiomeAmbientSounds.values().forEach(FadingSound::fadeOut);
                    final SoundEvent ambientSound = IAmbienceWorldProvider.getAmbienceOrFallback((World)BiomeAmbienceHandler.mc.world, pos, biome, SoundEvent.class, IAmbienceWorldProvider::getAmbientSound, IAmbienceBiome::getAmbientSound, null);
                    if (ambientSound != null) {
                        final SoundEvent soundIn;
                        BiomeAmbienceHandler.activeBiomeAmbientSounds.compute(biome, (biomeIn, sound) -> {
                            if (sound == null) {
                                sound = new FadingSound(BiomeAmbienceHandler.mc.player, soundIn, SoundCategory.AMBIENT);
                                BiomeAmbienceHandler.mc.getSoundHandler().playSound((ISound)sound);
                            }
                            sound.fadeIn();
                            return sound;
                        });
                    }
                }
                else if (BiomeAmbienceHandler.activeBiomeAmbientSounds.containsKey(biome) && !BiomeAmbienceHandler.mc.getSoundHandler().isSoundPlaying((ISound)BiomeAmbienceHandler.activeBiomeAmbientSounds.get(biome))) {
                    BiomeAmbienceHandler.currentBiome = null;
                    BiomeAmbienceHandler.activeBiomeAmbientSounds.clear();
                }
                final ISoundAmbience ambientSound2 = IAmbienceWorldProvider.getAmbienceOrFallback((World)BiomeAmbienceHandler.mc.world, pos, biome, ISoundAmbience.class, IAmbienceWorldProvider::getRandomAmbientSound, IAmbienceBiome::getRandomAmbientSound, null);
                if (ambientSound2 != null && BiomeAmbienceHandler.mc.player.getRNG().nextDouble() < ambientSound2.getChancePerTick()) {
                    final ISound sound2 = (ISound)new PositionedSoundRecord(ambientSound2.getSoundEvent().getSoundName(), SoundCategory.AMBIENT, 1.0f, 1.0f, false, 0, ISound.AttenuationType.NONE, 0.0f, 0.0f, 0.0f);
                    BiomeAmbienceHandler.mc.getSoundHandler().playSound(sound2);
                }
                final IDarkSoundAmbience caveSound = IAmbienceWorldProvider.getAmbienceOrFallback((World)BiomeAmbienceHandler.mc.world, pos, biome, IDarkSoundAmbience.class, IAmbienceWorldProvider::getDarkAmbienceSound, IAmbienceBiome::getDarkAmbienceSound, DarkSoundAmbience.DEFAULT_CAVE);
                if (caveSound != null) {
                    final int searchDiameter = caveSound.getLightSearchRadius() << 2;
                    final double searchX = BiomeAmbienceHandler.mc.player.posX + BiomeAmbienceHandler.mc.player.getRNG().nextInt(searchDiameter) - caveSound.getLightSearchRadius();
                    final double searchY = BiomeAmbienceHandler.mc.player.posY + BiomeAmbienceHandler.mc.player.getEyeHeight() + BiomeAmbienceHandler.mc.player.getRNG().nextInt(searchDiameter) - caveSound.getLightSearchRadius();
                    final double searchZ = BiomeAmbienceHandler.mc.player.posZ + BiomeAmbienceHandler.mc.player.getRNG().nextInt(searchDiameter) - caveSound.getLightSearchRadius();
                    final BlockPos searchPos = new BlockPos(searchX, searchY, searchZ);
                    final int skyLight = BiomeAmbienceHandler.mc.world.getLightFor(EnumSkyBlock.SKY, searchPos);
                    BiomeAmbienceHandler.caveAmbienceChance -= (float)((skyLight > 0) ? (skyLight * 0.001 / 15.0) : ((BiomeAmbienceHandler.mc.world.getLightFor(EnumSkyBlock.BLOCK, searchPos) - 1) * caveSound.getChancePerTick()));
                    if (BiomeAmbienceHandler.caveAmbienceChance < 1.0f) {
                        BiomeAmbienceHandler.caveAmbienceChance = Math.max(BiomeAmbienceHandler.caveAmbienceChance, 0.0f);
                    }
                    else {
                        final double offsetX = searchX - BiomeAmbienceHandler.mc.player.posX;
                        final double offsetY = searchY - BiomeAmbienceHandler.mc.player.posY - BiomeAmbienceHandler.mc.player.getEyeHeight();
                        final double offsetZ = searchZ - BiomeAmbienceHandler.mc.player.posZ;
                        final double offset = Math.sqrt(offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ);
                        final double soundOffset = offset * (offset + caveSound.getSoundOffset());
                        final float x = (float)(BiomeAmbienceHandler.mc.player.posX + offsetX / soundOffset);
                        final float y = (float)(BiomeAmbienceHandler.mc.player.posY + BiomeAmbienceHandler.mc.player.getEyeHeight() + offsetY / soundOffset);
                        final float z = (float)(BiomeAmbienceHandler.mc.player.posZ + offsetZ / soundOffset);
                        final ISound sound3 = (ISound)new PositionedSoundRecord(caveSound.getSoundEvent().getSoundName(), SoundCategory.AMBIENT, 1.0f, 1.0f, false, 0, ISound.AttenuationType.NONE, x, y, z);
                        BiomeAmbienceHandler.mc.getSoundHandler().playSound(sound3);
                        BiomeAmbienceHandler.caveAmbienceChance = 0.0f;
                    }
                }
            }
            else {
                BiomeAmbienceHandler.activeBiomeAmbientSounds.clear();
                BiomeAmbienceHandler.caveAmbienceChance = 0.0f;
                BiomeAmbienceHandler.currentBiome = null;
            }
        }
    }
    
    static {
        activeBiomeAmbientSounds = new HashMap<Biome, FadingSound>();
        mc = Minecraft.getMinecraft();
    }
}
