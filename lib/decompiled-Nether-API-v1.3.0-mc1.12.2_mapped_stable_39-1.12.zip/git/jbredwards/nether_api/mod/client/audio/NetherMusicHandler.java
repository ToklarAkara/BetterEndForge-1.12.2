package git.jbredwards.nether_api.mod.client.audio;

import net.minecraftforge.fml.relauncher.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.client.*;
import net.minecraft.client.audio.*;
import javax.annotation.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.audio.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.world.*;
import net.minecraftforge.fml.common.eventhandler.*;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = "nether_api", value = { Side.CLIENT })
public final class NetherMusicHandler
{
    @Nonnull
    static final Minecraft mc;
    @Nullable
    static MusicTicker.MusicType currentType;
    
    @Nullable
    public static MusicTicker.MusicType getMusicType() {
        if (NetherMusicHandler.currentType != null && !NetherMusicHandler.mc.getSoundHandler().isSoundPlaying(NetherMusicHandler.mc.getMusicTicker().currentMusic)) {
            NetherMusicHandler.currentType = null;
        }
        final Biome biome = NetherMusicHandler.mc.world.getBiome(new BlockPos(ActiveRenderInfo.projectViewFromEntity((Entity)NetherMusicHandler.mc.player, (double)NetherMusicHandler.mc.getRenderPartialTicks())));
        if (biome instanceof INetherBiome) {
            final IMusicType musicType = ((INetherBiome)biome).getMusicType();
            if (NetherMusicHandler.currentType == null) {
                NetherMusicHandler.currentType = musicType.getMusicType();
            }
            else if (musicType.replacesCurrentMusic(NetherMusicHandler.currentType)) {
                NetherMusicHandler.currentType = musicType.getMusicType();
            }
        }
        else if (NetherMusicHandler.currentType == null) {
            NetherMusicHandler.currentType = MusicTicker.MusicType.NETHER;
        }
        return NetherMusicHandler.currentType;
    }
    
    @SubscribeEvent
    static void resetCurrentMusicType(@Nonnull final TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.START && NetherMusicHandler.currentType != null && (NetherMusicHandler.mc.player == null || NetherMusicHandler.mc.player.dimension != DimensionType.NETHER.getId())) {
            NetherMusicHandler.currentType = null;
        }
    }
    
    static {
        mc = Minecraft.getMinecraft();
    }
}
