package git.jbredwards.nether_api.mod.client.audio;

import net.minecraftforge.fml.relauncher.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.client.*;
import net.minecraft.client.audio.*;
import javax.annotation.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.audio.*;
import net.minecraftforge.fml.common.gameevent.*;
import net.minecraft.world.*;
import net.minecraftforge.fml.common.eventhandler.*;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = "nether_api", value = { Side.CLIENT })
public final class TheEndMusicHandler
{
    @Nonnull
    static final Minecraft mc;
    @Nullable
    static MusicTicker.MusicType currentType;
    
    @Nullable
    public static MusicTicker.MusicType getMusicType() {
        if (TheEndMusicHandler.currentType != null && !TheEndMusicHandler.mc.getSoundHandler().isSoundPlaying(TheEndMusicHandler.mc.getMusicTicker().currentMusic)) {
            TheEndMusicHandler.currentType = null;
        }
        final Biome biome = TheEndMusicHandler.mc.world.getBiome(new BlockPos(ActiveRenderInfo.projectViewFromEntity((Entity)TheEndMusicHandler.mc.player, (double)TheEndMusicHandler.mc.getRenderPartialTicks())));
        if (biome instanceof IEndBiome) {
            final IMusicType musicType = TheEndMusicHandler.mc.ingameGUI.getBossOverlay().shouldPlayEndBossMusic() ? ((IEndBiome)biome).getBossMusicType() : ((IEndBiome)biome).getMusicType();
            if (TheEndMusicHandler.currentType == null) {
                TheEndMusicHandler.currentType = musicType.getMusicType();
            }
            else if (musicType.replacesCurrentMusic(TheEndMusicHandler.currentType)) {
                TheEndMusicHandler.currentType = musicType.getMusicType();
            }
        }
        else if (TheEndMusicHandler.currentType == null) {
            TheEndMusicHandler.currentType = (TheEndMusicHandler.mc.ingameGUI.getBossOverlay().shouldPlayEndBossMusic() ? MusicTicker.MusicType.END_BOSS : MusicTicker.MusicType.END);
        }
        return TheEndMusicHandler.currentType;
    }
    
    @SubscribeEvent
    static void resetCurrentMusicType(@Nonnull final TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.START && TheEndMusicHandler.currentType != null && (TheEndMusicHandler.mc.player == null || TheEndMusicHandler.mc.player.dimension != DimensionType.THE_END.getId())) {
            TheEndMusicHandler.currentType = null;
        }
    }
    
    static {
        mc = Minecraft.getMinecraft();
    }
}
