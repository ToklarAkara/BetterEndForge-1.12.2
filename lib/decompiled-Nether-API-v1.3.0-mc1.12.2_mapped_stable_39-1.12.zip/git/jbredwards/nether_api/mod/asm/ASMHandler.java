package git.jbredwards.nether_api.mod.asm;

import net.minecraftforge.fml.relauncher.*;
import javax.annotation.*;
import java.util.*;

@IFMLLoadingPlugin.SortingIndex(1001)
@IFMLLoadingPlugin.Name("Nether API Plugin")
@IFMLLoadingPlugin.MCVersion("1.12.2")
public final class ASMHandler implements IFMLLoadingPlugin
{
    @Nonnull
    public String[] getASMTransformerClass() {
        return new String[] { "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerBetterNetherConfigLoader", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerBetterNetherFirefly", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerBetterNetherGenerator", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerBiomesOPlentyBiomes", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerBiomesOPlentyDecorator", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerBiomesOPlentyFixes", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerJITLCascadingFix", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerJITLGenerator", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerJITLTowerFix", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerLibraryExCascadingFix", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerNethercraftEvents", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerNetherEXBiomes", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerNetherExOverride", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerStygianEndBiomes", "git.jbredwards.nether_api.mod.asm.transformers.modded.TransformerStygianEndCascadingFix", "git.jbredwards.nether_api.mod.asm.transformers.modded.height.Transformer_NetherHeight_BiomesOPlenty", "git.jbredwards.nether_api.mod.asm.transformers.modded.height.Transformer_NetherHeight_Natura", "git.jbredwards.nether_api.mod.asm.transformers.modded.height.Transformer_NetherHeight_NetherEx", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.Transformer_MC_10369", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerBiomeEndDecorator", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerBiomeHell", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerCommandLocate", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerDragonSpawnManager", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerEntityRenderer", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerMapGenCavesHell", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerMapGenEndCity", "git.jbredwards.nether_api.mod.asm.transformers.vanilla.TransformerWorldClient" };
    }
    
    @Nullable
    public String getModContainerClass() {
        return null;
    }
    
    @Nullable
    public String getSetupClass() {
        return null;
    }
    
    public void injectData(@Nonnull final Map<String, Object> data) {
    }
    
    @Nullable
    public String getAccessTransformerClass() {
        return null;
    }
}
