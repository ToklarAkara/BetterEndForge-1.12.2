package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.*;

public final class TransformerBiomesOPlentyBiomes implements IClassTransformer
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (transformedName.startsWith("biomesoplenty")) {
            final ClassReader reader = new ClassReader(basicClass);
            if ("biomesoplenty/common/biome/nether/BOPHellBiome".equals(reader.getSuperName())) {
                final ClassWriter writer = new ClassWriter(0);
                reader.accept((ClassVisitor)new ClassVisitor(327680, writer) {
                    public void visit(final int version, final int access, @Nonnull final String name, @Nonnull final String signature, @Nonnull final String superName, @Nonnull final String[] interfaces) {
                        super.visit(version, access, name, signature, "git/jbredwards/nether_api/mod/common/compat/biomesoplenty/AbstractNetherBOPBiome", interfaces);
                    }
                    
                    @Nonnull
                    public MethodVisitor visitMethod(final int access, @Nonnull final String name, @Nonnull final String desc, @Nonnull final String signature, @Nonnull final String[] exceptions) {
                        final MethodVisitor old = super.visitMethod(access, name, desc, signature, exceptions);
                        return "<init>".equals(name) ? new MethodVisitor(327680, old) {
                            public void visitMethodInsn(final int opcode, @Nonnull final String owner, @Nonnull final String name, @Nonnull final String desc, final boolean itf) {
                                super.visitMethodInsn(opcode, "biomesoplenty/common/biome/nether/BOPHellBiome".equals(owner) ? "git/jbredwards/nether_api/mod/common/compat/biomesoplenty/AbstractNetherBOPBiome" : owner, name, desc, itf);
                            }
                        } : old;
                    }
                }, 0);
                return writer.toByteArray();
            }
        }
        return basicClass;
    }
}
