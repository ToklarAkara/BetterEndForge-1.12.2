package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import net.minecraft.world.*;
import net.minecraft.world.gen.feature.*;
import java.util.*;

public final class TransformerDragonSpawnManager implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (transformedName.equals("net.minecraft.world.end.DragonSpawnManager$3")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0346:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "process" : "func_186079_a")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 187) {
                            if (((TypeInsnNode)insn).desc.equals("net/minecraft/world/gen/feature/WorldGenSpikes")) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(178, "git/jbredwards/nether_api/mod/common/world/WorldProviderTheEnd", "END_PILLAR", "Lnet/minecraft/world/gen/feature/WorldGenSpikes;"));
                                method.instructions.remove(insn.getNext());
                                method.instructions.remove(insn.getNext());
                                method.instructions.remove(insn);
                            }
                            else if (((TypeInsnNode)insn).desc.equals("java/util/Random")) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 11));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerDragonSpawnManager$Hooks", "createRandom", "(Lnet/minecraft/world/World;Lnet/minecraft/world/gen/feature/WorldGenSpikes$EndSpike;)Ljava/util/Random;", false));
                                method.instructions.remove(insn.getNext());
                                method.instructions.remove(insn.getNext());
                                method.instructions.remove(insn);
                                break Label_0346;
                            }
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        @Nonnull
        public static Random createRandom(@Nonnull final World world, @Nonnull final WorldGenSpikes.EndSpike spike) {
            final Random rand = new Random(world.getSeed());
            rand.setSeed((rand.nextLong() >> 3) * spike.getCenterX() + (rand.nextLong() >> 3) * spike.getCenterZ() ^ world.getSeed());
            return rand;
        }
    }
}
