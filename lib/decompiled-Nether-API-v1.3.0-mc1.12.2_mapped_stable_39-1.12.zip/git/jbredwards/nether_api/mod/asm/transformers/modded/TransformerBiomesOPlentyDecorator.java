package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;
import javax.annotation.*;
import net.minecraftforge.event.terraingen.*;
import git.jbredwards.nether_api.mod.common.config.*;
import net.minecraft.world.*;

public final class TransformerBiomesOPlentyDecorator implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(final String name, final String transformedName, final byte[] basicClass) {
        if (transformedName.equals("biomesoplenty.common.handler.decoration.DecorateBiomeEventHandler")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                    if (insn.getOpcode() == 185 && ((MethodInsnNode)insn).name.equals("contains")) {
                        method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/modded/TransformerBiomesOPlentyDecorator$Hooks", "orNonNether", "(ZLjava/lang/Object;)Z", false));
                        method.instructions.insert(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        public static boolean orNonNether(final boolean contains, @Nonnull final Object event) {
            if (!contains) {
                return false;
            }
            final World world = (event instanceof DecorateBiomeEvent) ? ((DecorateBiomeEvent)event).getWorld() : ((OreGenEvent)event).getWorld();
            return NetherAPIConfig.BOP.dependentBOPHellBiomes || world.provider.getDimension() != DimensionType.NETHER.getId();
        }
    }
}
