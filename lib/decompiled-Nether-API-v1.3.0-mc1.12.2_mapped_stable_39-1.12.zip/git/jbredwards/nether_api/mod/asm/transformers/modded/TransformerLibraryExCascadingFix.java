package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.*;
import java.util.*;
import org.objectweb.asm.tree.*;

public final class TransformerLibraryExCascadingFix implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (transformedName.equals("logictechcorp.libraryex.utility.StructureHelper")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                    if (insn.getOpcode() == 5 && insn.getNext().getOpcode() == 96) {
                        method.instructions.remove(insn.getNext());
                        method.instructions.remove(insn);
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
