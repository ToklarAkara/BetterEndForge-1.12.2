package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;
import net.minecraft.client.*;
import net.minecraft.world.*;
import net.minecraftforge.fml.relauncher.*;

public final class TransformerEntityRenderer implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("net.minecraft.client.renderer.EntityRenderer".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "updateRenderer" : "func_78464_a")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 177) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(12));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(181, "net/minecraft/client/renderer/EntityRenderer", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "fogColor1" : "field_78539_ae", "F"));
                            break;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        @SideOnly(Side.CLIENT)
        public static float getFogAlpha(@Nonnull final Minecraft mc) {
            return (mc.world.provider.getDimension() == DimensionType.THE_END.getId()) ? 0.01f : 1.0f;
        }
    }
}
