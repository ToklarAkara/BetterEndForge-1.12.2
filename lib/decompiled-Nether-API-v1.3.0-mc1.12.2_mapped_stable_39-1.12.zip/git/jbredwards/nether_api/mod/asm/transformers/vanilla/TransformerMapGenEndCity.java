package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;
import net.minecraft.world.gen.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.world.biome.*;

public final class TransformerMapGenEndCity implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("net.minecraft.world.gen.structure.MapGenEndCity".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 4);
        Label_0277:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "canSpawnStructureAtCoords" : "func_75047_a")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 60) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 0));
                            list.add((AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/world/gen/structure/MapGenEndCity", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "endProvider" : "field_186133_d", "Lnet/minecraft/world/gen/ChunkGeneratorEnd;"));
                            list.add((AbstractInsnNode)new VarInsnNode(21, 3));
                            list.add((AbstractInsnNode)new VarInsnNode(21, 4));
                            list.add((AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerMapGenEndCity$Hooks", "canBiomeGenerateEndCity", "(ILnet/minecraft/world/gen/ChunkGeneratorEnd;II)I", false));
                            method.instructions.insertBefore(insn, list);
                            break Label_0277;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(2);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        public static int canBiomeGenerateEndCity(final int islandHeight, @Nonnull final ChunkGeneratorEnd chunkGenerator, final int chunkX, final int chunkZ) {
            if (!(chunkGenerator instanceof INetherAPIChunkGenerator)) {
                throw new IllegalStateException("The end chunk generator has been replaced! Please report this to Nether API's issue tracker.");
            }
            final Biome biome = ((INetherAPIChunkGenerator)chunkGenerator).getWorld().getBiomeProvider().getBiome(new BlockPos((chunkX << 4) + 8, 0, (chunkZ << 4) + 8));
            return (biome instanceof IEndBiome) ? (((IEndBiome)biome).generateEndCity((INetherAPIChunkGenerator)chunkGenerator, chunkX, chunkZ, islandHeight) ? 60 : 0) : islandHeight;
        }
    }
}
