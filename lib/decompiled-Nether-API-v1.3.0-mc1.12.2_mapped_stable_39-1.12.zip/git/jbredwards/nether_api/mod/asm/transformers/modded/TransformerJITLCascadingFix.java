package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import java.util.*;

public final class TransformerJITLCascadingFix implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("net.journey.dimension.base.WorldGenJourney".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0356:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("generateNether")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 178 && ((FieldInsnNode)insn).name.equals("ANCIENT_BLOCK_GEN")) {
                            for (int i = 0; i < 2; ++i) {
                                AbstractInsnNode target = insn.getPrevious();
                                if (i == 1) {
                                    target = target.getPrevious().getPrevious();
                                }
                                do {
                                    if (target.getOpcode() == 54) {
                                        target = target.getPrevious();
                                    }
                                    else {
                                        final AbstractInsnNode prev = target.getPrevious();
                                        method.instructions.remove(target);
                                        target = prev;
                                    }
                                } while (target.getOpcode() != 25 || ((VarInsnNode)target).var != 2);
                                method.instructions.remove(target);
                            }
                        }
                        else if (insn.getOpcode() == 187 && ((TypeInsnNode)insn).desc.equals("net/journey/dimension/nether/gen/dungeon/WorldGenGhastTower")) {
                            for (int i = 0; i < 2; ++i) {
                                AbstractInsnNode target;
                                for (target = insn.getPrevious(); target.getOpcode() != 16 || ((IntInsnNode)target).operand == 16; target = target.getPrevious()) {}
                                ((IntInsnNode)target).operand = 10;
                            }
                            break Label_0356;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("net.slayer.api.worldgen.WorldGenAPI".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                    if (insn instanceof MethodInsnNode) {
                        if (FMLLaunchHandler.isDeobfuscatedEnvironment()) {
                            if ("setBlockState".equals(((MethodInsnNode)insn).name)) {
                                if ("(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z".equals(((MethodInsnNode)insn).desc)) {
                                    method.instructions.remove(insn.getPrevious());
                                }
                                else {
                                    ((MethodInsnNode)insn).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                                }
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 18));
                            }
                        }
                        else if ("func_175656_a".equals(((MethodInsnNode)insn).name)) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 18));
                            ((MethodInsnNode)insn).name = "func_180501_a";
                            ((MethodInsnNode)insn).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                        }
                        else if ("func_180501_a".equals(((MethodInsnNode)insn).name)) {
                            method.instructions.remove(insn.getPrevious());
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 18));
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
