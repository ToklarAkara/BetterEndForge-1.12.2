package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;

public final class TransformerNetherExOverride implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("logictechcorp.netherex.NetherEx".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            classNode.methods.removeIf(method -> method.name.equals("onFMLServerStarting"));
            for (final MethodNode method2 : classNode.methods) {
                if (method2.name.equals("onFMLInitialization") || method2.name.equals("onFMLPostInitialization")) {
                    for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                        if (insn.getOpcode() == 180 && ((FieldInsnNode)insn).name.equals("overrideNether")) {
                            method2.instructions.insert(insn, (AbstractInsnNode)new InsnNode(4));
                            method2.instructions.remove(insn.getPrevious());
                            method2.instructions.remove(insn.getPrevious());
                            method2.instructions.remove(insn);
                            break;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("logictechcorp.netherex.handler.BiomeTraitGenerationHandler".equals(transformedName) || "logictechcorp.netherex.world.biome.data.BiomeDataManagerNetherEx".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0482:
            for (final MethodNode method2 : classNode.methods) {
                if (method2.name.equals("generateBiomeTraits") || method2.name.equals("onWorldLoad")) {
                    for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                        if (insn.getOpcode() == 180 && ((FieldInsnNode)insn).name.equals("overrideNether")) {
                            method2.instructions.insert(insn, (AbstractInsnNode)new InsnNode(4));
                            method2.instructions.remove(insn.getPrevious());
                            method2.instructions.remove(insn.getPrevious());
                            method2.instructions.remove(insn);
                            break Label_0482;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
