package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import git.jbredwards.nether_api.mod.common.network.*;
import net.minecraft.entity.player.*;
import git.jbredwards.nether_api.mod.*;
import net.minecraftforge.fml.common.network.simpleimpl.*;
import net.minecraft.util.*;
import net.minecraft.block.*;
import net.minecraft.block.properties.*;

public final class Transformer_MC_10369 implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        switch (transformedName) {
            case "net.minecraft.block.BlockLiquid": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_0554:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "triggerMixEffects" : "func_180688_d")) {
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 8) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(24, 3));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(24, 5));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(24, 7));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "spawnFluidParticles", "(Lnet/minecraft/world/World;DDD)I", false));
                                method.instructions.remove(insn);
                                break Label_0554;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "net.minecraft.block.BlockPumpkin": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "trySpawnGolem" : "func_180673_e")) {
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_180501_a")) {
                                method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "destroyBlockWithFlags", "(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z", false));
                                method.instructions.remove(insn);
                            }
                            else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 128) {
                                ((IntInsnNode)insn).operand = 0;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "net.minecraft.block.BlockRedstoneTorch": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1065:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "updateTick" : "func_180650_b")) {
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 8) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 2));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 3));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "spawnTorchParticles", "(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)I", false));
                                method.instructions.remove(insn);
                                break Label_1065;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "net.minecraft.block.BlockSkull": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1336:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "checkWitherSpawn" : "func_180679_a")) {
                        int index = 0;
                        for (final AbstractInsnNode insn2 : method.instructions.toArray()) {
                            if (insn2.getOpcode() == 182 && ((MethodInsnNode)insn2).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_180501_a") && ++index == 2) {
                                method.instructions.insert(insn2, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "destroyBlockWithFlags", "(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z", false));
                                method.instructions.remove(insn2);
                            }
                            else if (insn2.getOpcode() == 16 && ((IntInsnNode)insn2).operand == 128) {
                                ((IntInsnNode)insn2).operand = 0;
                                break Label_1336;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "net.minecraft.entity.ai.EntityAIMate": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1658:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "spawnBaby" : "func_75388_i")) {
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 7) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/entity/ai/EntityAIMate", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "world" : "field_75394_a", "Lnet/minecraft/world/World;"));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/entity/ai/EntityAIMate", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "animal" : "field_75390_d", "Lnet/minecraft/entity/passive/EntityAnimal;"));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "spawnBabyParticles", "(Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;)I", false));
                                method.instructions.remove(insn);
                                break Label_1658;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "net.minecraft.entity.boss.EntityDragon": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1881:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "destroyBlocksInAABB" : "func_70972_a")) {
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "spawnParticle" : "func_175688_a")) {
                                method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "spawnDragonParticle", "(Lnet/minecraft/world/World;Lnet/minecraft/util/EnumParticleTypes;DDDDDD[I)V", false));
                                method.instructions.remove(insn);
                                break Label_1881;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "net.minecraft.entity.EntityLivingBase": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_2186:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "attemptTeleport" : "func_184595_k")) {
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 17 && insn.getNext().getOpcode() != 54 && ((IntInsnNode)insn).operand == 128) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(24, 7));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(24, 9));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(24, 11));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "spawnTeleportParticles", "(Lnet/minecraft/entity/Entity;DDD)I", false));
                                method.instructions.remove(insn);
                                break Label_2186;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "net.minecraft.item.ItemEnderEye": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 4);
            Label_2434:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "onItemUse" : "func_180614_a")) {
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 16) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 2));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 3));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/Transformer_MC_10369$Hooks", "spawnEyeParticles", "(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)I", false));
                                method.instructions.remove(insn);
                                break Label_2434;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(2);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "com.therandomlabs.randompatches.patch.ServerWorldEventHandlerPatch": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals("apply")) {
                        method.instructions.clear();
                        method.instructions.add((AbstractInsnNode)new InsnNode(4));
                        method.instructions.add((AbstractInsnNode)new InsnNode(172));
                        break;
                    }
                }
                final ClassWriter writer = new ClassWriter(1);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            default: {
                return basicClass;
            }
        }
    }
    
    public static final class Hooks
    {
        public static boolean BABY_FIX;
        public static boolean DRAGON_FIX;
        public static boolean EYE_FIX;
        public static boolean FLUID_FIX;
        public static boolean GOLEM_FIX;
        public static boolean TELEPORT_FIX;
        public static boolean TORCH_FIX;
        
        public static boolean destroyBlockWithFlags(@Nonnull final World world, @Nonnull final BlockPos pos, @Nonnull final IBlockState replaceState, final int flags) {
            if (Hooks.GOLEM_FIX) {
                world.playEvent(2001, pos, Block.getStateId(world.getBlockState(pos)));
            }
            return world.setBlockState(pos, replaceState, flags);
        }
        
        public static int spawnBabyParticles(@Nonnull final World world, @Nonnull final Entity animal) {
            if (Hooks.BABY_FIX) {
                world.setEntityState(animal, (byte)18);
            }
            return 0;
        }
        
        public static void spawnDragonParticle(@Nonnull final World world, @Nonnull final EnumParticleTypes particle, final double x, final double y, final double z, final double motionX, final double motionY, final double motionZ, final int[] args) {
            if (Hooks.DRAGON_FIX && world instanceof WorldServer) {
                ((WorldServer)world).spawnParticle(particle, true, x, y, z, 0, motionX, motionY, motionZ, 1.0, args);
            }
        }
        
        public static int spawnEyeParticles(@Nonnull final World world, @Nonnull final BlockPos pos) {
            if (Hooks.EYE_FIX && world instanceof WorldServer) {
                ((WorldServer)world).spawnParticle(EnumParticleTypes.SMOKE_NORMAL, pos.getX() + 0.5, pos.getY() + 0.8125, pos.getZ() + 0.5, 16, 0.1875, 0.0, 0.1875, 0.0, new int[0]);
            }
            return 0;
        }
        
        public static int spawnFluidParticles(@Nonnull final World world, final double x, final double y, final double z) {
            if (Hooks.FLUID_FIX && world instanceof WorldServer) {
                ((WorldServer)world).spawnParticle(EnumParticleTypes.SMOKE_LARGE, x + 0.5, y + 1.2, z + 0.5, 8, 0.25, 0.0, 0.25, 0.0, new int[0]);
            }
            return 0;
        }
        
        public static int spawnTeleportParticles(@Nonnull final Entity entity, final double prevX, final double prevY, final double prevZ) {
            if (Hooks.TELEPORT_FIX && entity.world instanceof WorldServer) {
                final MessageTeleportFX message = new MessageTeleportFX(entity, prevX, prevY, prevZ);
                if (entity instanceof EntityPlayerMP) {
                    NetherAPI.WRAPPER.sendTo((IMessage)message, (EntityPlayerMP)entity);
                }
                NetherAPI.WRAPPER.sendToAllTracking((IMessage)message, entity);
            }
            return 0;
        }
        
        public static int spawnTorchParticles(@Nonnull final World world, @Nonnull final BlockPos pos, @Nonnull final IBlockState state) {
            if (Hooks.TORCH_FIX && world instanceof WorldServer) {
                final EnumFacing facing = (EnumFacing)state.getValue((IProperty)BlockTorch.FACING);
                double offsetX = 0.5;
                double offsetY = 0.5625;
                double offsetZ = 0.5;
                if (facing.getAxis().isHorizontal()) {
                    offsetX -= 0.27 * facing.getXOffset();
                    offsetY += 0.22;
                    offsetZ -= 0.27 * facing.getZOffset();
                }
                ((WorldServer)world).spawnParticle(EnumParticleTypes.SMOKE_NORMAL, pos.getX() + offsetX, pos.getY() + offsetY, pos.getZ() + offsetZ, 5, 0.1, 0.1, 0.1, 0.0, new int[0]);
            }
            return 0;
        }
        
        static {
            Hooks.BABY_FIX = true;
            Hooks.DRAGON_FIX = true;
            Hooks.EYE_FIX = true;
            Hooks.FLUID_FIX = true;
            Hooks.GOLEM_FIX = true;
            Hooks.TELEPORT_FIX = true;
            Hooks.TORCH_FIX = true;
        }
    }
}
