package git.jbredwards.nether_api.mod.asm.transformers.modded.height;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import net.minecraft.world.biome.*;
import net.minecraft.init.*;
import java.util.*;

public final class Transformer_NetherHeight_Natura implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("com.progwml6.natura.world.worldgen.GlowshroomGenerator".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("generateNether")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals("hasType")) {
                            method.instructions.remove(insn.getPrevious());
                            method.instructions.insertBefore(insn.getPrevious(), (AbstractInsnNode)new FieldInsnNode(178, "git/jbredwards/nether_api/mod/asm/transformers/modded/height/Transformer_NetherHeight_Natura$Hooks", "VALID_GLOWSHROOM_BIOMES", "Ljava/util/Set;"));
                            method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(185, "java/util/Set", "contains", "(Ljava/lang/Object;)Z", true));
                            method.instructions.remove(insn);
                        }
                        else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 64) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 4));
                            list.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 8));
                            list.add((AbstractInsnNode)new InsnNode(122));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 7));
                            list.add((AbstractInsnNode)new InsnNode(120));
                            list.add((AbstractInsnNode)new InsnNode(96));
                            method.instructions.insert(insn, list);
                        }
                        else if (insn.getOpcode() == 17 && ((IntInsnNode)insn).operand == 128) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 4));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            method.instructions.remove(insn);
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("com.progwml6.natura.world.worldgen.NetherTreesGenerator".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_1249:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("generateNether")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals("hasType")) {
                            method.instructions.remove(insn.getPrevious());
                            method.instructions.insertBefore(insn.getPrevious(), (AbstractInsnNode)new FieldInsnNode(178, "git/jbredwards/nether_api/mod/asm/transformers/modded/height/Transformer_NetherHeight_Natura$Hooks", "VALID_TREE_BIOMES", "Ljava/util/Set;"));
                            method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(185, "java/util/Set", "contains", "(Ljava/lang/Object;)Z", true));
                            method.instructions.remove(insn);
                        }
                        else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 72) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 4));
                            list.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 8));
                            list.add((AbstractInsnNode)new InsnNode(122));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 7));
                            list.add((AbstractInsnNode)new InsnNode(120));
                            list.add((AbstractInsnNode)new InsnNode(96));
                            method.instructions.insert(insn, list);
                        }
                        else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 64) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 4));
                            list.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 8));
                            list.add((AbstractInsnNode)new InsnNode(122));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 7));
                            list.add((AbstractInsnNode)new InsnNode(120));
                            list.add((AbstractInsnNode)new InsnNode(96));
                            method.instructions.insert(insn, list);
                        }
                        else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 80) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 4));
                            list.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 8));
                            list.add((AbstractInsnNode)new InsnNode(122));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 7));
                            list.add((AbstractInsnNode)new InsnNode(120));
                            list.add((AbstractInsnNode)new InsnNode(96));
                            method.instructions.insert(insn, list);
                            break Label_1249;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("com.progwml6.natura.world.worldgen.VineGenerator".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_1698:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("generateNether")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals("hasType")) {
                            method.instructions.remove(insn.getPrevious());
                            method.instructions.insertBefore(insn.getPrevious(), (AbstractInsnNode)new FieldInsnNode(178, "git/jbredwards/nether_api/mod/asm/transformers/modded/height/Transformer_NetherHeight_Natura$Hooks", "VALID_VINE_BIOMES", "Ljava/util/Set;"));
                            method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(185, "java/util/Set", "contains", "(Ljava/lang/Object;)Z", true));
                            method.instructions.remove(insn);
                        }
                        else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 108) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 4));
                            list.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 8));
                            list.add((AbstractInsnNode)new InsnNode(122));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 7));
                            list.add((AbstractInsnNode)new InsnNode(120));
                            list.add((AbstractInsnNode)new InsnNode(96));
                            list.add((AbstractInsnNode)new InsnNode(8));
                            list.add((AbstractInsnNode)new InsnNode(96));
                            method.instructions.insert(insn, list);
                            break Label_1698;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        @Nonnull
        public static final Set<Biome> VALID_GLOWSHROOM_BIOMES;
        @Nonnull
        public static final Set<Biome> VALID_TREE_BIOMES;
        @Nonnull
        public static final Set<Biome> VALID_VINE_BIOMES;
        
        static {
            VALID_GLOWSHROOM_BIOMES = new HashSet<Biome>(Arrays.asList(Biomes.HELL));
            VALID_TREE_BIOMES = new HashSet<Biome>(Arrays.asList(Biomes.HELL));
            VALID_VINE_BIOMES = new HashSet<Biome>(Arrays.asList(Biomes.HELL));
        }
    }
}
