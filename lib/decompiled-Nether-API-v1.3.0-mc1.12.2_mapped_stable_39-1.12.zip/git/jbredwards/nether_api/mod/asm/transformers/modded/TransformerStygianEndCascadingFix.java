package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import git.jbredwards.nether_api.mod.common.config.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.*;
import java.util.*;
import org.objectweb.asm.tree.*;

public final class TransformerStygianEndCascadingFix implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        switch (transformedName) {
            case "fluke.stygian.world.feature.WorldGenEnderCanopy": {
                if (!NetherAPIConfig.StygianEnd.wideEnderCanopyGen) {
                    final ClassNode classNode = new ClassNode();
                    new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
                    for (final MethodNode method : classNode.methods) {
                        final String name2 = method.name;
                        switch (name2) {
                            case "isValidGenLocation": {
                                final int trunkRadiusVar = method.localVariables.stream().filter(var -> var.name.equals("trunkRadius")).mapToInt(var -> var.index).findFirst().orElse(-1);
                                final int canopyRadiusVar = method.localVariables.stream().filter(var -> var.name.equals("canopyRadius")).mapToInt(var -> var.index).findFirst().orElse(-1);
                                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                                    if (insn.getOpcode() == 16) {
                                        if (((IntInsnNode)insn).operand == -23) {
                                            ((IntInsnNode)insn).operand = -15;
                                        }
                                        else if (((IntInsnNode)insn).operand == 23) {
                                            ((IntInsnNode)insn).operand = 15;
                                        }
                                    }
                                    else if (insn.getOpcode() == 17 && ((IntInsnNode)insn).operand == 529) {
                                        ((IntInsnNode)insn).operand = 225;
                                    }
                                    else if (insn.getOpcode() == 54 && (((VarInsnNode)insn).var == trunkRadiusVar || ((VarInsnNode)insn).var == canopyRadiusVar)) {
                                        method.instructions.remove(insn.getPrevious());
                                        method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(2));
                                    }
                                }
                                continue;
                            }
                            case "buildCanopy": {
                                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                                    if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 8) {
                                        ((IntInsnNode)insn).operand = 7;
                                        break;
                                    }
                                }
                                continue;
                            }
                            case "buildTrunk": {
                                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                                    if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 18) {
                                        ((IntInsnNode)insn).operand = 15;
                                    }
                                }
                                continue;
                            }
                            case "buildBranches": {
                                final int branchLengthVar = method.localVariables.stream().filter(var -> var.name.equals("branchLength")).mapToInt(var -> var.index).findFirst().orElseThrow(() -> new UnsupportedOperationException("Unsupported version of Stygian End found, please try a different version!"));
                                for (final AbstractInsnNode insn2 : method.instructions.toArray()) {
                                    if (insn2.getOpcode() == 54 && ((VarInsnNode)insn2).var == branchLengthVar) {
                                        AbstractInsnNode nextBackInsn = insn2.getPrevious();
                                        int maxChanges = 2;
                                        while (maxChanges > 0) {
                                            final AbstractInsnNode backInsn = nextBackInsn;
                                            nextBackInsn = backInsn.getPrevious();
                                            if (backInsn instanceof IntInsnNode) {
                                                --maxChanges;
                                                switch (((IntInsnNode)backInsn).operand) {
                                                    case 8:
                                                    case 9:
                                                    case 14: {
                                                        method.instructions.insert(backInsn, (AbstractInsnNode)new InsnNode(7));
                                                        method.instructions.remove(backInsn);
                                                        continue;
                                                    }
                                                    case 7: {
                                                        method.instructions.insert(backInsn, (AbstractInsnNode)new InsnNode(6));
                                                        method.instructions.remove(backInsn);
                                                        continue;
                                                    }
                                                }
                                            }
                                            else {
                                                if (backInsn.getOpcode() != 8) {
                                                    continue;
                                                }
                                                --maxChanges;
                                                method.instructions.insert(backInsn, (AbstractInsnNode)new InsnNode(5));
                                                method.instructions.remove(backInsn);
                                            }
                                        }
                                    }
                                    else if (insn2.getOpcode() == 182 && ((MethodInsnNode)insn2).name.equals("isValidGenLocation")) {
                                        method.instructions.insert(insn2, (AbstractInsnNode)new InsnNode(4));
                                        method.instructions.remove(insn2.getPrevious());
                                        method.instructions.remove(insn2.getPrevious());
                                        method.instructions.remove(insn2.getPrevious());
                                        method.instructions.remove(insn2.getPrevious());
                                        method.instructions.remove(insn2);
                                    }
                                }
                                continue;
                            }
                            case "placeLogAt":
                            case "placeLeafAt": {
                                for (final AbstractInsnNode insn2 : method.instructions.toArray()) {
                                    if (insn2.getOpcode() == 182 && ((MethodInsnNode)insn2).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_175656_a")) {
                                        method.instructions.insertBefore(insn2, (AbstractInsnNode)new IntInsnNode(16, 18));
                                        if (!FMLLaunchHandler.isDeobfuscatedEnvironment()) {
                                            ((MethodInsnNode)insn2).name = "func_180501_a";
                                        }
                                        ((MethodInsnNode)insn2).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                                        break;
                                    }
                                }
                                continue;
                            }
                        }
                    }
                    final ClassWriter writer = new ClassWriter(1);
                    classNode.accept((ClassVisitor)writer);
                    return writer.toByteArray();
                }
                break;
            }
            case "fluke.stygian.world.feature.WorldGenEndVolcano": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1678:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "generate" : "func_180709_b")) {
                        int changes = 0;
                        for (final AbstractInsnNode insn3 : method.instructions.toArray()) {
                            if (insn3.getOpcode() == 16 && ((IntInsnNode)insn3).operand == 6) {
                                method.instructions.insert(insn3, (AbstractInsnNode)new InsnNode(8));
                                method.instructions.remove(insn3);
                            }
                            else if (insn3.getOpcode() == 182 && ((MethodInsnNode)insn3).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_175656_a")) {
                                method.instructions.insertBefore(insn3, (AbstractInsnNode)new IntInsnNode(16, 18));
                                if (!FMLLaunchHandler.isDeobfuscatedEnvironment()) {
                                    ((MethodInsnNode)insn3).name = "func_180501_a";
                                }
                                ((MethodInsnNode)insn3).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                                if (++changes == 2) {
                                    break Label_1678;
                                }
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "fluke.stygian.world.biomes.BiomeEndVolcano": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1966:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "decorate" : "func_180624_a")) {
                        for (final AbstractInsnNode insn4 : method.instructions.toArray()) {
                            if (insn4.getOpcode() == 1) {
                                method.instructions.insertBefore(insn4, (AbstractInsnNode)new FieldInsnNode(178, "fluke/stygian/world/biomes/BiomeEndVolcano", "END_OBSIDIAN", "Lnet/minecraft/block/state/IBlockState;"));
                                method.instructions.remove(insn4);
                            }
                            else if (insn4.getOpcode() == 182 && ((MethodInsnNode)insn4).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_175656_a")) {
                                method.instructions.insertBefore(insn4, (AbstractInsnNode)new IntInsnNode(16, 18));
                                if (!FMLLaunchHandler.isDeobfuscatedEnvironment()) {
                                    ((MethodInsnNode)insn4).name = "func_180501_a";
                                }
                                ((MethodInsnNode)insn4).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                                break Label_1966;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
        }
        return basicClass;
    }
}
