package git.jbredwards.nether_api.mod.asm.transformers.modded.height;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import net.minecraft.world.*;
import biomesoplenty.common.world.generator.*;
import java.util.*;
import net.minecraft.util.math.*;
import biomesoplenty.common.util.biome.*;

public final class Transformer_NetherHeight_BiomesOPlenty implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        switch (transformedName) {
            case "biomesoplenty.common.biome.nether.BOPHellBiome": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_0381:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "genTerrainBlocks" : "func_180622_a")) {
                        int changes = 0;
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 127) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(4));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(100));
                                method.instructions.remove(insn);
                                if (++changes == 2) {
                                    break Label_0381;
                                }
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(1);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "biomesoplenty.common.util.biome.GeneratorUtils$ScatterYMethod": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_0661:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals("getBlockPos")) {
                        int changes = 0;
                        for (final AbstractInsnNode insn : method.instructions.toArray()) {
                            if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 122) {
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 6));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(100));
                                method.instructions.remove(insn);
                                if (++changes == 2) {
                                    break Label_0661;
                                }
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(1);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "biomesoplenty.common.util.block.BlockQuery$BlockPosQueryAltitude": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_0872:
                for (final MethodNode method : classNode.methods) {
                    if (method.name.equals("matches")) {
                        for (final AbstractInsnNode insn2 : method.instructions.toArray()) {
                            if (insn2.getOpcode() == 180 && ((FieldInsnNode)insn2).name.equals("maxHeight")) {
                                method.instructions.insert(insn2, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/modded/height/Transformer_NetherHeight_BiomesOPlenty$Hooks", "maxHeight", "(ILnet/minecraft/world/World;)I", false));
                                method.instructions.insert(insn2, (AbstractInsnNode)new VarInsnNode(25, 1));
                                break Label_0872;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(1);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            default: {
                return basicClass;
            }
        }
    }
    
    public static final class Hooks
    {
        public static int maxHeight(final int maxHeight, @Nonnull final World world) {
            return world.provider.isNether() ? (maxHeight + (world.getActualHeight() >> 8 << 7)) : maxHeight;
        }
        
        public static void scatter(@Nonnull final GeneratorReplacing generator, @Nonnull final World world, @Nonnull final Random rand, @Nonnull final BlockPos pos, @Nonnull final GeneratorUtils.ScatterYMethod scatterYMethod) {
            int amount = 0;
            switch (scatterYMethod) {
                case NETHER_ROOF:
                case NETHER_SURFACE: {
                    amount = generator.getAmountToScatter(rand) << (world.getActualHeight() >> 8);
                    break;
                }
                default: {
                    amount = generator.getAmountToScatter(rand);
                    break;
                }
            }
            for (int i = 0; i < amount; ++i) {
                generator.generate(world, rand, generator.getScatterY(world, rand, pos.getX() + rand.nextInt(16) + 8, pos.getZ() + rand.nextInt(16) + 8));
            }
        }
    }
}
