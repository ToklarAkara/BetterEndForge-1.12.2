package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;
import net.minecraft.world.biome.*;
import net.minecraft.init.*;

public final class TransformerBiomeHell implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (transformedName.equals("net.minecraft.world.biome.BiomeHell")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0181:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("<init>")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 177) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerBiomeHell$Hooks", "setDefaultTopAndFillerBlocks", "(Lnet/minecraft/world/biome/BiomeHell;)V", false));
                            break Label_0181;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        public static void setDefaultTopAndFillerBlocks(@Nonnull final BiomeHell biome) {
            biome.topBlock = Blocks.NETHERRACK.getDefaultState();
            biome.fillerBlock = Blocks.NETHERRACK.getDefaultState();
        }
    }
}
