package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.util.*;
import net.minecraft.entity.*;

public final class TransformerNethercraftEvents implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        switch (transformedName) {
            case "com.legacy.nethercraft.entities.NetherEntityRegistry": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_0427:
                for (final MethodNode method2 : classNode.methods) {
                    if (method2.name.equals("register") && method2.desc.equals("(Ljava/lang/Class;III)V")) {
                        for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                            if (insn.getOpcode() == 178 && ((FieldInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "HELL" : "field_76778_j")) {
                                ((FieldInsnNode)insn).owner = "git/jbredwards/nether_api/mod/common/compat/nethercraft/NethercraftHandler";
                                ((FieldInsnNode)insn).name = "GLOWING_GROVE";
                                ((FieldInsnNode)insn).desc = "Lgit/jbredwards/nether_api/mod/common/compat/nethercraft/BiomeNethercraft;";
                                break Label_0427;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "com.legacy.nethercraft.world.NetherGenTree": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
                for (final MethodNode method2 : classNode.methods) {
                    if (method2.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "generate" : "func_180709_b")) {
                        for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                            if (insn.getOpcode() == 17 && ((IntInsnNode)insn).operand == 128) {
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                                method2.instructions.remove(insn);
                            }
                            else if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_175656_a")) {
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 18));
                                if (!FMLLaunchHandler.isDeobfuscatedEnvironment()) {
                                    ((MethodInsnNode)insn).name = "func_180501_a";
                                }
                                ((MethodInsnNode)insn).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "com.legacy.nethercraft.world.NetherWorldEvent": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
                classNode.methods.removeIf(method -> method.name.equals("onGenerateLand") || method.name.equals("onNetherDecorated"));
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "com.legacy.nethercraft.entities.projectile.EntitySlimeEggs": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1060:
                for (final MethodNode method2 : classNode.methods) {
                    if (method2.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "onImpact" : "func_70184_a")) {
                        for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                            if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals("nextInt")) {
                                ((JumpInsnNode)insn.getNext()).setOpcode(153);
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/modded/TransformerNethercraftEvents$Hooks", "canSpawnSlime", "(Ljava/util/Random;ILnet/minecraft/entity/Entity;)Z", false));
                                method2.instructions.remove(insn);
                                break Label_1060;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            case "com.legacy.nethercraft.entities.hostile.EntityBloodyZombie":
            case "com.legacy.nethercraft.entities.hostile.EntityDarkZombie":
            case "com.legacy.nethercraft.entities.hostile.EntityLavaSlime": {
                final ClassNode classNode = new ClassNode();
                new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            Label_1283:
                for (final MethodNode method2 : classNode.methods) {
                    if (method2.name.equals("<init>")) {
                        for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                            if (insn.getOpcode() == 177) {
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(4));
                                method2.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(181, "net/minecraft/entity/Entity", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "isImmuneToFire" : "field_70178_ae", "Z"));
                                break Label_1283;
                            }
                        }
                    }
                }
                final ClassWriter writer = new ClassWriter(0);
                classNode.accept((ClassVisitor)writer);
                return writer.toByteArray();
            }
            default: {
                return basicClass;
            }
        }
    }
    
    public static final class Hooks
    {
        public static boolean canSpawnSlime(@Nonnull final Random rand, final int chance, @Nonnull final Entity entity) {
            return !entity.world.isRemote && rand.nextInt(chance) == 0;
        }
    }
}
