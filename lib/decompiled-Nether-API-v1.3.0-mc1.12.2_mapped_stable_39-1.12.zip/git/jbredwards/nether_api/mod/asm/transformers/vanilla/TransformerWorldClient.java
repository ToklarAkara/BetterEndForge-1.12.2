package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import git.jbredwards.nether_api.api.world.*;
import git.jbredwards.nether_api.api.biome.*;
import java.util.*;
import net.minecraft.client.*;
import net.minecraft.client.particle.*;
import net.minecraftforge.fml.relauncher.*;

public final class TransformerWorldClient implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("net.minecraft.client.multiplayer.WorldClient".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            classNode.methods.removeIf(method -> method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "playMoodSoundAndCheckLight" : "func_147467_a"));
        Label_0270:
            for (final MethodNode method2 : classNode.methods) {
                if (method2.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "showBarrierParticles" : "func_184153_a")) {
                    for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                        if (insn.getOpcode() == 177) {
                            method2.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                            method2.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 5));
                            method2.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 7));
                            method2.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 11));
                            method2.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerWorldClient$Hooks", "spawnBiomeAmbientParticle", "(Lnet/minecraft/world/World;Ljava/util/Random;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V", false));
                            break Label_0270;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        @SideOnly(Side.CLIENT)
        public static void spawnBiomeAmbientParticle(@Nonnull final World world, @Nonnull final Random rand, @Nonnull final BlockPos pos, @Nonnull final IBlockState state) {
            if (!state.isFullCube()) {
                final IParticleFactory[] factories = IAmbienceWorldProvider.getAmbienceOrFallback(world, pos, world.getBiome(pos), IParticleFactory[].class, IAmbienceWorldProvider::getAmbientParticles, IAmbienceBiome::getAmbientParticles, (IParticleFactory[])null);
                if (factories == null || factories.length == 0) {
                    return;
                }
                if (factories.length != 1) {
                    Collections.shuffle(Arrays.asList(factories), rand);
                }
                for (final IParticleFactory factory : factories) {
                    final Particle particle = factory.createParticle(-1, world, pos.getX() + rand.nextDouble(), pos.getY() + rand.nextDouble(), pos.getZ() + rand.nextDouble(), 0.0, 0.0, 0.0, new int[0]);
                    if (particle != null) {
                        Minecraft.getMinecraft().effectRenderer.addEffect(particle);
                        return;
                    }
                }
            }
        }
    }
}
