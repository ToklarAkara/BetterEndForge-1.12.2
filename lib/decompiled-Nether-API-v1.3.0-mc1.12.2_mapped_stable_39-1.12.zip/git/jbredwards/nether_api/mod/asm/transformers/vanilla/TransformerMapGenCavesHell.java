package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.world.biome.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import net.minecraft.world.chunk.*;
import git.jbredwards.nether_api.api.block.*;
import net.minecraft.init.*;

public final class TransformerMapGenCavesHell implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("net.minecraft.world.gen.MapGenCavesHell".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 4);
        Label_1632:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "addTunnel" : "func_180704_a")) {
                    final LabelNode start = new LabelNode();
                    final LabelNode end = new LabelNode();
                    method.instructions.insertBefore(method.instructions.getFirst(), (AbstractInsnNode)start);
                    method.instructions.insert(method.instructions.getLast(), (AbstractInsnNode)end);
                    method.localVariables.add(new LocalVariableNode("biome", "Lnet/minecraft/world/biome/Biome;", (String)null, start, end, 62));
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 120) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/world/gen/MapGenBase", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "world" : "field_75039_c", "Lnet/minecraft/world/World;"));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 8));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(100));
                            method.instructions.remove(insn);
                        }
                        else if (insn.getOpcode() == 17 && ((IntInsnNode)insn).operand == 128) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/world/gen/MapGenBase", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "world" : "field_75039_c", "Lnet/minecraft/world/World;"));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            method.instructions.remove(insn);
                        }
                        else if (insn.getOpcode() == 178) {
                            if (((FieldInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "FLOWING_LAVA" : "field_150356_k")) {
                                ((JumpInsnNode)insn.getNext()).setOpcode(154);
                                method.instructions.remove(insn.getPrevious());
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(185, "net/minecraft/block/state/IBlockState", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getMaterial" : "func_185904_a", "()Lnet/minecraft/block/material/Material;", true));
                                method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/block/material/Material", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "isLiquid" : "func_76224_d", "()Z", false));
                                method.instructions.remove(insn);
                            }
                            else if (((FieldInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "LAVA" : "field_150353_l")) {
                                ((JumpInsnNode)insn.getNext()).setOpcode(153);
                                method.instructions.insert(insn, (AbstractInsnNode)new TypeInsnNode(193, "net/minecraftforge/fluids/IFluidBlock"));
                                method.instructions.remove(insn);
                            }
                        }
                        else if (insn.getOpcode() == 57 && ((VarInsnNode)insn).var == (FMLLaunchHandler.isDeobfuscatedEnvironment() ? 57 : 56)) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 0));
                            list.add((AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/world/gen/MapGenBase", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "world" : "field_75039_c", "Lnet/minecraft/world/World;"));
                            list.add((AbstractInsnNode)new VarInsnNode(21, 3));
                            list.add((AbstractInsnNode)new VarInsnNode(21, 4));
                            list.add((AbstractInsnNode)new VarInsnNode(21, 50));
                            list.add((AbstractInsnNode)new VarInsnNode(21, 53));
                            list.add((AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerMapGenCavesHell$Hooks", "getBiome", "(Lnet/minecraft/world/World;IIII)Lnet/minecraft/world/biome/Biome;", false));
                            list.add((AbstractInsnNode)new VarInsnNode(58, 62));
                            method.instructions.insert(insn, list);
                        }
                        else if (insn.getOpcode() == 25 && ((VarInsnNode)insn).var == (FMLLaunchHandler.isDeobfuscatedEnvironment() ? 59 : 61)) {
                            method.instructions.remove(insn.getNext());
                            method.instructions.remove(insn.getNext());
                            ((JumpInsnNode)insn.getNext()).setOpcode(159);
                            method.instructions.insert(insn, (AbstractInsnNode)new InsnNode(4));
                            method.instructions.insert(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerMapGenCavesHell$Hooks", "canCarveThrough", "(Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/chunk/ChunkPrimer;IIILnet/minecraft/world/biome/Biome;)Z", false));
                            method.instructions.insert(insn, (AbstractInsnNode)new VarInsnNode(25, 62));
                            method.instructions.insert(insn, (AbstractInsnNode)new VarInsnNode(21, 53));
                            method.instructions.insert(insn, (AbstractInsnNode)new VarInsnNode(21, FMLLaunchHandler.isDeobfuscatedEnvironment() ? 56 : 58));
                            method.instructions.insert(insn, (AbstractInsnNode)new VarInsnNode(21, 50));
                            method.instructions.insert(insn, (AbstractInsnNode)new VarInsnNode(25, 5));
                            break;
                        }
                    }
                }
                else {
                    if (!method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "recursiveGenerate" : "")) {
                        continue;
                    }
                    for (final AbstractInsnNode insn2 : method.instructions.toArray()) {
                        if (insn2.getOpcode() == 54 && ((VarInsnNode)insn2).var == 7 && insn2.getPrevious().getOpcode() == 182) {
                            method.instructions.insertBefore(insn2, (AbstractInsnNode)new VarInsnNode(25, 1));
                            method.instructions.insertBefore(insn2, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            method.instructions.insertBefore(insn2, (AbstractInsnNode)new IntInsnNode(16, 8));
                            method.instructions.insertBefore(insn2, (AbstractInsnNode)new InsnNode(122));
                            method.instructions.insertBefore(insn2, (AbstractInsnNode)new InsnNode(120));
                        }
                        else if (insn2.getOpcode() == 8) {
                            final InsnList list2 = new InsnList();
                            list2.add((AbstractInsnNode)new VarInsnNode(25, 1));
                            list2.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            list2.add((AbstractInsnNode)new IntInsnNode(16, 8));
                            list2.add((AbstractInsnNode)new InsnNode(122));
                            list2.add((AbstractInsnNode)new InsnNode(122));
                            method.instructions.insert(insn2, list2);
                        }
                        else if (insn2.getOpcode() == 17 && ((IntInsnNode)insn2).operand == 128) {
                            method.instructions.insertBefore(insn2, (AbstractInsnNode)new VarInsnNode(25, 1));
                            method.instructions.insertBefore(insn2, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            method.instructions.remove(insn2);
                            break Label_1632;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(3);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        @Nonnull
        public static Biome getBiome(@Nonnull final World world, final int chunkX, final int chunkZ, final int x, final int z) {
            return world.getBiome(new BlockPos((chunkX << 4) + x, 0, (chunkZ << 4) + z));
        }
        
        public static boolean canCarveThrough(@Nonnull final IBlockState state, @Nonnull final ChunkPrimer primer, final int x, final int y, final int z, @Nonnull final Biome biome) {
            if (state.getBlock() instanceof INetherCarvable) {
                return ((INetherCarvable)state.getBlock()).canNetherCarveThrough(state, primer, x, y, z);
            }
            return state.getBlock() == Blocks.NETHERRACK || state.getBlock() == Blocks.SOUL_SAND || state.getBlock() == Blocks.END_STONE || ((biome instanceof INetherCarvable) ? ((INetherCarvable)biome).canNetherCarveThrough(state, primer, x, y, z) : (biome.topBlock == state || biome.fillerBlock == state));
        }
    }
}
