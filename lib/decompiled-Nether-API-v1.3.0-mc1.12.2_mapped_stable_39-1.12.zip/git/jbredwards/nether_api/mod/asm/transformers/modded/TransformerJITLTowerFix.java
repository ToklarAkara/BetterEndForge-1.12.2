package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.*;
import java.util.*;
import org.objectweb.asm.tree.*;

public final class TransformerJITLTowerFix implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("net.journey.dimension.nether.gen.WorldGenNetherTower".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0257:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "generate" : "func_180709_b")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 18) {
                            if (((LdcInsnNode)insn).cst.equals("LavaSlime")) {
                                ((LdcInsnNode)insn).cst = "minecraft:magma_cube";
                            }
                            else if (((LdcInsnNode)insn).cst.equals("PigZombie")) {
                                ((LdcInsnNode)insn).cst = "minecraft:zombie_pigman";
                            }
                            else if (((LdcInsnNode)insn).cst.equals("lavasnake")) {
                                ((LdcInsnNode)insn).cst = "journey:lavasnake";
                            }
                            else if (((LdcInsnNode)insn).cst.equals("reaper")) {
                                ((LdcInsnNode)insn).cst = "journey:reaper";
                                break Label_0257;
                            }
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
