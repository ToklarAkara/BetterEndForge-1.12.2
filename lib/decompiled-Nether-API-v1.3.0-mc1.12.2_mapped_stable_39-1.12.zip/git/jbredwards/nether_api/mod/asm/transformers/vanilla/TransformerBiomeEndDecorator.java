package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;

public final class TransformerBiomeEndDecorator implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (transformedName.equals("net.minecraft.world.biome.BiomeEndDecorator")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final FieldNode field : classNode.fields) {
                if (field.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "spikeGen" : "field_76835_L")) {
                    final FieldNode fieldNode = field;
                    fieldNode.access &= 0xFFFFFFEF;
                    break;
                }
            }
        Label_0426:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "genDecorations" : "func_150513_a")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getPrevious() == method.instructions.getFirst()) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(178, "git/jbredwards/nether_api/mod/common/world/WorldProviderTheEnd", "END_PILLAR", "Lnet/minecraft/world/gen/feature/WorldGenSpikes;"));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new FieldInsnNode(181, "net/minecraft/world/biome/BiomeEndDecorator", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "spikeGen" : "field_76835_L", "Lnet/minecraft/world/gen/feature/WorldGenSpikes;"));
                        }
                        else if (insn.getOpcode() == 25 && ((VarInsnNode)insn).var == 3 && insn.getNext().getOpcode() != 182) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 2));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 8));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerDragonSpawnManager$Hooks", "createRandom", "(Lnet/minecraft/world/World;Lnet/minecraft/world/gen/feature/WorldGenSpikes$EndSpike;)Ljava/util/Random;", false));
                            method.instructions.remove(insn);
                            break Label_0426;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
