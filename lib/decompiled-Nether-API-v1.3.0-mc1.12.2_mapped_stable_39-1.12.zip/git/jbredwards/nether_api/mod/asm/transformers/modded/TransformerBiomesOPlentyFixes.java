package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;

public final class TransformerBiomesOPlentyFixes implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("biomesoplenty.common.handler.FogEventHandler".equals(transformedName) || "zmaster587.advancedRocketry.event.PlanetEventHandler".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("onGetFogColor") || method.name.equals("onRenderFog") || method.name.equals("fogColor")) {
                    final InsnList list = new InsnList();
                    list.add((AbstractInsnNode)new VarInsnNode(25, 1));
                    list.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraftforge/client/event/EntityViewRenderEvent", "getEntity", "()Lnet/minecraft/entity/Entity;", false));
                    list.add((AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/entity/Entity", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "world" : "field_70170_p", "Lnet/minecraft/world/World;"));
                    list.add((AbstractInsnNode)new FieldInsnNode(180, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "provider" : "field_73011_w", "Lnet/minecraft/world/WorldProvider;"));
                    list.add((AbstractInsnNode)new TypeInsnNode(193, "git/jbredwards/nether_api/mod/common/world/IFogWorldProvider"));
                    final LabelNode label = new LabelNode();
                    list.add((AbstractInsnNode)new JumpInsnNode(153, label));
                    list.add((AbstractInsnNode)new InsnNode(177));
                    list.add((AbstractInsnNode)label);
                    list.add((AbstractInsnNode)new FrameNode(3, 0, (Object[])null, 0, (Object[])null));
                    method.instructions.insert(method.instructions.getFirst(), list);
                }
            }
            final ClassWriter writer = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("biomesoplenty.common.world.generator.GeneratorBramble".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0793:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "generate" : "func_180709_b")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_175656_a")) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 18));
                            if (!FMLLaunchHandler.isDeobfuscatedEnvironment()) {
                                ((MethodInsnNode)insn).name = "func_180501_a";
                            }
                            ((MethodInsnNode)insn).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                        }
                        else if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "isAirBlock" : "func_175623_d")) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 3));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/modded/TransformerBiomesOPlentyFixes$Hooks", "canPlaceLeaves", "(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;)Z", false));
                            method.instructions.remove(insn);
                        }
                        else if (insn.getNext().getOpcode() == 58 && ((VarInsnNode)insn.getNext()).var == 5 && insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "offset" : "func_177972_a")) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 3));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/modded/TransformerBiomesOPlentyFixes$Hooks", "getClampedOffset", "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;", false));
                            method.instructions.remove(insn);
                            break Label_0793;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("biomesoplenty.common.world.generator.GeneratorHive".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("<init>")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 181 && ((FieldInsnNode)insn).name.equals("maxRadius")) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 8));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "java/lang/Math", "min", "(II)I", false));
                            break;
                        }
                    }
                }
                else {
                    if (!method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "generate" : "func_180709_b")) {
                        continue;
                    }
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_180501_a")) {
                            method.instructions.remove(insn.getPrevious());
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 18));
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        public static boolean canPlaceLeaves(@Nonnull final World world, @Nonnull final BlockPos genPos, @Nonnull final BlockPos origin) {
            final int minX = origin.getX() - 8 & 0xFFFFFFF0;
            if (genPos.getX() < minX || genPos.getX() > minX + 31) {
                return false;
            }
            final int minZ = origin.getZ() - 8 & 0xFFFFFFF0;
            return genPos.getZ() >= minZ && genPos.getZ() <= minZ + 31 && world.isAirBlock(genPos);
        }
        
        @Nonnull
        public static BlockPos getClampedOffset(@Nonnull final BlockPos genPos, @Nonnull final EnumFacing offset, @Nonnull final BlockPos origin) {
            final int x = genPos.getX() + offset.getXOffset();
            final int minX = origin.getX() - 8 & 0xFFFFFFF0;
            if (x < minX || x > minX + 31) {
                return genPos;
            }
            final int z = genPos.getZ() + offset.getZOffset();
            final int minZ = origin.getZ() - 8 & 0xFFFFFFF0;
            return (z < minZ || z > minZ + 31) ? genPos : genPos.offset(offset);
        }
    }
}
