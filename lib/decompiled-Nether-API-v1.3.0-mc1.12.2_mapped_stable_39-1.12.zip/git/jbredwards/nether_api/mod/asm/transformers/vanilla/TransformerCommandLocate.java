package git.jbredwards.nether_api.mod.asm.transformers.vanilla;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import git.jbredwards.nether_api.api.registry.*;
import git.jbredwards.nether_api.api.structure.*;
import java.util.function.*;
import java.util.*;

public final class TransformerCommandLocate implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (transformedName.equals("net.minecraft.command.CommandLocate")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0199:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getTabCompletions" : "func_184883_a")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getListOfStringsMatchingLastWord" : "func_71530_a")) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/vanilla/TransformerCommandLocate$Hooks", "getStructures", "([Ljava/lang/String;)[Ljava/lang/String;", false));
                            break Label_0199;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
    
    public static final class Hooks
    {
        @Nonnull
        public static String[] getStructures(@Nonnull final String[] vanillaStructures) {
            final List<String> structures = new LinkedList<String>(Arrays.asList(vanillaStructures));
            INetherAPIRegistry.REGISTRIES.forEach(registry -> registry.getStructures().stream().map((Function<? super Object, ?>)INetherAPIStructureEntry::getCommandName).forEach(structures::add));
            return structures.toArray(new String[0]);
        }
    }
}
