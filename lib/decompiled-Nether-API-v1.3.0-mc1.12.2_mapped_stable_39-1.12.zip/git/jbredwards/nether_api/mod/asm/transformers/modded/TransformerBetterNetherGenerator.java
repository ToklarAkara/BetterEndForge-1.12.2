package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.mod.common.compat.betternether.*;
import paulevs.betternether.biomes.*;
import net.minecraft.world.biome.*;
import java.util.*;

public final class TransformerBetterNetherGenerator implements IClassTransformer, Opcodes
{
    public static boolean isEnabled;
    
    static void legacyTransformer(@Nonnull final ClassNode classNode) {
        for (final MethodNode method : classNode.methods) {
            if (method.name.equals("generate")) {
                int biomeIndex = -1;
                int wzIndex = -1;
                for (final LocalVariableNode var : method.localVariables) {
                    if (var.name.equals("wz")) {
                        wzIndex = var.index;
                    }
                    else {
                        if (!var.name.equals("biome")) {
                            continue;
                        }
                        biomeIndex = var.index;
                    }
                }
                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                    if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals("makeBiomeArray")) {
                        if (((MethodInsnNode)insn).desc.startsWith("(L")) {
                            method.instructions.remove(insn.getPrevious());
                        }
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn);
                    }
                    else if (insn.getOpcode() == 54 && ((VarInsnNode)insn).var == wzIndex) {
                        final InsnList list = new InsnList();
                        list.add((AbstractInsnNode)new VarInsnNode(25, 0));
                        list.add((AbstractInsnNode)new VarInsnNode(21, wzIndex - 2));
                        list.add((AbstractInsnNode)new VarInsnNode(21, wzIndex));
                        list.add((AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/modded/TransformerBetterNetherGenerator$Hooks", "getNetherBiome", "(Lnet/minecraft/world/World;II)Lpaulevs/betternether/biomes/NetherBiome;", false));
                        list.add((AbstractInsnNode)new VarInsnNode(58, biomeIndex));
                        method.instructions.insert(insn, list);
                    }
                    else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 126) {
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(5));
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(100));
                        method.instructions.remove(insn);
                    }
                    else if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals("getBiomeLocal")) {
                        if (((MethodInsnNode)insn).desc.contains("World")) {
                            method.instructions.remove(insn.getPrevious());
                        }
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn.getNext());
                        method.instructions.remove(insn);
                        return;
                    }
                }
            }
        }
    }
    
    static void continuationTransformer(@Nonnull final ClassNode classNode) {
        for (final MethodNode method : classNode.methods) {
            if (method.name.equals("generate")) {
                for (final AbstractInsnNode insn : method.instructions.toArray()) {
                    if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals("makeBiomeArray")) {
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn.getPrevious());
                        method.instructions.remove(insn);
                    }
                    else if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 126) {
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 0));
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(5));
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(100));
                        method.instructions.remove(insn);
                    }
                    else if (insn.getOpcode() == 184 && ((MethodInsnNode)insn).name.equals("getBiomeFromCache")) {
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 10));
                        method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(184, "git/jbredwards/nether_api/mod/asm/transformers/modded/TransformerBetterNetherGenerator$Hooks", "getNetherBiome", "(II[[Lpaulevs/betternether/biomes/NetherBiome;Lnet/minecraft/world/World;Ljava/util/Random;Lnet/minecraft/util/math/BlockPos;)Lpaulevs/betternether/biomes/NetherBiome;", false));
                        method.instructions.remove(insn);
                        return;
                    }
                }
            }
        }
    }
    
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (TransformerBetterNetherGenerator.isEnabled && transformedName.equals("paulevs.betternether.world.BNWorldGenerator")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 4);
            boolean useLegacyTransformer = false;
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("smoothChunk")) {
                    useLegacyTransformer = true;
                    break;
                }
            }
            if (useLegacyTransformer) {
                legacyTransformer(classNode);
            }
            else {
                continuationTransformer(classNode);
            }
            final ClassWriter writer = new ClassWriter(3);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("paulevs.betternether.biomes".startsWith(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method2 : classNode.methods) {
                for (final AbstractInsnNode insn : method2.instructions.toArray()) {
                    if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "setBlockState" : "func_175656_a")) {
                        method2.instructions.insertBefore(insn, (AbstractInsnNode)new IntInsnNode(16, 18));
                        if (!FMLLaunchHandler.isDeobfuscatedEnvironment()) {
                            ((MethodInsnNode)insn).name = "func_180501_a";
                        }
                        ((MethodInsnNode)insn).desc = "(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z";
                    }
                }
            }
            final ClassWriter writer2 = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer2);
            return writer2.toByteArray();
        }
        return basicClass;
    }
    
    static {
        TransformerBetterNetherGenerator.isEnabled = true;
    }
    
    public static final class Hooks
    {
        @Nonnull
        public static NetherBiome getNetherBiome(@Nonnull final World world, final int wx, final int wz) {
            final Biome biome = world.getBiome(new BlockPos(wx, 0, wz));
            return (biome instanceof BiomeBetterNether) ? ((BiomeBetterNether)biome).netherBiome : BiomeRegister.BIOME_EMPTY_NETHER;
        }
        
        @Nonnull
        public static NetherBiome getNetherBiome(final int x, final int z, @Nonnull final NetherBiome[][] cache, @Nonnull final World world, @Nonnull final Random rand, @Nonnull final BlockPos pos) {
            return (cache[x][z] == null) ? (cache[x][z] = getNetherBiome(world, pos.getX(), pos.getZ())) : cache[x][z];
        }
    }
}
