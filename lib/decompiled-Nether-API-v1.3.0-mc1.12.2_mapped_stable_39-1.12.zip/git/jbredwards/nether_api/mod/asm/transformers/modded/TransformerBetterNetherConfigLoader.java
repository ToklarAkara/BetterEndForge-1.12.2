package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.*;
import java.util.*;
import org.objectweb.asm.tree.*;

public final class TransformerBetterNetherConfigLoader implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if (transformedName.equals("paulevs.betternether.config.ConfigLoader")) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0189:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("dispose")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 179 && (((FieldInsnNode)insn).name.equals("enabledBiomes") || ((FieldInsnNode)insn).name.equals("registerBiomes"))) {
                            method.instructions.remove(insn.getPrevious());
                            method.instructions.remove(insn);
                            break Label_0189;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
