package git.jbredwards.nether_api.mod.asm.transformers.modded;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import org.objectweb.asm.tree.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.commons.*;
import org.objectweb.asm.*;
import java.util.*;

public final class TransformerBetterNetherFirefly implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("paulevs.betternether.entities.EntityFirefly".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals(FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getCanSpawnHere" : "func_70601_bi")) {
                    method.instructions.clear();
                    if (method.tryCatchBlocks != null) {
                        method.tryCatchBlocks.clear();
                    }
                    if (method.localVariables != null) {
                        method.localVariables.clear();
                    }
                    if (method.visibleLocalVariableAnnotations != null) {
                        method.visibleLocalVariableAnnotations.clear();
                    }
                    if (method.invisibleLocalVariableAnnotations != null) {
                        method.invisibleLocalVariableAnnotations.clear();
                    }
                    final GeneratorAdapter generator = new GeneratorAdapter((MethodVisitor)method, method.access, method.name, method.desc);
                    generator.visitInsn(4);
                    generator.visitInsn(172);
                    break;
                }
            }
            final ClassWriter writer = new ClassWriter(0);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
