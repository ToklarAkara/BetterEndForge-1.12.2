package git.jbredwards.nether_api.mod.asm.transformers.modded.height;

import net.minecraft.launchwrapper.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.*;
import java.util.*;

public final class Transformer_NetherHeight_NetherEx implements IClassTransformer, Opcodes
{
    @Nonnull
    public byte[] transform(@Nonnull final String name, @Nonnull final String transformedName, @Nonnull final byte[] basicClass) {
        if ("logictechcorp.netherex.handler.BiomeTraitGenerationHandler".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 4);
        Label_0293:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("generateBiomeTraits")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 182 && ((MethodInsnNode)insn).name.equals("getMaximumGenerationHeight")) {
                            final InsnList list = new InsnList();
                            list.add((AbstractInsnNode)new VarInsnNode(25, 0));
                            list.add((AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 8));
                            list.add((AbstractInsnNode)new InsnNode(122));
                            list.add((AbstractInsnNode)new IntInsnNode(16, 7));
                            list.add((AbstractInsnNode)new InsnNode(120));
                            list.add((AbstractInsnNode)new InsnNode(96));
                            method.instructions.insert(insn, list);
                            break Label_0293;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(3);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        if ("logictechcorp.netherex.world.biome.data.BiomeDataNetherEx".equals(transformedName)) {
            final ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept((ClassVisitor)classNode, 0);
        Label_0567:
            for (final MethodNode method : classNode.methods) {
                if (method.name.equals("generateTerrain")) {
                    for (final AbstractInsnNode insn : method.instructions.toArray()) {
                        if (insn.getOpcode() == 16 && ((IntInsnNode)insn).operand == 127) {
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new VarInsnNode(25, 1));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new MethodInsnNode(182, "net/minecraft/world/World", FMLLaunchHandler.isDeobfuscatedEnvironment() ? "getActualHeight" : "func_72940_L", "()I", false));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(4));
                            method.instructions.insertBefore(insn, (AbstractInsnNode)new InsnNode(100));
                            method.instructions.remove(insn);
                            break Label_0567;
                        }
                    }
                }
            }
            final ClassWriter writer = new ClassWriter(1);
            classNode.accept((ClassVisitor)writer);
            return writer.toByteArray();
        }
        return basicClass;
    }
}
