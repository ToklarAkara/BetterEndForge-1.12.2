package git.jbredwards.nether_api.mod.common.registry;

import javax.annotation.*;
import net.minecraftforge.common.*;
import git.jbredwards.nether_api.api.structure.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.registry.*;
import java.util.function.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.world.gen.structure.*;
import java.util.*;

public class NetherAPIRegistry implements INetherAPIRegistry
{
    @Nonnull
    public static final NetherAPIRegistry NETHER;
    @Nonnull
    public static final NetherAPIRegistry THE_END;
    @Nonnull
    protected final List<BiomeManager.BiomeEntry> biomeEntries;
    @Nonnull
    protected final List<INetherAPIStructureEntry> structureEntries;
    
    public NetherAPIRegistry() {
        this.biomeEntries = new ArrayList<BiomeManager.BiomeEntry>();
        this.structureEntries = new ArrayList<INetherAPIStructureEntry>();
        NetherAPIRegistry.REGISTRIES.add(this);
    }
    
    @Nonnull
    @Override
    public List<BiomeManager.BiomeEntry> getBiomeEntries() {
        return Collections.unmodifiableList((List<? extends BiomeManager.BiomeEntry>)this.biomeEntries);
    }
    
    @Nonnull
    @Override
    public List<INetherAPIStructureEntry> getStructures() {
        return Collections.unmodifiableList((List<? extends INetherAPIStructureEntry>)this.structureEntries);
    }
    
    @Override
    public void registerBiome(@Nonnull final Biome biome, final int weight) {
        if (biome.delegate.name() == null) {
            throw new IllegalArgumentException("Biome must be registered!");
        }
        if (weight < 1) {
            return;
        }
        this.removeBiome(biome);
        this.biomeEntries.add(new BiomeManager.BiomeEntry(biome, weight));
        if (biome instanceof INetherAPIRegistryListener) {
            ((INetherAPIRegistryListener)biome).onAddedToRegistry(this, OptionalInt.of(weight));
        }
    }
    
    @Override
    public boolean removeBiome(@Nonnull final Biome biome) {
        return this.biomeEntries.removeIf(entry -> {
            if (entry.biome == biome) {
                if (biome instanceof INetherAPIRegistryListener) {
                    ((INetherAPIRegistryListener)biome).onRemovedFromRegistry(this, OptionalInt.of(entry.itemWeight));
                }
                return true;
            }
            else {
                return false;
            }
        });
    }
    
    @Override
    public void registerStructure(@Nonnull final INetherAPIStructureEntry structureEntry) {
        this.removeStructure(structureEntry.getCommandName());
        this.structureEntries.add(structureEntry);
        if (structureEntry instanceof INetherAPIRegistryListener) {
            ((INetherAPIRegistryListener)structureEntry).onAddedToRegistry(this, OptionalInt.empty());
        }
    }
    
    @Override
    public void registerStructure(@Nonnull final String commandName, @Nonnull final Function<INetherAPIChunkGenerator, MapGenStructure> structureFactory) {
        this.registerStructure(new NetherAPIStructureEntry(commandName, structureFactory));
    }
    
    @Override
    public boolean removeStructure(@Nonnull final String commandName) {
        return this.structureEntries.removeIf(entry -> {
            if (((INetherAPIStructureEntry)entry).getCommandName().equals(commandName)) {
                if (entry instanceof INetherAPIRegistryListener) {
                    entry.onRemovedFromRegistry(this, OptionalInt.empty());
                }
                return true;
            }
            else {
                return false;
            }
        });
    }
    
    @Override
    public void clear() {
        final Iterator<BiomeManager.BiomeEntry> it = this.biomeEntries.iterator();
        while (it.hasNext()) {
            final BiomeManager.BiomeEntry entry = it.next();
            if (entry.biome instanceof INetherAPIRegistryListener) {
                ((INetherAPIRegistryListener)entry.biome).onRemovedFromRegistry(this, OptionalInt.of(entry.itemWeight));
            }
            it.remove();
        }
        final Iterator<INetherAPIStructureEntry> it2 = this.structureEntries.iterator();
        while (it2.hasNext()) {
            final INetherAPIStructureEntry entry2 = it2.next();
            if (entry2 instanceof INetherAPIRegistryListener) {
                ((INetherAPIRegistryListener)entry2).onRemovedFromRegistry(this, OptionalInt.empty());
            }
            it2.remove();
        }
    }
    
    static {
        NETHER = new NetherAPIRegistry();
        THE_END = new NetherAPIRegistry();
    }
}
