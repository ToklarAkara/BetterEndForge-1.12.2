package git.jbredwards.nether_api.mod.common.registry;

import git.jbredwards.nether_api.api.structure.*;
import javax.annotation.*;
import java.util.function.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.world.gen.structure.*;

public class NetherAPIStructureEntry implements INetherAPIStructureEntry
{
    @Nonnull
    public final String commandName;
    @Nonnull
    public final Function<INetherAPIChunkGenerator, MapGenStructure> factory;
    
    public NetherAPIStructureEntry(@Nonnull final String commandNameIn, @Nonnull final Function<INetherAPIChunkGenerator, MapGenStructure> factoryIn) {
        this.commandName = commandNameIn;
        this.factory = factoryIn;
    }
    
    @Nonnull
    @Override
    public String getCommandName() {
        return this.commandName;
    }
    
    @Nonnull
    @Override
    public Function<INetherAPIChunkGenerator, MapGenStructure> getStructureFactory() {
        return this.factory;
    }
}
