package git.jbredwards.nether_api.mod.common.network;

import net.minecraft.entity.*;
import io.netty.buffer.*;
import net.minecraftforge.fml.common.network.simpleimpl.*;
import javax.annotation.*;
import net.minecraft.client.*;
import net.minecraft.util.*;
import net.minecraftforge.fml.relauncher.*;

public class MessageTeleportFX implements IMessage
{
    public double x;
    public double y;
    public double z;
    public double prevX;
    public double prevY;
    public double prevZ;
    public float width;
    public float height;
    public boolean valid;
    
    public MessageTeleportFX() {
    }
    
    public MessageTeleportFX(@Nonnull final Entity entityIn, final double prevXIn, final double prevYIn, final double prevZIn) {
        this.valid = true;
        this.x = entityIn.posX;
        this.y = entityIn.posY;
        this.z = entityIn.posZ;
        this.prevX = prevXIn;
        this.prevY = prevYIn;
        this.prevZ = prevZIn;
        this.width = entityIn.width;
        this.height = entityIn.height;
    }
    
    public void fromBytes(@Nonnull final ByteBuf buf) {
        final boolean boolean1 = buf.readBoolean();
        this.valid = boolean1;
        if (boolean1) {
            this.x = buf.readDouble();
            this.y = buf.readDouble();
            this.z = buf.readDouble();
            this.prevX = buf.readDouble();
            this.prevY = buf.readDouble();
            this.prevZ = buf.readDouble();
            this.width = buf.readFloat();
            this.height = buf.readFloat();
        }
    }
    
    public void toBytes(@Nonnull final ByteBuf buf) {
        buf.writeBoolean(this.valid);
        if (this.valid) {
            buf.writeDouble(this.x).writeDouble(this.y).writeDouble(this.z).writeDouble(this.prevX).writeDouble(this.prevY).writeDouble(this.prevZ).writeFloat(this.width).writeFloat(this.height);
        }
    }
    
    public enum Handler implements IMessageHandler<MessageTeleportFX, IMessage>
    {
        INSTANCE;
        
        @Nullable
        public IMessage onMessage(@Nonnull final MessageTeleportFX msg, @Nonnull final MessageContext ctx) {
            if (msg.valid && ctx.side.isClient()) {
                onMessageClient(msg);
            }
            return null;
        }
        
        @SideOnly(Side.CLIENT)
        static void onMessageClient(@Nonnull final MessageTeleportFX msg) {
            final double scale;
            double slide;
            Minecraft.getMinecraft().addScheduledTask(() -> {
                scale = 0.007874015748031496;
                for (slide = 0.0; slide <= 1.0; slide += 0.007874015748031496) {
                    Minecraft.getMinecraft().renderGlobal.spawnParticle(EnumParticleTypes.PORTAL, msg.prevX + (msg.x - msg.prevX) * slide + (Math.random() - 0.5) * msg.width * 2.0, msg.prevY + (msg.y - msg.prevY) * slide + Math.random() * msg.height, msg.prevZ + (msg.z - msg.prevZ) * slide + (Math.random() - 0.5) * msg.width * 2.0, (Math.random() - 0.5) * 0.2, (Math.random() - 0.5) * 0.2, (Math.random() - 0.5) * 0.2, new int[0]);
                }
            });
        }
    }
}
