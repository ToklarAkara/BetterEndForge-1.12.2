package git.jbredwards.nether_api.mod.common.world;

import net.minecraft.world.*;
import git.jbredwards.nether_api.api.world.*;
import git.jbredwards.nether_api.mod.common.config.*;
import git.jbredwards.nether_api.mod.common.world.biome.*;
import net.minecraft.world.gen.*;
import git.jbredwards.nether_api.mod.common.world.gen.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.audio.*;
import javax.annotation.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.api.event.*;
import net.minecraftforge.fml.relauncher.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.client.audio.*;
import git.jbredwards.nether_api.mod.client.audio.*;
import git.jbredwards.nether_api.mod.*;
import git.jbredwards.nether_api.mod.common.compat.netherex.*;

public class WorldProviderNether extends WorldProviderHell implements IAmbienceWorldProvider, IFogWorldProvider
{
    public static boolean FORCE_NETHER_FOG;
    
    public int getActualHeight() {
        return NetherAPIConfig.tallNether ? 256 : super.getActualHeight();
    }
    
    public void init() {
        this.biomeProvider = new BiomeProviderNether(this.world);
        this.doesWaterVaporize = true;
        this.nether = true;
    }
    
    @Nonnull
    public IChunkGenerator createChunkGenerator() {
        return (IChunkGenerator)new ChunkGeneratorNether(this.world, this.world.getWorldInfo().isMapFeaturesEnabled(), this.world.getSeed());
    }
    
    @Nullable
    public IDarkSoundAmbience getDarkAmbienceSound(@Nonnull final Biome biome) {
        return (biome instanceof IAmbienceBiome) ? ((IAmbienceBiome)biome).getDarkAmbienceSound() : null;
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    public Vec3d getFogColor(final float celestialAngle, final float partialTicks) {
        return this.getFogColor(this.world, celestialAngle, partialTicks, 0.2, 0.03, 0.03, NetherAPIFogColorEvent.Nether::new);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    public Vec3d getDefaultFogColor(@Nonnull final Biome biome, final float celestialAngle, final float partialTicks, final double defaultR, final double defaultG, final double defaultB) {
        return (biome instanceof INetherBiome) ? ((INetherBiome)biome).getFogColor(celestialAngle, partialTicks) : new Vec3d(defaultR, defaultG, defaultB);
    }
    
    @Nullable
    @SideOnly(Side.CLIENT)
    public float[] calcSunriseSunsetColors(final float celestialAngle, final float partialTicks) {
        return null;
    }
    
    @Nullable
    @SideOnly(Side.CLIENT)
    public MusicTicker.MusicType getMusicType() {
        return NetherMusicHandler.getMusicType();
    }
    
    @SideOnly(Side.CLIENT)
    public boolean doesXZShowFog(final int x, final int z) {
        return WorldProviderNether.FORCE_NETHER_FOG || !NetherAPI.isNetherExLoaded || NetherExHandler.doesXZShowFog();
    }
    
    static {
        WorldProviderNether.FORCE_NETHER_FOG = false;
    }
}
