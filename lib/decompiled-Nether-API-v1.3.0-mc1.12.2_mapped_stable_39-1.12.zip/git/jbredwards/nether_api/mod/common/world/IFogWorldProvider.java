package git.jbredwards.nether_api.mod.common.world;

import net.minecraft.world.biome.*;
import javax.annotation.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.world.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraftforge.common.*;
import net.minecraftforge.fml.common.eventhandler.*;
import git.jbredwards.nether_api.api.event.*;

public interface IFogWorldProvider
{
    @SideOnly(Side.CLIENT)
    Vec3d getDefaultFogColor(@Nonnull final Biome p0, final float p1, final float p2, final double p3, final double p4, final double p5);
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    default Vec3d getFogColor(@Nonnull final World world, final float celestialAngle, final float partialTicks, final double defaultR, final double defaultG, final double defaultB, @Nonnull final FogEventSupplier eventConstructor) {
        final Vec3d entityPos = ActiveRenderInfo.projectViewFromEntity((Entity)Minecraft.getMinecraft().player, (double)partialTicks);
        final int originX = MathHelper.fastFloor(entityPos.x);
        final int originZ = MathHelper.fastFloor(entityPos.z);
        final double originDiffX = entityPos.x - originX;
        final double originDiffZ = entityPos.z - originZ;
        final int[] weights = { 0, 1, 4, 6, 4, 1, 0 };
        Vec3d color = Vec3d.ZERO;
        double totalWeight = 0.0;
        for (int offsetX = 0; offsetX < 6; ++offsetX) {
            final double weightX = originDiffX * (weights[offsetX] - weights[offsetX + 1]) + weights[offsetX];
            final int posX = originX + offsetX - 3;
            for (int offsetZ = 0; offsetZ < 6; ++offsetZ) {
                final double weightZ = originDiffZ * (weights[offsetZ] - weights[offsetZ + 1]) + weights[offsetZ];
                final int posZ = originZ + offsetZ - 3;
                final Biome biome = world.getBiome(new BlockPos(posX, 0, posZ));
                final NetherAPIFogColorEvent event = eventConstructor.create(biome, world, celestialAngle, partialTicks);
                event.fogR = defaultR;
                event.fogG = defaultG;
                event.fogB = defaultB;
                final double weight = weightX * weightZ;
                totalWeight += weight;
                color = color.add((MinecraftForge.EVENT_BUS.post((Event)event) ? new Vec3d(event.fogR, event.fogG, event.fogB) : this.getDefaultFogColor(biome, celestialAngle, partialTicks, defaultR, defaultG, defaultB)).scale(weight));
            }
        }
        return color.scale(1.0 / totalWeight);
    }
    
    @FunctionalInterface
    public interface FogEventSupplier
    {
        @Nonnull
        NetherAPIFogColorEvent create(@Nonnull final Biome p0, @Nonnull final World p1, final float p2, final float p3);
    }
}
