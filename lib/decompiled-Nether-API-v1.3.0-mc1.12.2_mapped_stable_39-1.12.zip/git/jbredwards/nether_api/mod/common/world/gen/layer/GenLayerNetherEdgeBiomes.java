package git.jbredwards.nether_api.mod.common.world.gen.layer;

import javax.annotation.*;
import net.minecraft.world.gen.layer.*;
import java.util.function.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraftforge.common.*;

public class GenLayerNetherEdgeBiomes extends GenLayer
{
    public GenLayerNetherEdgeBiomes(final long seed, @Nonnull final GenLayer parentIn) {
        super(seed);
        this.parent = parentIn;
    }
    
    @Nonnull
    public int[] getInts(final int areaX, final int areaZ, final int areaWidth, final int areaHeight) {
        final int[] out = IntCache.getIntCache(areaWidth * areaHeight);
        final int[] biomeIds = this.parent.getInts(areaX - 1, areaZ - 1, areaWidth + 2, areaHeight + 2);
        for (int x = 0; x < areaWidth; ++x) {
            for (int z = 0; z < areaHeight; ++z) {
                this.initChunkSeed((long)(areaX + x), (long)(areaZ + z));
                final int biomeId = biomeIds[x + 1 + (z + 1) * (areaHeight + 2)];
                final int index = x + z * areaHeight;
                out[index] = biomeId;
                final int finalX = x;
                final int finalZ = z;
                for (final BooleanSupplier supplier : this.shuffle(() -> this.handleNeighborBiome(out, index, biomeIds[finalX + 1 + (finalZ + 1 - 1) * (areaHeight + 2)]), () -> this.handleNeighborBiome(out, index, biomeIds[finalX + 1 + 1 + (finalZ + 1) * (areaHeight + 2)]), () -> this.handleNeighborBiome(out, index, biomeIds[finalX + 1 - 1 + (finalZ + 1) * (areaHeight + 2)]), () -> this.handleNeighborBiome(out, index, biomeIds[finalX + 1 + (finalZ + 1 + 1) * (areaHeight + 2)]))) {
                    if (supplier.getAsBoolean()) {
                        break;
                    }
                }
            }
        }
        return out;
    }
    
    @Nonnull
    @SafeVarargs
    protected final <T> T[] shuffle(@Nonnull final T... original) {
        for (int i = original.length - 1; i > 0; --i) {
            final T temp = original[i];
            final int rand = this.nextInt(i + 1);
            original[i] = original[rand];
            original[rand] = temp;
        }
        return original;
    }
    
    protected boolean handleNeighborBiome(@Nonnull final int[] out, final int index, final int neighborId) {
        if (out[index] != neighborId) {
            final Biome biome = Biome.getBiomeForId(out[index]);
            if (biome instanceof INetherAPIBiomeProvider) {
                final List<BiomeManager.BiomeEntry> edgeBiomes = ((INetherAPIBiomeProvider)biome).getEdgeBiomes(neighborId);
                if (!edgeBiomes.isEmpty()) {
                    final int totalWeight = WeightedRandom.getTotalWeight((List)edgeBiomes);
                    final Biome edgeBiome = ((BiomeManager.BiomeEntry)WeightedRandom.getRandomItem((List)edgeBiomes, this.nextInt(totalWeight))).biome;
                    out[index] = Biome.getIdForBiome(edgeBiome);
                    return true;
                }
            }
        }
        return false;
    }
}
