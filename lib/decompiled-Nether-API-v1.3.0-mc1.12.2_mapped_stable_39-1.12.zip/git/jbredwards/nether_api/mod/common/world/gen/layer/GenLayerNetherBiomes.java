package git.jbredwards.nether_api.mod.common.world.gen.layer;

import git.jbredwards.nether_api.api.registry.*;
import javax.annotation.*;
import net.minecraft.world.gen.layer.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraftforge.common.*;
import net.minecraft.world.biome.*;

public class GenLayerNetherBiomes extends GenLayer
{
    @Nonnull
    protected final INetherAPIRegistry registry;
    
    public GenLayerNetherBiomes(final long seed, @Nonnull final INetherAPIRegistry registryIn) {
        super(seed);
        this.registry = registryIn;
    }
    
    @Nonnull
    public int[] getInts(final int areaX, final int areaZ, final int areaWidth, final int areaHeight) {
        final int[] out = IntCache.getIntCache(areaWidth * areaHeight);
        final int totalWeight = WeightedRandom.getTotalWeight((List)this.registry.getBiomeEntries());
        for (int x = 0; x < areaWidth; ++x) {
            for (int z = 0; z < areaHeight; ++z) {
                this.initChunkSeed((long)(x + areaX), (long)(z + areaZ));
                final Biome biome = ((BiomeManager.BiomeEntry)WeightedRandom.getRandomItem((List)this.registry.getBiomeEntries(), this.nextInt(totalWeight))).biome;
                out[x + z * areaHeight] = Biome.getIdForBiome(biome);
            }
        }
        return out;
    }
}
