package git.jbredwards.nether_api.mod.common.world.biome;

import javax.annotation.*;
import git.jbredwards.nether_api.mod.common.registry.*;
import git.jbredwards.nether_api.api.registry.*;
import java.util.function.*;
import net.minecraft.world.*;
import net.minecraftforge.common.*;
import net.minecraftforge.fml.common.eventhandler.*;
import git.jbredwards.nether_api.mod.common.world.gen.layer.*;
import net.minecraft.world.gen.layer.*;
import git.jbredwards.nether_api.api.event.*;

public class BiomeProviderNether extends BiomeProviderNetherAPI
{
    public BiomeProviderNether(@Nonnull final World world) {
        super(world, NetherAPIRegistry.NETHER, (BiFunction<INetherAPIRegistry, World, NetherAPIRegistryEvent>)NetherAPIRegistryEvent.Nether::new);
    }
    
    @Nonnull
    @Override
    public GenLayer[] getBiomeGenerators(@Nonnull final WorldType worldType, final long seed, @Nonnull final INetherAPIRegistry registry) {
        final NetherAPIBiomeSizeEvent event = new NetherAPIBiomeSizeEvent.Nether(worldType, 3);
        MinecraftForge.TERRAIN_GEN_BUS.post((Event)event);
        final GenLayer biomeLayerBase = (GenLayer)new GenLayerFuzzyZoom(10L, (GenLayer)new GenLayerNetherBiomes(20L, registry));
        final GenLayer biomeLayerWithSub = GenLayerZoom.magnify(10L, (GenLayer)new GenLayerNetherSubBiomes(20L, biomeLayerBase), event.biomeSize);
        final GenLayer biomeLayerWithEdge = new GenLayerNetherEdgeBiomes(20L, biomeLayerWithSub);
        final GenLayer biomeLayer = (GenLayer)new GenLayerSmooth(10L, (GenLayer)new GenLayerSmooth(10L, GenLayerZoom.magnify(10L, biomeLayerWithEdge, 2)));
        final GenLayer indexLayer = (GenLayer)new GenLayerVoronoiZoom(10L, biomeLayer);
        indexLayer.initWorldGenSeed(seed);
        return new GenLayer[] { biomeLayer, indexLayer };
    }
    
    @Nonnull
    @Override
    public GenLayer[] getModdedBiomeGenerators(@Nonnull final WorldType worldType, final long seed, @Nonnull final GenLayer[] original) {
        final NetherAPIInitBiomeGensEvent event = new NetherAPIInitBiomeGensEvent.Nether(worldType, seed, original);
        MinecraftForge.TERRAIN_GEN_BUS.post((Event)event);
        return event.biomeGenerators;
    }
}
