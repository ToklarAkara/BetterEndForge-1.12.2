package git.jbredwards.nether_api.mod.common.world.biome;

import net.minecraft.world.gen.*;
import javax.annotation.*;
import git.jbredwards.nether_api.mod.common.registry.*;
import git.jbredwards.nether_api.api.registry.*;
import java.util.function.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraftforge.common.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.world.gen.layer.*;
import git.jbredwards.nether_api.mod.common.world.gen.layer.*;
import git.jbredwards.nether_api.api.event.*;

public class BiomeProviderTheEnd extends BiomeProviderNetherAPI
{
    @Nonnull
    public final NoiseGeneratorSimplex islandNoise;
    
    public BiomeProviderTheEnd(@Nonnull final World world) {
        super(world, NetherAPIRegistry.THE_END, (BiFunction<INetherAPIRegistry, World, NetherAPIRegistryEvent>)NetherAPIRegistryEvent.End::new);
        this.islandNoise = new NoiseGeneratorSimplex(new Random(world.getSeed()));
    }
    
    @Nonnull
    @Override
    public GenLayer[] getBiomeGenerators(@Nonnull final WorldType worldType, final long seed, @Nonnull final INetherAPIRegistry registry) {
        final NetherAPIBiomeSizeEvent event = new NetherAPIBiomeSizeEvent.End(worldType, 3);
        MinecraftForge.TERRAIN_GEN_BUS.post((Event)event);
        final GenLayer biomeLayerBase = (GenLayer)new GenLayerFuzzyZoom(10L, (GenLayer)new GenLayerNetherBiomes(20L, registry));
        final GenLayer biomeLayerWithSub = GenLayerZoom.magnify(10L, (GenLayer)new GenLayerNetherSubBiomes(20L, biomeLayerBase), event.biomeSize);
        final GenLayer biomeLayerWithEdge = new GenLayerNetherEdgeBiomes(20L, biomeLayerWithSub);
        final GenLayer biomeLayer = (GenLayer)new GenLayerSmooth(10L, (GenLayer)new GenLayerSmooth(10L, GenLayerZoom.magnify(10L, biomeLayerWithEdge, 2)));
        final GenLayer indexLayer = (GenLayer)new GenLayerVoronoiZoom(10L, biomeLayer);
        indexLayer.initWorldGenSeed(seed);
        return new GenLayer[] { new GenLayerEnd(this, biomeLayer), new GenLayerEnd(this, indexLayer) };
    }
    
    @Nonnull
    @Override
    public GenLayer[] getModdedBiomeGenerators(@Nonnull final WorldType worldType, final long seed, @Nonnull final GenLayer[] original) {
        final NetherAPIInitBiomeGensEvent event = new NetherAPIInitBiomeGensEvent.End(worldType, seed, original);
        MinecraftForge.TERRAIN_GEN_BUS.post((Event)event);
        return event.biomeGenerators;
    }
}
