package git.jbredwards.nether_api.mod.common.world.gen;

import git.jbredwards.nether_api.api.world.*;
import net.minecraft.world.biome.*;
import net.minecraft.world.gen.structure.*;
import net.minecraft.world.*;
import net.minecraft.init.*;
import git.jbredwards.nether_api.mod.common.registry.*;
import net.minecraft.block.state.*;
import net.minecraftforge.event.*;
import net.minecraft.world.gen.*;
import git.jbredwards.nether_api.api.biome.*;
import git.jbredwards.nether_api.api.util.*;
import net.minecraft.world.chunk.*;
import git.jbredwards.nether_api.mod.common.config.*;
import git.jbredwards.nether_api.mod.*;
import git.jbredwards.nether_api.mod.common.compat.netherex.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import net.minecraftforge.common.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.event.terraingen.*;
import net.minecraft.entity.*;
import javax.annotation.*;
import java.util.*;
import git.jbredwards.nether_api.api.structure.*;
import net.minecraft.block.material.*;
import net.minecraft.world.gen.feature.*;

public class ChunkGeneratorNether extends ChunkGeneratorHell implements INetherAPIChunkGenerator
{
    @Nonnull
    protected final NoiseGeneratorPerlin terrainNoiseGen;
    @Nonnull
    protected Biome[] biomesForGeneration;
    @Nonnull
    protected final List<MapGenStructure> moddedStructures;
    
    public ChunkGeneratorNether(@Nonnull final World worldIn, final boolean generateStructures, final long seed) {
        super(worldIn, generateStructures, seed);
        this.biomesForGeneration = new Biome[0];
        this.moddedStructures = new LinkedList<MapGenStructure>();
        this.terrainNoiseGen = new NoiseGeneratorPerlin(this.rand, 4);
        this.magmaGen = (WorldGenerator)new WorldGenMinable(Blocks.MAGMA.getDefaultState(), 33, state -> state == ChunkGeneratorNether.NETHERRACK || (state.isFullCube() && state.getMaterial() != Material.ROCK));
        NetherAPIRegistry.NETHER.getStructures().forEach(entry -> this.moddedStructures.add(entry.getStructureFactory().apply(this)));
    }
    
    public void prepareHeights(final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer) {
        final int lavaHeight = (this.world.getSeaLevel() >> 1) + 1;
        final int noiseHeight = (this.world.getActualHeight() >> 3) + 1;
        final int noiseWidthX = 5;
        final int noiseWidthZ = 5;
        this.buffer = this.getHeights(this.buffer, chunkX << 2, 0, chunkZ << 2, 5, noiseHeight, 5);
        for (int j1 = 0; j1 < 4; ++j1) {
            for (int k1 = 0; k1 < 4; ++k1) {
                for (int heightIndex = noiseHeight - 2; heightIndex >= 0; --heightIndex) {
                    double d1 = this.buffer[((j1 + 0) * 5 + k1 + 0) * noiseHeight + heightIndex];
                    double d2 = this.buffer[((j1 + 0) * 5 + k1 + 1) * noiseHeight + heightIndex];
                    double d3 = this.buffer[((j1 + 1) * 5 + k1 + 0) * noiseHeight + heightIndex];
                    double d4 = this.buffer[((j1 + 1) * 5 + k1 + 1) * noiseHeight + heightIndex];
                    final double d5 = (this.buffer[((j1 + 0) * 5 + k1 + 0) * noiseHeight + heightIndex + 1] - d1) * 0.125;
                    final double d6 = (this.buffer[((j1 + 0) * 5 + k1 + 1) * noiseHeight + heightIndex + 1] - d2) * 0.125;
                    final double d7 = (this.buffer[((j1 + 1) * 5 + k1 + 0) * noiseHeight + heightIndex + 1] - d3) * 0.125;
                    final double d8 = (this.buffer[((j1 + 1) * 5 + k1 + 1) * noiseHeight + heightIndex + 1] - d4) * 0.125;
                    for (int yOffset = 0; yOffset < 8; ++yOffset) {
                        double d9 = d1;
                        double d10 = d2;
                        final double d11 = (d3 - d1) * 0.25;
                        final double d12 = (d4 - d2) * 0.25;
                        for (int xOffset = 0; xOffset < 4; ++xOffset) {
                            double density = d9;
                            final double d13 = (d10 - d9) * 0.25;
                            for (int zOffset = 0; zOffset < 4; ++zOffset) {
                                final int y = (heightIndex << 3) + yOffset;
                                IBlockState state = null;
                                if (y < lavaHeight) {
                                    state = ChunkGeneratorNether.LAVA;
                                }
                                if (density > 0.0) {
                                    state = ChunkGeneratorNether.NETHERRACK;
                                }
                                primer.setBlockState((j1 << 2) + xOffset, y, (k1 << 2) + zOffset, state);
                                density += d13;
                            }
                            d9 += d11;
                            d10 += d12;
                        }
                        d1 += d5;
                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                    }
                }
            }
        }
    }
    
    public void buildSurfaces(final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer) {
        if (!ForgeEventFactory.onReplaceBiomeBlocks((IChunkGenerator)this, chunkX, chunkZ, primer, this.world)) {
            return;
        }
        final int originX = chunkX << 4;
        final int originZ = chunkZ << 4;
        this.slowsandNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.slowsandNoise, originX, originZ, 0, 16, 16, 1, 0.03125, 0.03125, 1.0);
        this.gravelNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.gravelNoise, originX, 109, originZ, 16, 1, 16, 0.03125, 1.0, 0.03125);
        this.depthBuffer = this.netherrackExculsivityNoiseGen.generateNoiseOctaves(this.depthBuffer, originX, originZ, 0, 16, 16, 1, 0.0625, 0.0625, 0.0625);
        final double[] terrainNoise = this.terrainNoiseGen.getRegion((double[])null, (double)originX, (double)originZ, 16, 16, 0.0625, 0.0625, 1.0);
        for (int posX = 0; posX < 16; ++posX) {
            for (int posZ = 0; posZ < 16; ++posZ) {
                for (int posY = 4; posY >= 0; --posY) {
                    if (posY <= this.rand.nextInt(5)) {
                        primer.setBlockState(posX, posY, posZ, ChunkGeneratorNether.BEDROCK);
                    }
                    if (posY >= 4 - this.rand.nextInt(5)) {
                        primer.setBlockState(posX, posY + this.world.getActualHeight() - 5, posZ, ChunkGeneratorNether.BEDROCK);
                    }
                }
                final Biome biome = this.biomesForGeneration[posZ << 4 | posX];
                if (biome instanceof INetherBiome) {
                    ((INetherBiome)biome).buildSurface(this, chunkX, chunkZ, primer, posX, posZ, this.slowsandNoise, this.gravelNoise, this.depthBuffer, terrainNoise[posZ << 4 | posX]);
                }
                else {
                    NetherGenerationUtils.buildSurfaceAndSoulSandGravel(this.world, this.rand, primer, posX, posZ, this.slowsandNoise, this.gravelNoise, this.depthBuffer, ChunkGeneratorNether.NETHERRACK, biome.topBlock, biome.fillerBlock, ChunkGeneratorNether.LAVA);
                }
            }
        }
    }
    
    @Nonnull
    public Chunk generateChunk(final int x, final int z) {
        this.rand.setSeed(x * 341873128712L + z * 132897987541L);
        this.biomesForGeneration = this.world.getBiomeProvider().getBiomes((Biome[])null, x << 4, z << 4, 16, 16);
        final ChunkPrimer primer = new ChunkPrimer();
        this.setBlocksInPrimer(x, z, primer);
        this.buildSurfaces(x, z, primer);
        if (NetherAPIConfig.hellCaves) {
            this.genNetherCaves.generate(this.world, x, z, primer);
        }
        if (this.areStructuresEnabled()) {
            if (this.genNetherBridge != null) {
                this.genNetherBridge.generate(this.world, x, z, primer);
            }
            this.moddedStructures.forEach(structure -> structure.generate(this.world, x, z, primer));
        }
        final Chunk chunk = new Chunk(this.world, primer, x, z);
        final byte[] biomeArray = chunk.getBiomeArray();
        for (int i = 0; i < biomeArray.length; ++i) {
            biomeArray[i] = (byte)Biome.getIdForBiome(this.biomesForGeneration[i]);
        }
        chunk.resetRelightChecks();
        if (NetherAPI.isNetherExLoaded) {
            NetherExHandler.onChunkGenerate(chunk);
        }
        return chunk;
    }
    
    public void populate(final int chunkX, final int chunkZ) {
        final boolean prevFixVanillaCascading = ForgeModContainer.fixVanillaCascading;
        ForgeModContainer.fixVanillaCascading = true;
        final BlockPos pos = new BlockPos(chunkX << 4, 0, chunkZ << 4);
        final Biome biome = this.world.getBiome(pos.add(16, 0, 16));
        final ChunkPos chunkPos = new ChunkPos(chunkX, chunkZ);
        this.moddedStructures.forEach(structure -> structure.generateStructure(this.world, this.rand, chunkPos));
        if (!(biome instanceof INetherBiome)) {
            this.populateWithVanilla(chunkX, chunkZ);
        }
        else {
            BlockFalling.fallInstantly = true;
            if (this.genNetherBridge != null) {
                this.genNetherBridge.generateStructure(this.world, this.rand, chunkPos);
            }
            ((INetherBiome)biome).populate(this, chunkX, chunkZ);
            BlockFalling.fallInstantly = false;
        }
        ForgeModContainer.fixVanillaCascading = prevFixVanillaCascading;
    }
    
    public void populateWithVanilla(final int chunkX, final int chunkZ) {
        final ChunkPos chunkPos = new ChunkPos(chunkX, chunkZ);
        final int originX = chunkX << 4;
        final int originZ = chunkZ << 4;
        final int maxHeight = this.world.getActualHeight();
        final int heightGenFactor = 0;
        ForgeEventFactory.onChunkPopulate(BlockFalling.fallInstantly = true, (IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false);
        if (this.genNetherBridge != null) {
            this.genNetherBridge.generateStructure(this.world, this.rand, chunkPos);
        }
        final BlockPos pos = new BlockPos(originX, 0, originZ);
        final Biome biome = this.world.getBiome(pos.add(16, 0, 16));
        if (TerrainGen.populate((IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false, PopulateChunkEvent.Populate.EventType.NETHER_LAVA)) {
            for (int i = 0; i < 8; ++i) {
                this.hellSpringGen.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, this.rand.nextInt(maxHeight - 8) + 4, this.rand.nextInt(16) + 8));
            }
        }
        if (TerrainGen.populate((IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false, PopulateChunkEvent.Populate.EventType.FIRE)) {
            for (int i = 0; i < this.rand.nextInt(this.rand.nextInt(10) + 1) + 1 << 0; ++i) {
                this.fireFeature.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, this.rand.nextInt(maxHeight - 8) + 4, this.rand.nextInt(16) + 8));
            }
        }
        if (TerrainGen.populate((IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false, PopulateChunkEvent.Populate.EventType.GLOWSTONE)) {
            for (int i = 0; i < this.rand.nextInt(this.rand.nextInt(10) + 1) + 1 << 0; ++i) {
                this.lightGemGen.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, this.rand.nextInt(maxHeight - 8) + 4, this.rand.nextInt(16) + 8));
            }
            for (int i = 0; i < 10; ++i) {
                this.hellPortalGen.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, this.rand.nextInt(maxHeight), this.rand.nextInt(16) + 8));
            }
        }
        ForgeEventFactory.onChunkPopulate(false, (IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false);
        MinecraftForge.EVENT_BUS.post((Event)new DecorateBiomeEvent.Pre(this.world, this.rand, chunkPos));
        if (TerrainGen.decorate(this.world, this.rand, chunkPos, DecorateBiomeEvent.Decorate.EventType.SHROOM)) {
            for (int i = 0; i < 1; ++i) {
                if (this.rand.nextBoolean()) {
                    this.brownMushroomFeature.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, this.rand.nextInt(maxHeight), this.rand.nextInt(16) + 8));
                }
                if (this.rand.nextBoolean()) {
                    this.redMushroomFeature.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, this.rand.nextInt(maxHeight), this.rand.nextInt(16) + 8));
                }
            }
        }
        if (TerrainGen.generateOre(this.world, this.rand, this.quartzGen, pos, OreGenEvent.GenerateMinable.EventType.QUARTZ)) {
            for (int i = 0; i < 16; ++i) {
                this.quartzGen.generate(this.world, this.rand, pos.add(this.rand.nextInt(16), this.rand.nextInt(maxHeight - 20) + 10, this.rand.nextInt(16)));
            }
        }
        if (TerrainGen.populate((IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false, PopulateChunkEvent.Populate.EventType.NETHER_MAGMA)) {
            for (int i = 0; i < 4; ++i) {
                this.magmaGen.generate(this.world, this.rand, pos.add(this.rand.nextInt(16), (this.world.getSeaLevel() >> 1) - 4 + this.rand.nextInt(10), this.rand.nextInt(16)));
            }
        }
        if (TerrainGen.populate((IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false, PopulateChunkEvent.Populate.EventType.NETHER_LAVA2)) {
            for (int i = 0; i < 16; ++i) {
                this.lavaTrapGen.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, this.rand.nextInt(maxHeight - 20) + 10, this.rand.nextInt(16) + 8));
            }
        }
        biome.decorate(this.world, this.rand, new BlockPos(originX, 0, originZ));
        MinecraftForge.EVENT_BUS.post((Event)new DecorateBiomeEvent.Post(this.world, this.rand, chunkPos));
        BlockFalling.fallInstantly = false;
    }
    
    @Nonnull
    public List<Biome.SpawnListEntry> getPossibleCreatures(@Nonnull final EnumCreatureType creatureType, @Nonnull final BlockPos pos) {
        if (this.areStructuresEnabled()) {
            if (creatureType == EnumCreatureType.MONSTER && this.genNetherBridge != null && (this.genNetherBridge.isInsideStructure(pos) || (this.genNetherBridge.isPositionInStructure(this.world, pos) && this.world.getBlockState(pos.down()).getBlock() == Blocks.NETHER_BRICK))) {
                return (List<Biome.SpawnListEntry>)this.genNetherBridge.getSpawnList();
            }
            for (final MapGenStructure structure : this.moddedStructures) {
                if (structure instanceof ISpawningStructure) {
                    final List<Biome.SpawnListEntry> possibleCreatures = ((ISpawningStructure)structure).getPossibleCreatures(creatureType, this.world, pos);
                    if (!possibleCreatures.isEmpty()) {
                        return possibleCreatures;
                    }
                    continue;
                }
            }
        }
        return NetherAPI.isNetherExLoaded ? NetherExHandler.getSpawnableList(this.world.getBiome(pos), creatureType) : this.world.getBiome(pos).getSpawnableList(creatureType);
    }
    
    @Nullable
    public BlockPos getNearestStructurePos(@Nonnull final World worldIn, @Nonnull final String structureName, @Nonnull final BlockPos position, final boolean findUnexplored) {
        if (this.areStructuresEnabled()) {
            if ("Fortress".equals(structureName) && this.genNetherBridge != null) {
                return this.genNetherBridge.getNearestStructurePos(worldIn, position, findUnexplored);
            }
            for (final MapGenStructure structure : this.moddedStructures) {
                if (structure.getStructureName().equals(structureName)) {
                    return structure.getNearestStructurePos(worldIn, position, findUnexplored);
                }
            }
        }
        return null;
    }
    
    public boolean isInsideStructure(@Nonnull final World worldIn, @Nonnull final String structureName, @Nonnull final BlockPos pos) {
        if (this.areStructuresEnabled()) {
            if ("Fortress".equals(structureName) && this.genNetherBridge != null) {
                return this.genNetherBridge.isInsideStructure(pos);
            }
            for (final MapGenStructure structure : this.moddedStructures) {
                if (structure.getStructureName().equals(structureName)) {
                    return structure.isInsideStructure(pos);
                }
            }
        }
        return false;
    }
    
    public void recreateStructures(@Nonnull final Chunk chunkIn, final int x, final int z) {
        if (this.areStructuresEnabled()) {
            this.genNetherBridge.generate(this.world, x, z, (ChunkPrimer)null);
            this.moddedStructures.forEach(structure -> structure.generate(this.world, x, z, (ChunkPrimer)null));
        }
    }
    
    @Nonnull
    public World getWorld() {
        return this.world;
    }
    
    @Nonnull
    public Random getRand() {
        return this.rand;
    }
    
    public boolean areStructuresEnabled() {
        return this.generateStructures;
    }
    
    public void setBlocksInPrimer(final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer) {
        this.prepareHeights(chunkX, chunkZ, primer);
    }
}
