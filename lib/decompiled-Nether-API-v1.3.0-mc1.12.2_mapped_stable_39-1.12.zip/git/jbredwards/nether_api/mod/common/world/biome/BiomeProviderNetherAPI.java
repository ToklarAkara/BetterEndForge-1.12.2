package git.jbredwards.nether_api.mod.common.world.biome;

import git.jbredwards.nether_api.api.registry.*;
import java.util.function.*;
import git.jbredwards.nether_api.api.event.*;
import net.minecraftforge.fml.common.eventhandler.*;
import git.jbredwards.nether_api.api.biome.*;
import com.google.common.collect.*;
import java.util.stream.*;
import net.minecraft.world.*;
import net.minecraft.world.biome.*;
import javax.annotation.*;
import net.minecraft.world.gen.layer.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraftforge.common.*;

public abstract class BiomeProviderNetherAPI extends BiomeProvider
{
    protected BiomeProviderNetherAPI(@Nonnull final World world, @Nonnull final INetherAPIRegistry registry, @Nonnull final BiFunction<INetherAPIRegistry, World, NetherAPIRegistryEvent> eventSupplier) {
        if (registry.isEmpty()) {
            MinecraftForge.EVENT_BUS.post((Event)eventSupplier.apply(registry, world));
        }
        if (registry.getBiomeEntries().isEmpty()) {
            final String id = world.provider.getDimensionType().getName();
            throw new IllegalStateException("Dimension with id: \"" + id + "\" has no biomes, try adjusting your config settings!");
        }
        final GenLayer[] biomeGenerators = this.getModdedBiomeGenerators(world.getWorldType(), world.getSeed(), this.getBiomeGenerators(world.getWorldType(), world.getSeed(), registry));
        this.genBiomes = biomeGenerators[0];
        this.biomeIndexLayer = biomeGenerators[1];
        this.biomesToSpawnIn = registry.getBiomeEntries().stream().map(entry -> entry.biome).filter(biome -> !(biome instanceof INoSpawnBiome)).collect((Collector<? super Object, Object, List>)ImmutableList.toImmutableList());
    }
    
    @Nonnull
    public abstract GenLayer[] getBiomeGenerators(@Nonnull final WorldType p0, final long p1, @Nonnull final INetherAPIRegistry p2);
    
    @Nonnull
    public abstract GenLayer[] getModdedBiomeGenerators(@Nonnull final WorldType p0, final long p1, @Nonnull final GenLayer[] p2);
    
    @Nonnull
    public Biome[] getBiomesForGeneration(@Nullable Biome[] listToReuse, final int x, final int z, final int width, final int height) {
        IntCache.resetIntCache();
        final int size = width * height;
        if (listToReuse == null || listToReuse.length < size) {
            listToReuse = new Biome[size];
        }
        final int[] biomeIds = this.genBiomes.getInts(x, z, width, height);
        for (int i = 0; i < size; ++i) {
            final int biomeId = biomeIds[i];
            listToReuse[i] = Objects.requireNonNull(Biome.getBiome(biomeId), () -> "Unmapped biome id: " + biomeId);
        }
        return listToReuse;
    }
    
    @Nonnull
    public Biome[] getBiomes(@Nullable Biome[] listToReuse, final int x, final int z, final int width, final int height, final boolean cacheFlag) {
        IntCache.resetIntCache();
        final int size = width * height;
        if (listToReuse == null || listToReuse.length < size) {
            listToReuse = new Biome[size];
        }
        if (cacheFlag && width == 16 && height == 16 && (x & 0xF) == 0x0 && (z & 0xF) == 0x0) {
            final Biome[] biomes = this.biomeCache.getCachedBiomes(x, z);
            System.arraycopy(biomes, 0, listToReuse, 0, size);
            return listToReuse;
        }
        final int[] biomeIds = this.biomeIndexLayer.getInts(x, z, width, height);
        for (int i = 0; i < size; ++i) {
            final int biomeId = biomeIds[i];
            listToReuse[i] = Objects.requireNonNull(Biome.getBiome(biomeId), () -> "Unmapped biome id: " + biomeId);
        }
        return listToReuse;
    }
    
    public boolean areBiomesViable(final int x, final int z, final int radius, @Nonnull final List<Biome> allowed) {
        return !allowed.isEmpty() && super.areBiomesViable(x, z, radius << 2, (List)allowed);
    }
    
    @Nullable
    public BlockPos findBiomePosition(final int x, final int z, final int range, @Nonnull final List<Biome> biomes, @Nonnull final Random random) {
        return biomes.isEmpty() ? null : super.findBiomePosition(x, z, range << 2, (List)biomes, random);
    }
}
