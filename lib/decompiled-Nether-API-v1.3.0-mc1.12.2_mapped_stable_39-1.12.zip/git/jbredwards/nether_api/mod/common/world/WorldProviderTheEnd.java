package git.jbredwards.nether_api.mod.common.world;

import git.jbredwards.nether_api.api.world.*;
import git.jbredwards.nether_api.mod.common.world.biome.*;
import net.minecraft.world.end.*;
import net.minecraft.nbt.*;
import net.minecraft.init.*;
import net.minecraft.world.gen.*;
import git.jbredwards.nether_api.mod.common.world.gen.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.audio.*;
import javax.annotation.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.math.*;
import git.jbredwards.nether_api.api.event.*;
import net.minecraft.client.audio.*;
import git.jbredwards.nether_api.mod.client.audio.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.world.gen.feature.*;

public class WorldProviderTheEnd extends WorldProviderEnd implements IAmbienceWorldProvider, IFogWorldProvider
{
    @Nonnull
    public static ExitPortal EXIT_PORTAL;
    @Nonnull
    public static WorldGenerator END_GATEWAY;
    @Nonnull
    public static WorldGenSpikes END_PILLAR;
    public static boolean forceExtraEndFog;
    
    public void init() {
        this.biomeProvider = new BiomeProviderTheEnd(this.world);
        if (this.world instanceof WorldServer) {
            final NBTTagCompound fightData = this.world.getWorldInfo().getDimensionData(this.getDimension()).getCompoundTag("DragonFight");
            this.dragonFightManager = new DragonFightManager((WorldServer)this.world, fightData) {
                public void generateGateway(@Nonnull final BlockPos pos) {
                    WorldProviderTheEnd.this.world.playEvent(3000, pos, 0);
                    WorldProviderTheEnd.END_GATEWAY.generate(WorldProviderTheEnd.this.world, WorldProviderTheEnd.this.createSeedRandom(pos), pos);
                }
                
                public void generatePortal(final boolean active) {
                    if (this.exitPortalLocation == null) {
                        this.exitPortalLocation = WorldProviderTheEnd.this.world.getTopSolidOrLiquidBlock(WorldGenEndPodium.END_PODIUM_LOCATION).down();
                        while (WorldProviderTheEnd.this.world.getBlockState(this.exitPortalLocation).getBlock() == Blocks.BEDROCK && this.exitPortalLocation.getY() > WorldProviderTheEnd.this.world.getSeaLevel()) {
                            this.exitPortalLocation = this.exitPortalLocation.down();
                        }
                    }
                    WorldProviderTheEnd.EXIT_PORTAL.create(active).generate(WorldProviderTheEnd.this.world, WorldProviderTheEnd.this.createSeedRandom(this.exitPortalLocation), this.exitPortalLocation);
                }
            };
        }
    }
    
    @Nonnull
    public IChunkGenerator createChunkGenerator() {
        return (IChunkGenerator)new ChunkGeneratorTheEnd(this.world, this.world.getWorldInfo().isMapFeaturesEnabled(), (BiomeProviderTheEnd)this.biomeProvider, this.getSpawnCoordinate());
    }
    
    @Nullable
    public IDarkSoundAmbience getDarkAmbienceSound(@Nonnull final Biome biome) {
        return (biome instanceof IAmbienceBiome) ? ((IAmbienceBiome)biome).getDarkAmbienceSound() : null;
    }
    
    @SideOnly(Side.CLIENT)
    public boolean doesXZShowFog(final int x, final int z) {
        if (WorldProviderTheEnd.forceExtraEndFog) {
            return true;
        }
        final Biome biome = this.world.getBiome(new BlockPos(x, 0, z));
        return biome instanceof IEndBiome && ((IEndBiome)biome).hasExtraXZFog(this.world, x, z);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    public Vec3d getFogColor(final float celestialAngle, final float partialTicks) {
        return this.getFogColor(this.world, celestialAngle, partialTicks, 0.09411766, 0.07529412, 0.09411766, NetherAPIFogColorEvent.End::new);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    public Vec3d getDefaultFogColor(@Nonnull final Biome biome, final float celestialAngle, final float partialTicks, final double defaultR, final double defaultG, final double defaultB) {
        return (biome instanceof IEndBiome) ? ((IEndBiome)biome).getFogColor(celestialAngle, partialTicks) : new Vec3d(defaultR, defaultG, defaultB);
    }
    
    @Nullable
    @SideOnly(Side.CLIENT)
    public MusicTicker.MusicType getMusicType() {
        return TheEndMusicHandler.getMusicType();
    }
    
    @Nonnull
    public Random createSeedRandom(@Nonnull final BlockPos pos) {
        final Random rand = new Random(this.world.getSeed());
        rand.setSeed((rand.nextLong() >> 3) * (pos.getX() >> 4) + (rand.nextLong() >> 3) * (pos.getZ() >> 4) ^ this.world.getSeed());
        return rand;
    }
    
    static {
        WorldProviderTheEnd.EXIT_PORTAL = WorldGenEndPodium::new;
        WorldProviderTheEnd.END_GATEWAY = (WorldGenerator)new WorldGenEndGateway();
        WorldProviderTheEnd.END_PILLAR = new WorldGenSpikes();
        WorldProviderTheEnd.forceExtraEndFog = false;
    }
    
    @FunctionalInterface
    public interface ExitPortal
    {
        WorldGenerator create(final boolean p0);
    }
}
