package git.jbredwards.nether_api.mod.common.world.gen.layer;

import javax.annotation.*;
import net.minecraft.world.gen.layer.*;
import net.minecraft.world.biome.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraftforge.common.*;

public class GenLayerNetherSubBiomes extends GenLayer
{
    public GenLayerNetherSubBiomes(final long seed, @Nonnull final GenLayer parentIn) {
        super(seed);
        this.parent = parentIn;
    }
    
    @Nonnull
    public int[] getInts(final int areaX, final int areaZ, final int areaWidth, final int areaHeight) {
        final int[] out = IntCache.getIntCache(areaWidth * areaHeight);
        final int[] biomeIds = this.parent.getInts(areaX - 1, areaZ - 1, areaWidth + 2, areaHeight + 2);
        for (int x = 0; x < areaWidth; ++x) {
            for (int z = 0; z < areaHeight; ++z) {
                this.initChunkSeed((long)(areaX + x), (long)(areaZ + z));
                final int biomeId = biomeIds[x + 1 + (z + 1) * (areaHeight + 2)];
                out[x + z * areaHeight] = biomeId;
                if (biomeId == biomeIds[x + 1 + (z + 1 - 1) * (areaHeight + 2)] && biomeId == biomeIds[x + 1 + 1 + (z + 1) * (areaHeight + 2)] && biomeId == biomeIds[x + 1 - 1 + (z + 1) * (areaHeight + 2)] && biomeId == biomeIds[x + 1 + (z + 1 + 1) * (areaHeight + 2)]) {
                    final Biome biome = Biome.getBiomeForId(biomeId);
                    if (biome instanceof INetherAPIBiomeProvider) {
                        final List<BiomeManager.BiomeEntry> subBiomes = ((INetherAPIBiomeProvider)biome).getSubBiomes();
                        if (!subBiomes.isEmpty()) {
                            final int totalWeight = WeightedRandom.getTotalWeight((List)subBiomes);
                            final Biome subBiome = ((BiomeManager.BiomeEntry)WeightedRandom.getRandomItem((List)subBiomes, this.nextInt(totalWeight))).biome;
                            out[x + z * areaHeight] = Biome.getIdForBiome(subBiome);
                        }
                    }
                }
            }
        }
        return out;
    }
}
