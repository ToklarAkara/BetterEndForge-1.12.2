package git.jbredwards.nether_api.mod.common.world.gen.layer;

import git.jbredwards.nether_api.mod.common.world.biome.*;
import javax.annotation.*;
import net.minecraft.world.gen.layer.*;
import java.util.*;
import net.minecraft.init.*;
import net.minecraft.world.biome.*;

public class GenLayerEnd extends GenLayer
{
    protected static final int END_ID;
    protected static final int VOID_ID;
    @Nonnull
    protected final BiomeProviderTheEnd biomeProvider;
    
    public GenLayerEnd(@Nonnull final BiomeProviderTheEnd biomeProviderIn, @Nonnull final GenLayer parentIn) {
        super(1L);
        this.parent = parentIn;
        this.biomeProvider = biomeProviderIn;
    }
    
    @Nonnull
    public int[] getInts(final int areaX, final int areaZ, final int areaWidth, final int areaHeight) {
        final int[] out = IntCache.getIntCache(areaWidth * areaHeight);
        if ((areaX >> 4) * (long)(areaX >> 4) + (areaZ >> 4) * (long)(areaZ >> 4) <= 2048L) {
            Arrays.fill(out, GenLayerEnd.END_ID);
        }
        else {
            final int[] biomeIds = this.parent.getInts(areaX, areaZ, areaWidth, areaHeight);
            for (int x = 0; x < areaWidth; ++x) {
                final int blockX = areaX + x;
                for (int z = 0; z < areaHeight; ++z) {
                    final int index = x + z * areaHeight;
                    out[index] = biomeIds[index];
                }
            }
        }
        return out;
    }
    
    protected boolean isVoidAt(final int blockX, final int blockZ) {
        final double vanillaBlockX = blockX / 8.0 + 1.0;
        final double vanillaBlockZ = blockX / 8.0 + 1.0;
        final double chunkX = blockX / 16.0;
        final double chunkZ = blockZ / 16.0;
        double height = 100.0 - Math.sqrt(vanillaBlockX * vanillaBlockX + vanillaBlockZ * vanillaBlockZ) * 8.0;
        for (int x = -12; x <= 12; ++x) {
            final double offsetX = chunkX + x;
            for (int z = -12; z <= 12; ++z) {
                final double offsetZ = chunkZ + z;
                if (offsetX * offsetX + offsetZ * offsetZ > 2048.0 && this.biomeProvider.islandNoise.getValue(offsetX, offsetZ) < -0.9) {
                    final double scale = (Math.abs(offsetX) * 3439.0 + Math.abs(offsetZ) * 147.0) % 13.0 + 9.0;
                    final double fracX = 1 - (x << 1);
                    final double fracZ = 1 - (z << 1);
                    final double newHeight = 100.0 - Math.sqrt(fracX * fracX + fracZ * fracZ) * scale;
                    if (height < newHeight) {
                        height = newHeight;
                    }
                }
            }
        }
        return height < -20.0;
    }
    
    static {
        END_ID = Biome.getIdForBiome(Biomes.SKY);
        VOID_ID = Biome.getIdForBiome(Biomes.VOID);
    }
}
