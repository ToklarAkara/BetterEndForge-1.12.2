package git.jbredwards.nether_api.mod.common.world.gen;

import git.jbredwards.nether_api.api.world.*;
import net.minecraft.world.gen.structure.*;
import net.minecraft.world.biome.*;
import net.minecraft.world.*;
import git.jbredwards.nether_api.mod.common.world.biome.*;
import git.jbredwards.nether_api.mod.common.registry.*;
import net.minecraftforge.event.*;
import net.minecraft.world.gen.*;
import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.world.chunk.*;
import git.jbredwards.nether_api.mod.common.config.*;
import net.minecraftforge.common.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import git.jbredwards.nether_api.mod.common.world.*;
import net.minecraft.block.state.*;
import net.minecraft.tileentity.*;
import net.minecraft.entity.*;
import javax.annotation.*;
import java.util.*;
import git.jbredwards.nether_api.api.structure.*;

public class ChunkGeneratorTheEnd extends ChunkGeneratorEnd implements INetherAPIChunkGenerator
{
    @Nonnull
    protected final NoiseGeneratorPerlin terrainNoiseGen;
    @Nonnull
    protected final MapGenCavesEnd genEndCaves;
    @Nonnull
    protected final List<MapGenStructure> moddedStructures;
    @Nonnull
    protected Biome[] biomesForGeneration;
    
    public ChunkGeneratorTheEnd(@Nonnull final World worldIn, final boolean generateStructures, @Nonnull final BiomeProviderTheEnd biomeProvider, @Nonnull final BlockPos spawnCoord) {
        super(worldIn, generateStructures, worldIn.getSeed(), spawnCoord);
        this.genEndCaves = new MapGenCavesEnd();
        this.moddedStructures = new LinkedList<MapGenStructure>();
        this.biomesForGeneration = new Biome[0];
        this.terrainNoiseGen = new NoiseGeneratorPerlin(this.rand, 4);
        this.islandNoise = biomeProvider.islandNoise;
        NetherAPIRegistry.THE_END.getStructures().forEach(entry -> this.moddedStructures.add(entry.getStructureFactory().apply(this)));
    }
    
    public void buildSurfaces(final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer) {
        if (!ForgeEventFactory.onReplaceBiomeBlocks((IChunkGenerator)this, chunkX, chunkZ, primer, this.world)) {
            return;
        }
        final double[] terrainNoise = this.terrainNoiseGen.getRegion((double[])null, (double)(chunkX << 4), (double)(chunkZ << 4), 16, 16, 0.0625, 0.0625, 1.0);
        for (int posX = 0; posX < 16; ++posX) {
            for (int posZ = 0; posZ < 16; ++posZ) {
                final Biome biome = this.biomesForGeneration[posZ << 4 | posX];
                if (biome instanceof IEndBiome) {
                    ((IEndBiome)biome).buildSurface(this, chunkX, chunkZ, primer, posX, posZ, terrainNoise[posZ << 4 | posX]);
                }
            }
        }
    }
    
    @Nonnull
    public Chunk generateChunk(final int chunkX, final int chunkZ) {
        this.rand.setSeed(chunkX * 341873128712L + chunkZ * 132897987541L);
        this.biomesForGeneration = this.world.getBiomeProvider().getBiomes((Biome[])null, chunkX << 4, chunkZ << 4, 16, 16);
        final ChunkPrimer primer = new ChunkPrimer();
        this.setBlocksInPrimer(chunkX, chunkZ, primer);
        this.buildSurfaces(chunkX, chunkZ, primer);
        if (NetherAPIConfig.endCaves) {
            this.genEndCaves.generate(this.world, chunkX, chunkZ, primer);
        }
        if (this.areStructuresEnabled()) {
            if (this.endCityGen != null) {
                this.endCityGen.generate(this.world, chunkX, chunkZ, primer);
            }
            this.moddedStructures.forEach(structure -> structure.generate(this.world, chunkX, chunkZ, primer));
        }
        final Chunk chunk = new Chunk(this.world, primer, chunkX, chunkZ);
        final byte[] biomeArray = chunk.getBiomeArray();
        for (int i = 0; i < biomeArray.length; ++i) {
            biomeArray[i] = (byte)Biome.getIdForBiome(this.biomesForGeneration[i]);
        }
        chunk.generateSkylightMap();
        return chunk;
    }
    
    public void populate(final int chunkX, final int chunkZ) {
        final boolean prevFixVanillaCascading = ForgeModContainer.fixVanillaCascading;
        ForgeModContainer.fixVanillaCascading = true;
        final BlockPos pos = new BlockPos(chunkX << 4, 0, chunkZ << 4);
        final Biome biome = this.world.getBiome(pos.add(16, 0, 16));
        final ChunkPos chunkPos = new ChunkPos(chunkX, chunkZ);
        this.moddedStructures.forEach(structure -> structure.generateStructure(this.world, this.rand, chunkPos));
        if (!(biome instanceof IEndBiome)) {
            this.populateWithVanilla(chunkX, chunkZ);
        }
        else {
            BlockFalling.fallInstantly = true;
            if (this.endCityGen != null) {
                this.endCityGen.generateStructure(this.world, this.rand, chunkPos);
            }
            ((IEndBiome)biome).populate(this, chunkX, chunkZ);
            BlockFalling.fallInstantly = false;
        }
        ForgeModContainer.fixVanillaCascading = prevFixVanillaCascading;
    }
    
    public void populateWithVanilla(final int chunkX, final int chunkZ) {
        ForgeEventFactory.onChunkPopulate(BlockFalling.fallInstantly = true, (IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false);
        if (this.areStructuresEnabled()) {
            this.endCityGen.generateStructure(this.world, this.rand, new ChunkPos(chunkX, chunkZ));
        }
        final BlockPos pos = new BlockPos(chunkX << 4, 0, chunkZ << 4);
        final Biome biome = this.world.getBiome(pos.add(16, 0, 16));
        if (chunkX * (long)chunkX + chunkZ * (long)chunkZ > 4096L) {
            final float height = this.getIslandHeightValue(chunkX, chunkZ, 1, 1);
            if ((!(biome instanceof IEndBiome) || ((IEndBiome)biome).generateIslands(this, chunkX, chunkZ, height)) && height < -20.0f && this.rand.nextInt(14) == 0) {
                this.endIslands.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, 55 + this.rand.nextInt(16), this.rand.nextInt(16) + 8));
                if (this.rand.nextInt(4) == 0) {
                    this.endIslands.generate(this.world, this.rand, pos.add(this.rand.nextInt(16) + 8, 55 + this.rand.nextInt(16), this.rand.nextInt(16) + 8));
                }
            }
            if ((!(biome instanceof IEndBiome) || ((IEndBiome)biome).generateChorusPlants(this, chunkX, chunkZ, height)) && height > 40.0f) {
                for (int amountInChunk = this.rand.nextInt(5), i = 0; i < amountInChunk; ++i) {
                    final int xOffset = this.rand.nextInt(16) + 8;
                    final int zOffset = this.rand.nextInt(16) + 8;
                    final int y = this.world.getHeight(pos.add(xOffset, 0, zOffset)).getY();
                    if (y > 0 && this.world.isAirBlock(pos.add(xOffset, y, zOffset))) {
                        final IBlockState ground = this.world.getBlockState(pos.add(xOffset, y - 1, zOffset));
                        if (ground == ChunkGeneratorTheEnd.END_STONE) {
                            BlockChorusFlower.generatePlant(this.world, pos.add(xOffset, y, zOffset), this.rand, 8);
                        }
                    }
                }
            }
            if (height > 40.0f && this.rand.nextInt(700) == 0) {
                final int xOffset2 = this.rand.nextInt(16) + 8;
                final int zOffset2 = this.rand.nextInt(16) + 8;
                final int blockHeight = this.world.getHeight(pos.add(xOffset2, 0, zOffset2)).getY();
                if (blockHeight > 0) {
                    final BlockPos offset = pos.add(xOffset2, blockHeight + 3 + this.rand.nextInt(7), zOffset2);
                    WorldProviderTheEnd.END_GATEWAY.generate(this.world, this.rand, offset);
                    final TileEntity tile = this.world.getTileEntity(offset);
                    if (tile instanceof TileEntityEndGateway) {
                        ((TileEntityEndGateway)tile).setExactPosition(this.spawnPoint);
                    }
                }
            }
        }
        biome.decorate(this.world, this.rand, pos);
        ForgeEventFactory.onChunkPopulate(false, (IChunkGenerator)this, this.world, this.rand, chunkX, chunkZ, false);
        BlockFalling.fallInstantly = false;
    }
    
    @Nonnull
    public List<Biome.SpawnListEntry> getPossibleCreatures(@Nonnull final EnumCreatureType creatureType, @Nonnull final BlockPos pos) {
        if (this.areStructuresEnabled()) {
            for (final MapGenStructure structure : this.moddedStructures) {
                if (structure instanceof ISpawningStructure) {
                    final List<Biome.SpawnListEntry> possibleCreatures = ((ISpawningStructure)structure).getPossibleCreatures(creatureType, this.world, pos);
                    if (!possibleCreatures.isEmpty()) {
                        return possibleCreatures;
                    }
                    continue;
                }
            }
        }
        return (List<Biome.SpawnListEntry>)this.world.getBiome(pos).getSpawnableList(creatureType);
    }
    
    @Nullable
    public BlockPos getNearestStructurePos(@Nonnull final World worldIn, @Nonnull final String structureName, @Nonnull final BlockPos position, final boolean findUnexplored) {
        if (this.areStructuresEnabled()) {
            if ("EndCity".equals(structureName) && this.endCityGen != null) {
                return this.endCityGen.getNearestStructurePos(worldIn, position, findUnexplored);
            }
            for (final MapGenStructure structure : this.moddedStructures) {
                if (structure.getStructureName().equals(structureName)) {
                    return structure.getNearestStructurePos(worldIn, position, findUnexplored);
                }
            }
        }
        return null;
    }
    
    public boolean isInsideStructure(@Nonnull final World worldIn, @Nonnull final String structureName, @Nonnull final BlockPos pos) {
        if (this.areStructuresEnabled()) {
            if ("EndCity".equals(structureName) && this.endCityGen != null) {
                return this.endCityGen.isInsideStructure(pos);
            }
            for (final MapGenStructure structure : this.moddedStructures) {
                if (structure.getStructureName().equals(structureName)) {
                    return structure.isInsideStructure(pos);
                }
            }
        }
        return false;
    }
    
    public void recreateStructures(@Nonnull final Chunk chunkIn, final int x, final int z) {
        if (this.areStructuresEnabled()) {
            this.moddedStructures.forEach(structure -> structure.generate(this.world, x, z, (ChunkPrimer)null));
        }
    }
    
    @Nonnull
    public World getWorld() {
        return this.world;
    }
    
    @Nonnull
    public Random getRand() {
        return this.rand;
    }
    
    public boolean areStructuresEnabled() {
        return this.mapFeaturesEnabled;
    }
    
    public void setBlocksInPrimer(final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer) {
        this.setBlocksInChunk(chunkX, chunkZ, primer);
    }
}
