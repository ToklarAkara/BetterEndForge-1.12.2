package git.jbredwards.nether_api.mod.common.world.gen;

import net.minecraft.world.gen.*;
import net.minecraft.world.*;
import javax.annotation.*;
import net.minecraft.world.chunk.*;
import net.minecraft.util.math.*;

public class MapGenCavesEnd extends MapGenCavesHell
{
    public static boolean generateOnStartIsland;
    public static int chance;
    public static int roomChance;
    
    public void generate(@Nonnull final World worldIn, final int x, final int z, @Nonnull final ChunkPrimer primer) {
        if (MapGenCavesEnd.generateOnStartIsland || x * (long)x + z * (long)z > 2048L) {
            super.generate(worldIn, x, z, primer);
        }
    }
    
    protected void recursiveGenerate(@Nonnull final World worldIn, final int chunkX, final int chunkZ, final int originalX, final int originalZ, @Nonnull final ChunkPrimer chunkPrimerIn) {
        if (this.rand.nextInt(MapGenCavesEnd.chance) == 0) {
            for (int max = this.rand.nextInt(this.rand.nextInt(this.rand.nextInt(10) + 1) + 1), i = 0; i < max; ++i) {
                final double x = (chunkX << 4) + this.rand.nextInt(16);
                final double y = MathHelper.getInt(this.rand, 10, 80);
                final double z = (chunkZ << 4) + this.rand.nextInt(16);
                int tunnels = 1;
                if (this.rand.nextInt(MapGenCavesEnd.roomChance) == 0) {
                    this.addRoom(this.rand.nextLong(), originalX, originalZ, chunkPrimerIn, x, y, z);
                    tunnels += this.rand.nextInt(4);
                }
                for (int j = 0; j < tunnels; ++j) {
                    final float radius = this.rand.nextFloat() * 6.0f;
                    final float direction = this.rand.nextFloat() * 3.1415927f * 2.0f;
                    final float length = (this.rand.nextFloat() - 0.5f) / 4.0f;
                    this.addTunnel(this.rand.nextLong(), originalX, originalZ, chunkPrimerIn, x, y, z, radius, direction, length, 0, 0, 0.5);
                }
            }
        }
    }
    
    static {
        MapGenCavesEnd.generateOnStartIsland = false;
        MapGenCavesEnd.chance = 3;
        MapGenCavesEnd.roomChance = 4;
    }
}
