package git.jbredwards.nether_api.mod.common.compat.netherex;

import logictechcorp.netherex.world.biome.*;
import git.jbredwards.nether_api.api.biome.*;
import git.jbredwards.nether_api.api.block.*;
import logictechcorp.libraryex.*;
import javax.annotation.*;
import net.minecraft.world.biome.*;
import net.minecraft.block.state.*;
import net.minecraft.world.chunk.*;
import logictechcorp.netherex.*;
import logictechcorp.libraryex.world.biome.data.*;
import net.minecraftforge.common.*;
import java.util.function.*;
import java.util.stream.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.util.math.*;
import net.minecraftforge.event.*;
import net.minecraft.world.gen.*;
import logictechcorp.libraryex.event.*;
import net.minecraft.init.*;
import net.minecraft.block.state.pattern.*;
import net.minecraftforge.event.terraingen.*;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.*;
import java.util.*;

public abstract class AbstractNetherExBiome extends BiomeNetherEx implements INetherBiome, INetherAPIBiomeProvider, INetherCarvable
{
    public AbstractNetherExBiome(@Nonnull final IModData data, @Nonnull final Biome.BiomeProperties properties, @Nonnull final String name) {
        super(data, properties, name);
    }
    
    public boolean canNetherCarveThrough(@Nonnull final IBlockState state, @Nonnull final ChunkPrimer primer, final int x, final int y, final int z) {
        final BiomeData biomeData = NetherEx.BIOME_DATA_MANAGER.getBiomeData((Biome)this);
        return state == biomeData.getBiomeBlock(BiomeData.BlockType.SURFACE_BLOCK) || state == biomeData.getBiomeBlock(BiomeData.BlockType.SUBSURFACE_BLOCK);
    }
    
    @Nonnull
    public List<BiomeManager.BiomeEntry> getSubBiomes() {
        return (List<BiomeManager.BiomeEntry>)NetherEx.BIOME_DATA_MANAGER.getBiomeData((Biome)this).getSubBiomes().stream().filter(BiomeData::isEnabled).map(data -> new BiomeManager.BiomeEntry(data.getBiome(), data.getGenerationWeight())).collect(Collectors.toList());
    }
    
    public void buildSurface(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer, final int x, final int z, final double[] soulSandNoise, final double[] gravelNoise, final double[] depthBuffer, final double terrainNoise) {
        final int prevSeaLevel = chunkGenerator.getWorld().getSeaLevel();
        chunkGenerator.getWorld().setSeaLevel(31);
        NetherEx.BIOME_DATA_MANAGER.getBiomeData((Biome)this).generateTerrain(chunkGenerator.getWorld(), chunkGenerator.getRand(), primer, chunkX << 4 | x, chunkZ << 4 | z, terrainNoise);
        chunkGenerator.getWorld().setSeaLevel(prevSeaLevel);
    }
    
    public void populate(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ) {
        final World world = chunkGenerator.getWorld();
        final Random rand = chunkGenerator.getRand();
        final BlockPos pos = new BlockPos(chunkX << 4, 0, chunkZ << 4);
        final ChunkPos chunkPos = new ChunkPos(chunkX, chunkZ);
        ForgeEventFactory.onChunkPopulate(true, (IChunkGenerator)chunkGenerator, world, rand, chunkX, chunkZ, false);
        TerrainGen.populate((IChunkGenerator)chunkGenerator, world, rand, chunkX, chunkZ, false, PopulateChunkEvent.Populate.EventType.CUSTOM);
        ForgeEventFactory.onChunkPopulate(false, (IChunkGenerator)chunkGenerator, world, rand, chunkX, chunkZ, false);
        LibExEventFactory.onPreDecorateBiome(world, rand, chunkPos);
        LibExEventFactory.onDecorateBiome(world, rand, chunkPos, pos, DecorateBiomeEvent.Decorate.EventType.CUSTOM);
        final BiomeData biomeData = NetherEx.BIOME_DATA_MANAGER.getBiomeData((Biome)this);
        if (biomeData != BiomeData.EMPTY && biomeData.useDefaultBiomeDecorations()) {
            this.decorate(world, rand, pos);
        }
        LibExEventFactory.onPostDecorateBiome(world, rand, chunkPos);
        LibExEventFactory.onPreOreGen(world, rand, pos);
        LibExEventFactory.onOreGen(world, rand, (WorldGenerator)new WorldGenMinable(Blocks.AIR.getDefaultState(), 0, (com.google.common.base.Predicate)BlockMatcher.forBlock(Blocks.AIR)), pos, OreGenEvent.GenerateMinable.EventType.CUSTOM);
        LibExEventFactory.onPostOreGen(world, rand, pos);
    }
}
