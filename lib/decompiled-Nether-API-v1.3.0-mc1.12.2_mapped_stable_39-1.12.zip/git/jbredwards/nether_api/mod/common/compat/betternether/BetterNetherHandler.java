package git.jbredwards.nether_api.mod.common.compat.betternether;

import java.lang.reflect.*;
import javax.annotation.*;
import git.jbredwards.nether_api.api.registry.*;
import net.minecraft.world.biome.*;
import net.minecraft.util.*;
import paulevs.betternether.config.*;
import net.minecraftforge.fml.common.*;
import net.minecraftforge.event.*;
import net.minecraftforge.registries.*;
import net.minecraftforge.common.*;
import paulevs.betternether.biomes.*;
import java.util.function.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.init.*;
import net.minecraft.entity.*;
import paulevs.betternether.entities.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.monster.*;
import java.util.*;

public final class BetterNetherHandler
{
    @Nonnull
    static final Set<NetherBiome> GEN_BIOMES;
    @Nonnull
    static final Map<NetherBiome, BiomeBetterNether> BIOME_LOOKUP;
    @Nullable
    static Field legacyEnabledBiomes;
    
    public static void registerBiomes(@Nonnull final INetherAPIRegistry registry) {
        final BiomeBetterNether biome;
        BetterNetherHandler.GEN_BIOMES.forEach(netherBiome -> {
            biome = BetterNetherHandler.BIOME_LOOKUP.get(netherBiome);
            registry.registerBiome((Biome)biome, getWeight(biome));
        });
    }
    
    @Nonnull
    public static BiomeBetterNether getBiomeFromLookup(@Nonnull final NetherBiome netherBiome) {
        final BiomeBetterNether biome = BetterNetherHandler.BIOME_LOOKUP.get(netherBiome);
        if (biome != null) {
            return biome;
        }
        throw new IllegalStateException("No Biome found for BetterNether: {" + netherBiome.getName() + '}');
    }
    
    public static int getWeight(@Nonnull final BiomeBetterNether biome) {
        if (biome.cachedWeight == -1) {
            if (biome.netherBiome instanceof WeightedRandom.Item) {
                biome.cachedWeight = (ConfigLoader.mustInitBiome(biome.netherBiome) ? biome.netherBiome.itemWeight : 0);
            }
            else {
                if (BetterNetherHandler.legacyEnabledBiomes == null) {
                    BetterNetherHandler.legacyEnabledBiomes = ObfuscationReflectionHelper.findField((Class)ConfigLoader.class, "registerBiomes");
                }
                try {
                    biome.cachedWeight = (((boolean[])BetterNetherHandler.legacyEnabledBiomes.get(null))[biome.netherBiomeId] ? 1 : 0);
                }
                catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return biome.cachedWeight;
    }
    
    @SubscribeEvent
    static void registerBiomes(@Nonnull final RegistryEvent.Register<Biome> event) {
        final BiomeBetterNether biome;
        final ObjIntConsumer<NetherBiome> registerAction = (netherBiome, netherBiomeId) -> {
            biome = new BiomeBetterNether(netherBiome, netherBiomeId);
            event.getRegistry().register((IForgeRegistryEntry)biome);
            BetterNetherHandler.BIOME_LOOKUP.put(netherBiome, biome);
            BiomeDictionary.addTypes((Biome)biome, new BiomeDictionary.Type[] { BiomeDictionary.Type.NETHER, BiomeDictionary.Type.HOT, BiomeDictionary.Type.DRY });
            return;
        };
        BetterNetherHandler.GEN_BIOMES.add(BiomeRegister.BIOME_GRAVEL_DESERT);
        BetterNetherHandler.GEN_BIOMES.add(BiomeRegister.BIOME_NETHER_JUNGLE);
        BetterNetherHandler.GEN_BIOMES.add(BiomeRegister.BIOME_WART_FOREST);
        BetterNetherHandler.GEN_BIOMES.add(BiomeRegister.BIOME_GRASSLANDS);
        BetterNetherHandler.GEN_BIOMES.add(BiomeRegister.BIOME_MUSHROOM_FOREST);
        registerAction.accept(BiomeRegister.BIOME_EMPTY_NETHER, 0);
        registerAction.accept(BiomeRegister.BIOME_GRAVEL_DESERT, 1);
        registerAction.accept(BiomeRegister.BIOME_NETHER_JUNGLE, 2);
        registerAction.accept(BiomeRegister.BIOME_WART_FOREST, 3);
        registerAction.accept(BiomeRegister.BIOME_GRASSLANDS, 4);
        registerAction.accept(BiomeRegister.BIOME_MUSHROOM_FOREST, 5);
        registerAction.accept(BiomeRegister.BIOME_MUSHROOM_FOREST_EDGE, 6);
        registerAction.accept(BiomeRegister.BIOME_WART_FOREST_EDGE, 7);
        registerAction.accept(BiomeRegister.BIOME_BONE_REEF, 8);
        registerAction.accept(BiomeRegister.BIOME_POOR_GRASSLANDS, 9);
    }
    
    public static void init() {
        Biomes.HELL.getSpawnableList(EnumCreatureType.AMBIENT).removeIf(entry -> entry.entityClass == EntityFirefly.class);
        EntityRegistry.addSpawn((Class)EntityFirefly.class, 100, 5, 10, EnumCreatureType.AMBIENT, new Biome[] { (Biome)getBiomeFromLookup(BiomeRegister.BIOME_GRASSLANDS), (Biome)getBiomeFromLookup(BiomeRegister.BIOME_NETHER_JUNGLE) });
        getBiomeFromLookup(BiomeRegister.BIOME_GRAVEL_DESERT).getSpawnableList(EnumCreatureType.MONSTER).removeIf(entry -> EntityGhast.class.isAssignableFrom(entry.entityClass));
    }
    
    static {
        GEN_BIOMES = new HashSet<NetherBiome>();
        BIOME_LOOKUP = new HashMap<NetherBiome, BiomeBetterNether>();
    }
}
