package git.jbredwards.nether_api.mod.common.compat.biomesoplenty;

import net.minecraft.world.*;
import javax.annotation.*;
import git.jbredwards.nether_api.mod.common.config.*;
import biomesoplenty.common.world.*;
import git.jbredwards.nether_api.api.registry.*;
import biomesoplenty.api.enums.*;
import biomesoplenty.api.biome.*;
import net.minecraft.world.biome.*;

public final class BiomesOPlentyHandler
{
    public static boolean allowBOPNetherBiomes(@Nonnull final World world) {
        return !NetherAPIConfig.BOP.dependentBOPHellBiomes || world.getWorldType() instanceof WorldTypeBOP;
    }
    
    public static void registerBiomes(@Nonnull final INetherAPIRegistry registry, @Nonnull final World world) {
        if (allowBOPNetherBiomes(world)) {
            final IExtendedBiome extended;
            BOPBiomes.REG_INSTANCE.getPresentBiomes().forEach(biome -> {
                extended = BOPBiomes.REG_INSTANCE.getExtendedBiome(biome);
                if (extended != null) {
                    registry.registerBiome(biome, extended.getWeightMap().getOrDefault(BOPClimates.HELL, 0));
                }
            });
        }
    }
}
