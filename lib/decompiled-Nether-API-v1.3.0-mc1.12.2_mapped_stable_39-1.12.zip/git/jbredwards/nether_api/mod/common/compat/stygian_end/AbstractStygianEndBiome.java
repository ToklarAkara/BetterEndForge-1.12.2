package git.jbredwards.nether_api.mod.common.compat.stygian_end;

import git.jbredwards.nether_api.api.biome.*;
import net.minecraft.world.biome.*;
import javax.annotation.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.world.chunk.*;
import net.minecraft.block.material.*;
import net.minecraft.init.*;
import net.minecraft.block.state.*;
import fluke.stygian.world.*;
import git.jbredwards.nether_api.mod.common.config.*;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.util.math.*;
import fluke.stygian.block.*;

public abstract class AbstractStygianEndBiome extends BiomeEnd implements IEndBiome
{
    public AbstractStygianEndBiome(@Nonnull final Biome.BiomeProperties properties) {
        super(properties);
    }
    
    public void buildSurface(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer, final int x, final int z, final double terrainNoise) {
        int currDepth = -1;
        for (int y = chunkGenerator.getWorld().getActualHeight() - 1; y >= 0; --y) {
            final IBlockState here = primer.getBlockState(x, y, z);
            if (here.getMaterial() == Material.AIR) {
                currDepth = -1;
            }
            else if (here.getBlock() == Blocks.END_STONE) {
                if (currDepth == -1) {
                    currDepth = 3 + chunkGenerator.getRand().nextInt(2);
                    primer.setBlockState(x, y, z, this.topBlock);
                }
                else if (currDepth > 0) {
                    --currDepth;
                    primer.setBlockState(x, y, z, this.fillerBlock);
                }
            }
        }
    }
    
    public boolean generateChorusPlants(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, final float islandHeight) {
        return (this == BiomeRegistrar.END_JUNGLE) ? NetherAPIConfig.StygianEnd.endJungleChorusPlants : NetherAPIConfig.StygianEnd.endVolcanoChorusPlants;
    }
    
    public boolean generateEndCity(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, final int islandHeight) {
        return islandHeight >= 60 && ((this != BiomeRegistrar.END_JUNGLE) ? NetherAPIConfig.StygianEnd.endVolcanoEndCity : NetherAPIConfig.StygianEnd.endJungleEndCity);
    }
    
    public boolean generateIslands(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, final float islandHeight) {
        if (this != BiomeRegistrar.END_VOLCANO) {
            return islandHeight < -25.0f;
        }
        if (chunkGenerator.getRand().nextBoolean()) {
            if (islandHeight < -20.0f && chunkGenerator.getRand().nextInt(14) == 0) {
                final WorldGenerator feature = new WorldGenerator() {
                    public boolean generate(@Nonnull final World worldIn, @Nonnull final Random rand, @Nonnull final BlockPos position) {
                        float radius = (float)(rand.nextInt(3) + 4);
                        for (int y = 0; radius > 0.5; radius -= (float)(rand.nextInt(2) + 0.5), --y) {
                            for (int x = MathHelper.floor(-radius); x <= MathHelper.ceil(radius); ++x) {
                                for (int z = MathHelper.floor(-radius); z <= MathHelper.ceil(radius); ++z) {
                                    if (x * x + z * z <= (radius + 1.0f) * (radius + 1.0f)) {
                                        this.setBlockAndNotifyAdequately(worldIn, position.add(x, y, z), ModBlocks.endObsidian.getDefaultState());
                                    }
                                }
                            }
                        }
                        return true;
                    }
                };
                feature.generate(chunkGenerator.getWorld(), chunkGenerator.getRand(), new BlockPos((chunkX << 4) + chunkGenerator.getRand().nextInt(16) + 8, chunkGenerator.getRand().nextInt(16) + 55, (chunkZ << 4) + chunkGenerator.getRand().nextInt(16) + 8));
                if (chunkGenerator.getRand().nextInt(4) == 0) {
                    feature.generate(chunkGenerator.getWorld(), chunkGenerator.getRand(), new BlockPos((chunkX << 4) + chunkGenerator.getRand().nextInt(16) + 8, chunkGenerator.getRand().nextInt(16) + 55, (chunkZ << 4) + chunkGenerator.getRand().nextInt(16) + 8));
                }
            }
            return false;
        }
        return true;
    }
}
