package git.jbredwards.nether_api.mod.common.compat.netherex;

import net.minecraft.world.chunk.*;
import javax.annotation.*;
import logictechcorp.libraryex.event.*;
import git.jbredwards.nether_api.api.registry.*;
import logictechcorp.netherex.init.*;
import net.minecraft.world.biome.*;
import logictechcorp.netherex.*;
import logictechcorp.libraryex.world.biome.data.*;
import net.minecraft.entity.*;
import java.util.*;

public final class NetherExHandler
{
    public static boolean doesXZShowFog() {
        return !NetherExConfig.client.visual.disableNetherFog;
    }
    
    public static boolean doesGravelGenerate() {
        return NetherExConfig.dimension.nether.generateGravel;
    }
    
    public static boolean doesSoulSandGenerate() {
        return NetherExConfig.dimension.nether.generateSoulSand;
    }
    
    public static void onChunkGenerate(@Nonnull final Chunk chunk) {
        LibExEventFactory.onChunkGenerate(chunk);
    }
    
    public static void registerBiomes(@Nonnull final INetherAPIRegistry registry) {
        registerBiome(registry, (Biome)NetherExBiomes.ARCTIC_ABYSS);
        registerBiome(registry, (Biome)NetherExBiomes.FUNGI_FOREST);
        registerBiome(registry, (Biome)NetherExBiomes.RUTHLESS_SANDS);
        registerBiome(registry, (Biome)NetherExBiomes.TORRID_WASTELAND);
    }
    
    static void registerBiome(@Nonnull final INetherAPIRegistry registry, @Nonnull final Biome biome) {
        final BiomeData biomeData = NetherEx.BIOME_DATA_MANAGER.getBiomeData(biome);
        if (biomeData.isEnabled()) {
            registry.registerBiome(biome, biomeData.getGenerationWeight());
        }
    }
    
    @Nonnull
    public static List<Biome.SpawnListEntry> getSpawnableList(@Nonnull final Biome biome, @Nonnull final EnumCreatureType creatureType) {
        final List<Biome.SpawnListEntry> spawns = new ArrayList<Biome.SpawnListEntry>(biome.getSpawnableList(creatureType));
        final BiomeData biomeData = NetherEx.BIOME_DATA_MANAGER.getBiomeData(biome);
        if (biomeData != BiomeData.EMPTY) {
            spawns.addAll(biomeData.getEntitySpawns(creatureType));
        }
        return spawns;
    }
}
