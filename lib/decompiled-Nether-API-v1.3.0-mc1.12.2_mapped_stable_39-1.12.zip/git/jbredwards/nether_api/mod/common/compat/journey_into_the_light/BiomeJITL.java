package git.jbredwards.nether_api.mod.common.compat.journey_into_the_light;

import git.jbredwards.nether_api.api.biome.*;
import java.lang.reflect.*;
import net.journey.dimension.nether.biomes.*;
import javax.annotation.*;
import net.minecraft.world.biome.*;
import net.minecraftforge.common.*;
import java.util.*;
import java.util.stream.*;
import net.minecraftforge.fml.common.*;

public final class BiomeJITL extends BiomeHell implements INetherAPIBiomeProvider
{
    @Nonnull
    static final Field SUBBIOMES_FIELD;
    @Nonnull
    public final Class<? extends NetherBiome> netherBiomeClass;
    @Nullable
    public NetherBiome netherBiome;
    
    BiomeJITL(@Nonnull final Class<? extends NetherBiome> netherBiomeClassIn, @Nonnull final String nameIn) {
        super(new Biome.BiomeProperties(nameIn).setTemperature(2.0f).setRainfall(0.0f).setRainDisabled());
        this.setRegistryName("nether_api", "journey_into_the_light_" + netherBiomeClassIn.getSimpleName());
        this.netherBiomeClass = netherBiomeClassIn;
    }
    
    @Nonnull
    public List<BiomeManager.BiomeEntry> getEdgeBiomes(final int neighborBiomeId) {
        if (this.netherBiome == null) {
            throw new IllegalStateException("Attempted to generate unregistered JITL biome: {" + this.netherBiomeClass.getSimpleName() + '}');
        }
        final NetherBiome edge = this.netherBiome.getEdge();
        if (edge == this.netherBiome) {
            return Collections.emptyList();
        }
        final Biome neighborBiome = Biome.getBiomeForId(neighborBiomeId);
        if (neighborBiome == this) {
            return Collections.emptyList();
        }
        for (final BiomeManager.BiomeEntry entry : this.getSubBiomes()) {
            if (entry.biome == neighborBiome) {
                return Collections.emptyList();
            }
        }
        return Collections.singletonList(new BiomeManager.BiomeEntry((Biome)JITLHandler.getBiomeFromLookup(edge), 1));
    }
    
    @Nonnull
    public List<BiomeManager.BiomeEntry> getSubBiomes() {
        if (this.netherBiome == null) {
            throw new IllegalStateException("Attempted to generate unregistered JITL biome: {" + this.netherBiomeClass.getSimpleName() + '}');
        }
        return Collections.unmodifiableList((List<? extends BiomeManager.BiomeEntry>)getSubNetherBiomes(this.netherBiome).stream().map(biome -> new BiomeManager.BiomeEntry((Biome)JITLHandler.getBiomeFromLookup(biome), 1)).collect((Collector<? super Object, ?, List<? extends T>>)Collectors.toList()));
    }
    
    @Nonnull
    public static List<NetherBiome> getSubNetherBiomes(@Nonnull final NetherBiome netherBiome) {
        try {
            return (List<NetherBiome>)BiomeJITL.SUBBIOMES_FIELD.get(netherBiome);
        }
        catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
    
    static {
        SUBBIOMES_FIELD = ObfuscationReflectionHelper.findField((Class)NetherBiome.class, "subbiomes");
    }
}
