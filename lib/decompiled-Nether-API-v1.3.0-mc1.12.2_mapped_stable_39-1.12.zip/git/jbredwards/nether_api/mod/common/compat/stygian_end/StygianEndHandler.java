package git.jbredwards.nether_api.mod.common.compat.stygian_end;

import git.jbredwards.nether_api.api.registry.*;
import javax.annotation.*;
import fluke.stygian.world.*;
import git.jbredwards.nether_api.mod.common.config.*;
import fluke.stygian.world.biomes.*;
import fluke.stygian.world.feature.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.gen.*;
import git.jbredwards.nether_api.mod.common.world.gen.*;
import fluke.stygian.block.*;
import net.minecraftforge.fml.relauncher.*;
import fluke.stygian.config.*;
import net.minecraft.world.biome.*;
import net.minecraft.util.*;
import fluke.stygian.*;
import net.minecraft.world.gen.feature.*;

public final class StygianEndHandler
{
    public static void registerBiomes(@Nonnull final INetherAPIRegistry registry) {
        try {
            registerBiomesUnofficial(registry);
        }
        catch (ReflectiveOperationException ex) {}
        catch (IncompatibleClassChangeError incompatibleClassChangeError) {}
        registry.registerBiome(BiomeRegistrar.END_JUNGLE, NetherAPIConfig.StygianEnd.endJungleWeight);
        registry.registerBiome(BiomeRegistrar.END_VOLCANO, NetherAPIConfig.StygianEnd.endVolcanoWeight);
    }
    
    public static void init() {
        ((BiomeEndJungle)BiomeRegistrar.END_JUNGLE).endCanopyTree = (WorldGenerator)new WorldGenEnderCanopy(false) {
            public boolean generate(@Nonnull final World world, @Nonnull final Random rand, @Nonnull final BlockPos pos) {
                return (!(world.getChunkProvider() instanceof ChunkProviderServer) || !(((ChunkProviderServer)world.getChunkProvider()).chunkGenerator instanceof ChunkGeneratorTheEnd) || ((ChunkGeneratorTheEnd)((ChunkProviderServer)world.getChunkProvider()).chunkGenerator).getIslandHeightValue(pos.getX() >> 4, pos.getZ() >> 4, 1, 1) >= 25.0f) && super.generate(world, rand, pos);
            }
        };
    }
    
    @SideOnly(Side.CLIENT)
    public static void initClient() {
        ModBlocks.endLeaves.setGraphicsLevel(true);
    }
    
    static void registerBiomesUnofficial(@Nonnull final INetherAPIRegistry registry) throws ReflectiveOperationException, IncompatibleClassChangeError {
        if (Configs.worldgen.biomeIDs.length > Configs.worldgen.biomeWeights.length) {
            throw new IllegalStateException("Found missing end biome weights in Stygian End Unofficial config!");
        }
        for (int i = 0; i < Configs.worldgen.biomeIDs.length; ++i) {
            final Biome biome = (Biome)Biome.REGISTRY.getObject((Object)new ResourceLocation(Configs.worldgen.biomeIDs[i]));
            if (biome == null) {
                Stygian.LOGGER.warn("Biome not found with ID: " + Configs.worldgen.biomeIDs[i] + ", skipping...");
            }
            else {
                registry.registerBiome(biome, Configs.worldgen.biomeWeights[i]);
            }
        }
    }
}
