package git.jbredwards.nether_api.mod.common.compat.journey_into_the_light;

import javax.annotation.*;
import git.jbredwards.nether_api.api.registry.*;
import git.jbredwards.nether_api.mod.common.config.*;
import net.minecraft.world.biome.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import net.minecraftforge.fml.common.registry.*;
import net.journey.entity.mob.nether.*;
import net.minecraftforge.event.*;
import net.minecraftforge.registries.*;
import net.minecraftforge.common.*;
import net.journey.dimension.nether.biomes.*;
import java.util.function.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.event.terraingen.*;
import net.minecraft.block.*;
import net.journey.dimension.nether.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.block.material.*;
import net.minecraft.world.chunk.*;
import net.journey.dimension.nether.biomes.structure.*;
import java.lang.reflect.*;
import java.util.*;
import net.minecraftforge.fml.common.*;

public final class JITLHandler
{
    @Nonnull
    static final Map<Class<? extends NetherBiome>, BiomeJITL> BIOME_LOOKUP;
    @Nonnull
    static final Method DOWN_RAY_METHOD;
    @Nonnull
    static final Field PLANT_DENSITY_FIELD;
    
    public static void registerBiomes(@Nonnull final INetherAPIRegistry registry) {
        if (BiomeRegister.BIOME_FOREST != null) {
            registry.registerBiome((Biome)getBiomeFromLookup(BiomeRegister.BIOME_FOREST), NetherAPIConfig.JITL.bloodForestWeight);
        }
        if (BiomeRegister.BIOME_EARTHEN != null) {
            registry.registerBiome((Biome)getBiomeFromLookup(BiomeRegister.BIOME_EARTHEN), NetherAPIConfig.JITL.earthenSeepWeight);
        }
        if (BiomeRegister.BIOME_HEAT_SANDS != null) {
            registry.registerBiome((Biome)getBiomeFromLookup(BiomeRegister.BIOME_HEAT_SANDS), NetherAPIConfig.JITL.heatSandsWeight);
        }
    }
    
    public static void init() {
        if (BiomeRegister.BIOME_EMPTY_NETHER != null) {
            getBiomeFromLookup(BiomeRegister.BIOME_EMPTY_NETHER).netherBiome = BiomeRegister.BIOME_EMPTY_NETHER;
        }
        if (BiomeRegister.BIOME_FOREST != null) {
            getBiomeFromLookup(BiomeRegister.BIOME_FOREST).netherBiome = BiomeRegister.BIOME_FOREST;
        }
        if (BiomeRegister.BIOME_EARTHEN != null) {
            getBiomeFromLookup(BiomeRegister.BIOME_EARTHEN).netherBiome = BiomeRegister.BIOME_EARTHEN;
        }
        if (BiomeRegister.BIOME_HEAT_SANDS != null) {
            getBiomeFromLookup(BiomeRegister.BIOME_HEAT_SANDS).netherBiome = BiomeRegister.BIOME_HEAT_SANDS;
        }
        if (BiomeRegister.BIOME_FOREST_EDGE != null) {
            getBiomeFromLookup(BiomeRegister.BIOME_FOREST_EDGE).netherBiome = BiomeRegister.BIOME_FOREST_EDGE;
        }
        EntityRegistry.removeSpawn((Class)EntityLavasnake.class, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        EntityRegistry.removeSpawn((Class)EntityWitherspine.class, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        EntityRegistry.removeSpawn((Class)EntityReaper.class, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        EntityRegistry.removeSpawn((Class)EntityHellCow.class, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        EntityRegistry.removeSpawn((Class)EntityMiniGhast.class, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        EntityRegistry.removeSpawn((Class)EntityInfernoBlaze.class, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        EntityRegistry.removeSpawn((Class)EntityHellTurtle.class, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        if (BiomeRegister.BIOME_FOREST != null) {
            final BiomeJITL biome = getBiomeFromLookup(BiomeRegister.BIOME_FOREST);
            EntityRegistry.addSpawn((Class)EntityHellCow.class, 15, 1, 1, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
            EntityRegistry.addSpawn((Class)EntityMiniGhast.class, 3, 1, 1, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
            EntityRegistry.addSpawn((Class)EntityInfernoBlaze.class, 2, 1, 2, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
        }
        if (BiomeRegister.BIOME_EARTHEN != null) {
            final BiomeJITL biome = getBiomeFromLookup(BiomeRegister.BIOME_EARTHEN);
            EntityRegistry.addSpawn((Class)EntityWitherspine.class, 8, 1, 1, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
            EntityRegistry.addSpawn((Class)EntityReaper.class, 8, 1, 1, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
        }
        if (BiomeRegister.BIOME_HEAT_SANDS != null) {
            final BiomeJITL biome = getBiomeFromLookup(BiomeRegister.BIOME_HEAT_SANDS);
            EntityRegistry.addSpawn((Class)EntityLavasnake.class, 15, 1, 1, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
            EntityRegistry.addSpawn((Class)EntityHellTurtle.class, 15, 1, 2, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
        }
        if (BiomeRegister.BIOME_FOREST_EDGE != null) {
            final BiomeJITL biome = getBiomeFromLookup(BiomeRegister.BIOME_FOREST_EDGE);
            EntityRegistry.addSpawn((Class)EntityHellCow.class, 15, 1, 1, EnumCreatureType.MONSTER, new Biome[] { (Biome)biome });
        }
    }
    
    @Nonnull
    public static BiomeJITL getBiomeFromLookup(@Nonnull final NetherBiome netherBiome) {
        final BiomeJITL biome = JITLHandler.BIOME_LOOKUP.get(netherBiome.getClass());
        if (biome != null) {
            return biome;
        }
        throw new IllegalStateException("No Biome found for Journey Into The Light: {" + netherBiome.getName() + '}');
    }
    
    @SubscribeEvent
    static void registerBiomes(@Nonnull final RegistryEvent.Register<Biome> event) {
        final BiomeJITL biome;
        final BiConsumer<Class<? extends NetherBiome>, String> registerAction = (netherBiomeClass, biomeName) -> {
            biome = new BiomeJITL(netherBiomeClass, biomeName);
            event.getRegistry().register((IForgeRegistryEntry)biome);
            JITLHandler.BIOME_LOOKUP.put(netherBiomeClass, biome);
            BiomeDictionary.addTypes((Biome)biome, new BiomeDictionary.Type[] { BiomeDictionary.Type.NETHER, BiomeDictionary.Type.HOT, BiomeDictionary.Type.DRY });
            return;
        };
        registerAction.accept(NetherBiome.class, "Empty Nether");
        registerAction.accept((Class<? extends NetherBiome>)NetherBiomeForest.class, "Blood Forest");
        registerAction.accept((Class<? extends NetherBiome>)NetherBiomeEarthen.class, "Earthen Seep");
        registerAction.accept((Class<? extends NetherBiome>)NetherBiomeHeatSands.class, "Heat Sands");
        registerAction.accept((Class<? extends NetherBiome>)NetherBiomeForestEdge.class, "Blood Forest Edge");
    }
    
    @SubscribeEvent
    static void globalNetherPopulations(@Nonnull final PopulateChunkEvent.Post event) throws InvocationTargetException, IllegalAccessException {
        if (event.getWorld().provider.getDimensionType() == DimensionType.NETHER && event.getWorld().getWorldType() != WorldType.DEBUG_ALL_BLOCK_STATES) {
            BlockFalling.fallInstantly = true;
            if ((JNWorldGenerator.globalStructuresLand.length != 0 || JNWorldGenerator.globalStructuresLava.length != 0 || JNWorldGenerator.globalStructuresCave.length != 0) && event.getRand().nextInt(16) == 0) {
                final int x = (event.getChunkX() << 4) + event.getRand().nextInt(16) + 8;
                final int z = (event.getChunkZ() << 4) + event.getRand().nextInt(16) + 8;
                final BlockPos.MutableBlockPos start = new BlockPos.MutableBlockPos(x, MathHelper.getInt(event.getRand(), 32, event.getWorld().getActualHeight() - 40), z);
                final Chunk chunk = event.getWorld().getChunk((BlockPos)start);
                while (start.getY() > 32 && !chunk.getBlockState((BlockPos)start).getBlock().isAir(chunk.getBlockState((BlockPos)start), (IBlockAccess)event.getWorld(), (BlockPos)start)) {
                    start.setY(start.getY() - 1);
                }
                final BlockPos rayPos = (BlockPos)JITLHandler.DOWN_RAY_METHOD.invoke(null, chunk, start);
                if (rayPos != null) {
                    boolean terrain = true;
                    for (int y = 1; y < 8; ++y) {
                        if (!chunk.getBlockState(rayPos.up(y)).getBlock().isAir(chunk.getBlockState(rayPos.up(y)), (IBlockAccess)event.getWorld(), rayPos.up(y))) {
                            terrain = false;
                            break;
                        }
                    }
                    if (terrain) {
                        if (JNWorldGenerator.globalStructuresLava.length != 0 && chunk.getBlockState(rayPos).getMaterial() == Material.LAVA) {
                            final IStructureWorld structure = JNWorldGenerator.globalStructuresLava[event.getRand().nextInt(JNWorldGenerator.globalStructuresLava.length)];
                            structure.generateSurface(event.getWorld(), rayPos.up(), event.getRand());
                        }
                        else if (JNWorldGenerator.globalStructuresLand.length != 0) {
                            final IStructureWorld structure = JNWorldGenerator.globalStructuresLand[event.getRand().nextInt(JNWorldGenerator.globalStructuresLand.length)];
                            structure.generateSurface(event.getWorld(), rayPos.up(), event.getRand());
                        }
                    }
                    else if (JNWorldGenerator.globalStructuresCave.length != 0) {
                        final IStructureWorld structure = JNWorldGenerator.globalStructuresCave[event.getRand().nextInt(JNWorldGenerator.globalStructuresCave.length)];
                        structure.generateSubterrain(event.getWorld(), rayPos, event.getRand());
                    }
                }
            }
            float plantDensity;
            try {
                plantDensity = JITLHandler.PLANT_DENSITY_FIELD.getFloat(null);
            }
            catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
            final Chunk chunk2 = event.getWorld().getChunk(event.getChunkX(), event.getChunkZ());
            final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(chunk2.x << 4, 0, chunk2.z << 4);
            BlockPos.MutableBlockPos mutableBlockPos2;
            for (int x2 = 0; x2 < 16; ++x2, mutableBlockPos2 = pos, ++mutableBlockPos2.x) {
                BlockPos.MutableBlockPos mutableBlockPos;
                for (int z2 = 0; z2 < 16; ++z2, mutableBlockPos = pos, ++mutableBlockPos.z) {
                    final Biome biome = chunk2.getBiome((BlockPos)pos, event.getWorld().getBiomeProvider());
                    if (biome instanceof BiomeJITL) {
                        final NetherBiome netherBiome = ((BiomeJITL)biome).netherBiome;
                        if (netherBiome != null) {
                            for (int y2 = 5; y2 < event.getWorld().getActualHeight() - 5; ++y2) {
                                pos.setY(y2);
                                if (chunk2.getBlockState((BlockPos)pos).isFullCube()) {
                                    final Material above = chunk2.getBlockState(pos.up()).getMaterial();
                                    if (!above.isLiquid() && !above.isSolid()) {
                                        netherBiome.genSurfColumn(chunk2, (BlockPos)pos, event.getRand());
                                        if (event.getRand().nextFloat() < plantDensity) {
                                            netherBiome.genFloorObjects(chunk2, (BlockPos)pos, event.getRand());
                                        }
                                    }
                                    else {
                                        final Material below = chunk2.getBlockState(pos.down()).getMaterial();
                                        if (!below.isLiquid() && !below.isSolid() && event.getRand().nextFloat() < plantDensity) {
                                            netherBiome.genCeilObjects(chunk2, (BlockPos)pos, event.getRand());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            BlockFalling.fallInstantly = false;
        }
    }
    
    static {
        BIOME_LOOKUP = new HashMap<Class<? extends NetherBiome>, BiomeJITL>(5);
        DOWN_RAY_METHOD = ObfuscationReflectionHelper.findMethod((Class)JNWorldGenerator.class, "downRay", (Class)BlockPos.class, new Class[] { Chunk.class, BlockPos.class });
        PLANT_DENSITY_FIELD = ObfuscationReflectionHelper.findField((Class)JNWorldGenerator.class, "plantDensity");
    }
}
