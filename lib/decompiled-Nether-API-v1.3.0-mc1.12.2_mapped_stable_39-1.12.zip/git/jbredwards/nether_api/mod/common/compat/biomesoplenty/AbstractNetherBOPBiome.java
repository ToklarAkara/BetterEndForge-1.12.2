package git.jbredwards.nether_api.mod.common.compat.biomesoplenty;

import biomesoplenty.common.biome.nether.*;
import git.jbredwards.nether_api.api.biome.*;
import git.jbredwards.nether_api.api.block.*;
import javax.annotation.*;
import biomesoplenty.common.biome.*;
import net.minecraft.block.state.*;
import net.minecraft.world.chunk.*;
import git.jbredwards.nether_api.api.world.*;
import net.minecraft.init.*;
import git.jbredwards.nether_api.api.util.*;
import net.minecraft.util.math.*;
import net.minecraftforge.fml.relauncher.*;

public abstract class AbstractNetherBOPBiome extends BOPHellBiome implements INetherBiome, INetherCarvable
{
    public AbstractNetherBOPBiome(@Nonnull final String idName, @Nonnull final BOPBiome.PropsBuilder defaultBuilder) {
        super(idName, defaultBuilder);
    }
    
    public boolean canNetherCarveThrough(@Nonnull final IBlockState state, @Nonnull final ChunkPrimer primer, final int x, final int y, final int z) {
        return this.topBlock == state || this.fillerBlock == state || this.wallBlock == state || this.roofTopBlock == state || this.roofFillerBlock == state;
    }
    
    public void buildSurface(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer, final int x, final int z, final double[] soulSandNoise, final double[] gravelNoise, final double[] depthBuffer, final double terrainNoise) {
        NetherGenerationUtils.buildSurfaceAndSoulSandGravel(chunkGenerator.getWorld(), chunkGenerator.getRand(), primer, x, z, soulSandNoise, gravelNoise, depthBuffer, Blocks.NETHERRACK.getDefaultState(), Blocks.NETHERRACK.getDefaultState(), Blocks.NETHERRACK.getDefaultState(), Blocks.LAVA.getDefaultState());
        this.genTerrainBlocks(chunkGenerator.getWorld(), chunkGenerator.getRand(), primer, chunkZ << 4 | z, chunkX << 4 | x, terrainNoise);
    }
    
    @Nonnull
    @SideOnly(Side.CLIENT)
    public Vec3d getFogColor(final float celestialAngle, final float partialTicks) {
        final int fogColor = this.getFogColor((BlockPos)null);
        if (fogColor != -1) {
            final double r = (fogColor >> 16 & 0xFF) / 255.0;
            final double g = (fogColor >> 8 & 0xFF) / 255.0;
            final double b = (fogColor & 0xFF) / 255.0;
            return new Vec3d(r, g, b);
        }
        return super.getFogColor(celestialAngle, partialTicks);
    }
}
