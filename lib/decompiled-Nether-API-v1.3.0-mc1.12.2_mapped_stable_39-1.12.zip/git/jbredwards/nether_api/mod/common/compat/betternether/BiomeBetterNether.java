package git.jbredwards.nether_api.mod.common.compat.betternether;

import git.jbredwards.nether_api.api.biome.*;
import java.lang.reflect.*;
import javax.annotation.*;
import paulevs.betternether.biomes.*;
import net.minecraft.world.biome.*;
import net.minecraftforge.common.*;
import java.util.stream.*;
import git.jbredwards.nether_api.api.registry.*;
import java.util.*;
import net.minecraftforge.fml.common.*;

public final class BiomeBetterNether extends BiomeHell implements INetherAPIBiomeProvider, INetherAPIRegistryListener
{
    @Nonnull
    static final Field SUBBIOMES_FIELD;
    int cachedWeight;
    @Nonnull
    public final NetherBiome netherBiome;
    public final int netherBiomeId;
    
    BiomeBetterNether(@Nonnull final NetherBiome netherBiomeIn, final int netherBiomeIdIn) {
        super(new Biome.BiomeProperties(netherBiomeIn.getName()).setTemperature(2.0f).setRainfall(0.0f).setRainDisabled());
        this.cachedWeight = -1;
        this.setRegistryName("nether_api", "betternether_" + netherBiomeIn.getClass().getSimpleName());
        this.netherBiome = netherBiomeIn;
        this.netherBiomeId = netherBiomeIdIn;
    }
    
    @Nonnull
    public List<BiomeManager.BiomeEntry> getSubBiomes() {
        final List<NetherBiome> subBiomes = getSubNetherBiomes(this.netherBiome);
        if (subBiomes.isEmpty() || (subBiomes.size() == 1 && subBiomes.get(0) == this.netherBiome)) {
            return Collections.emptyList();
        }
        BiomeManager.BiomeEntry biomeEntry = null;
        return subBiomes.stream().filter(netherBiomeIn -> BetterNetherHandler.getWeight(BetterNetherHandler.getBiomeFromLookup(netherBiomeIn)) > 0).map(netherBiomeIn -> {
            if (netherBiomeIn == this.netherBiome) {
                // new(net.minecraftforge.common.BiomeManager.BiomeEntry.class)
                new BiomeManager.BiomeEntry((Biome)this, 1000);
            }
            else {
                biomeEntry = BetterNetherHandler.getBiomeFromLookup(netherBiomeIn).createBiomeEntry();
            }
            return biomeEntry;
        }).collect((Collector<? super Object, ?, List<BiomeManager.BiomeEntry>>)Collectors.toList());
    }
    
    @Nonnull
    public List<BiomeManager.BiomeEntry> getEdgeBiomes(final int neighborBiomeId) {
        final NetherBiome edge = this.netherBiome.getEdge();
        if (edge == this.netherBiome) {
            return Collections.emptyList();
        }
        final Biome neighborBiome = Biome.getBiomeForId(neighborBiomeId);
        if (neighborBiome == this) {
            return Collections.emptyList();
        }
        for (final BiomeManager.BiomeEntry entry : this.getSubBiomes()) {
            if (entry.biome == neighborBiome) {
                return Collections.emptyList();
            }
        }
        return Collections.singletonList(BetterNetherHandler.getBiomeFromLookup(edge).createBiomeEntry());
    }
    
    @Nonnull
    public static List<NetherBiome> getSubNetherBiomes(@Nonnull final NetherBiome netherBiome) {
        try {
            return (List<NetherBiome>)BiomeBetterNether.SUBBIOMES_FIELD.get(netherBiome);
        }
        catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void onAddedToRegistry(@Nonnull final INetherAPIRegistry registry, @Nonnull final OptionalInt newWeight) {
        if (newWeight.isPresent()) {
            this.cachedWeight = newWeight.getAsInt();
        }
    }
    
    public void onRemovedFromRegistry(@Nonnull final INetherAPIRegistry registry, @Nonnull final OptionalInt oldWeight) {
        this.cachedWeight = -1;
    }
    
    @Nonnull
    public BiomeManager.BiomeEntry createBiomeEntry() {
        return new BiomeManager.BiomeEntry((Biome)this, BetterNetherHandler.getWeight(this));
    }
    
    static {
        SUBBIOMES_FIELD = ObfuscationReflectionHelper.findField((Class)NetherBiome.class, "subbiomes");
    }
}
