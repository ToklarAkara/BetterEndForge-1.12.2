package git.jbredwards.nether_api.mod.common.compat.nethercraft;

import git.jbredwards.nether_api.api.biome.*;
import git.jbredwards.nether_api.api.block.*;
import net.minecraft.world.biome.*;
import com.legacy.nethercraft.blocks.*;
import git.jbredwards.nether_api.api.world.*;
import javax.annotation.*;
import net.minecraft.world.chunk.*;
import net.minecraft.init.*;
import net.minecraft.block.state.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import net.minecraft.world.gen.feature.*;
import com.legacy.nethercraft.world.*;

public final class BiomeNethercraft extends BiomeHell implements INetherBiome, INetherCarvable
{
    public static int minTreeTries;
    public static int maxTreeTries;
    public static int reedTries;
    public static int reedChance;
    public static int mushroomTries;
    public static int purpleMushroomChance;
    public static int greenMushroomChance;
    
    BiomeNethercraft() {
        super(new Biome.BiomeProperties("Glowing Grove").setTemperature(2.0f).setRainfall(0.0f).setRainDisabled());
        this.setRegistryName("nether_api", "nethercraft_glowing_grove");
        this.topBlock = BlocksNether.nether_dirt.getDefaultState();
    }
    
    public void buildSurface(@Nonnull final INetherAPIChunkGenerator chunkGenerator, final int chunkX, final int chunkZ, @Nonnull final ChunkPrimer primer, final int x, final int z, final double[] soulSandNoise, final double[] gravelNoise, final double[] depthBuffer, final double terrainNoise) {
        final boolean soulSand = soulSandNoise[x << 4 | z] + chunkGenerator.getRand().nextDouble() * 0.2 > 0.0;
        final boolean gravel = gravelNoise[x << 4 | z] + chunkGenerator.getRand().nextDouble() * 0.2 > 0.0;
        final int depth = (int)(depthBuffer[x << 4 | z] / 3.0 + 3.0 + chunkGenerator.getRand().nextDouble() * 0.25);
        IBlockState filler = this.topBlock;
        int depthRemaining = -1;
        for (int y = chunkGenerator.getWorld().getActualHeight() - 1; y >= 0; --y) {
            if (y < chunkGenerator.getWorld().getActualHeight() - 1 - chunkGenerator.getRand().nextInt(5) && y > chunkGenerator.getRand().nextInt(5)) {
                if (primer.getBlockState(x, y, z).getBlock() == Blocks.NETHERRACK) {
                    if (depthRemaining == -1) {
                        if (depth <= 0) {
                            filler = Blocks.AIR.getDefaultState();
                        }
                        else if (y > chunkGenerator.getWorld().getSeaLevel() - 4 && y < chunkGenerator.getWorld().getSeaLevel() + 3) {
                            filler = ((gravel || soulSand) ? BlocksNether.heat_sand.getDefaultState() : this.topBlock);
                        }
                        depthRemaining = depth;
                        final int n;
                        primer.setBlockState(x, n, z, ((n = y) >= chunkGenerator.getWorld().getSeaLevel()) ? filler : this.topBlock);
                    }
                    else if (depthRemaining > 0) {
                        --depthRemaining;
                        primer.setBlockState(x, y, z, this.topBlock);
                    }
                }
                else {
                    depthRemaining = -1;
                }
            }
        }
    }
    
    public void decorate(@Nonnull final World worldIn, @Nonnull final Random rand, @Nonnull final BlockPos pos) {
        super.decorate(worldIn, rand, pos);
        final int worldHeight = worldIn.getActualHeight();
        for (int treeTries = MathHelper.getInt(rand, BiomeNethercraft.minTreeTries, BiomeNethercraft.maxTreeTries), i = 0; i < treeTries; ++i) {
            this.getRandomTreeFeature(rand).generate(worldIn, rand, pos.add(rand.nextInt(16) + 8, rand.nextInt(worldHeight - 4) + 4, rand.nextInt(16) + 8));
        }
        if (BiomeNethercraft.reedChance > 0) {
            for (int i = 0; i < BiomeNethercraft.reedTries; ++i) {
                if (rand.nextInt(BiomeNethercraft.reedChance) == 0) {
                    new NetherGenReeds().generate(worldIn, rand, pos.add(rand.nextInt(16) + 8, 32, rand.nextInt(16) + 8));
                }
            }
        }
        if (Math.max(BiomeNethercraft.purpleMushroomChance, BiomeNethercraft.greenMushroomChance) > 0) {
            for (int tries = BiomeNethercraft.mushroomTries, j = 0; j < tries; ++j) {
                BlockPos mushroomPos = null;
                if (BiomeNethercraft.purpleMushroomChance > 0 && rand.nextInt(BiomeNethercraft.purpleMushroomChance) == 0) {
                    new WorldGenBush((BlockBush)BlocksNether.purple_glowshroom).generate(worldIn, rand, mushroomPos = pos.add(rand.nextInt(16) + 8, rand.nextInt(worldHeight - 4) + 4, rand.nextInt(16) + 8));
                }
                if (BiomeNethercraft.greenMushroomChance > 0 && rand.nextInt(BiomeNethercraft.greenMushroomChance) == 0) {
                    new WorldGenBush((BlockBush)BlocksNether.green_glowshroom).generate(worldIn, rand, (mushroomPos != null) ? mushroomPos : pos.add(rand.nextInt(16) + 8, rand.nextInt(worldHeight - 4) + 4, rand.nextInt(16) + 8));
                }
            }
        }
    }
    
    public boolean canNetherCarveThrough(@Nonnull final IBlockState state, @Nonnull final ChunkPrimer primer, final int x, final int y, final int z) {
        return state == this.fillerBlock || state == this.topBlock || state.getBlock() == BlocksNether.heat_sand;
    }
    
    @Nonnull
    public WorldGenAbstractTree getRandomTreeFeature(@Nonnull final Random rand) {
        return (WorldGenAbstractTree)new NetherGenTree();
    }
    
    static {
        BiomeNethercraft.minTreeTries = 35;
        BiomeNethercraft.maxTreeTries = 39;
        BiomeNethercraft.reedTries = 7;
        BiomeNethercraft.reedChance = 10;
        BiomeNethercraft.mushroomTries = 3;
        BiomeNethercraft.purpleMushroomChance = 4;
        BiomeNethercraft.greenMushroomChance = 8;
    }
}
