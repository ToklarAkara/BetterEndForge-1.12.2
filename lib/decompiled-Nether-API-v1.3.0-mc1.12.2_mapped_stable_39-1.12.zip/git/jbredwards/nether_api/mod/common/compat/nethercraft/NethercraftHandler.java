package git.jbredwards.nether_api.mod.common.compat.nethercraft;

import java.lang.reflect.*;
import javax.annotation.*;
import git.jbredwards.nether_api.api.registry.*;
import git.jbredwards.nether_api.mod.common.config.*;
import net.minecraft.world.biome.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import net.minecraftforge.fml.common.registry.*;
import java.util.*;
import java.util.function.*;
import com.legacy.nethercraft.entities.tribal.*;
import com.legacy.nethercraft.entities.hostile.*;
import com.legacy.nethercraft.entities.block.*;
import com.legacy.nethercraft.entities.projectile.*;
import com.legacy.nethercraft.entities.item.*;
import net.minecraftforge.event.*;
import net.minecraftforge.registries.*;
import net.minecraftforge.event.terraingen.*;
import com.legacy.nethercraft.blocks.*;
import com.legacy.nethercraft.world.*;
import net.minecraft.world.gen.feature.*;
import net.minecraftforge.event.entity.living.*;
import net.minecraft.world.*;
import net.minecraft.entity.monster.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.common.*;

public final class NethercraftHandler
{
    @Nonnull
    static final Field TRACKING_RANGE_FIELD;
    @Nonnull
    static final Field UPDATE_FREQUENCY_FIELD;
    @Nonnull
    static final Field SENDS_VELOCITY_UPDATES_FIELD;
    public static BiomeNethercraft GLOWING_GROVE;
    public static int foulitePerChunk;
    public static int fouliteOreSize;
    public static int fouliteMinHeight;
    public static int fouliteMaxHeight;
    public static int neridiumPerChunk;
    public static int neridiumOreSize;
    public static int neridiumMinHeight;
    public static int neridiumMaxHeight;
    public static int liniumPerChunk;
    public static int liniumOreSize;
    public static int liniumMinHeight;
    public static int liniumMaxHeight;
    public static int pyridiumPerChunk;
    public static int pyridiumOreSize;
    public static int pyridiumMinHeight;
    public static int pyridiumMaxHeight;
    public static int wPerChunk;
    public static int wOreSize;
    public static int wMinHeight;
    public static int wMaxHeight;
    
    public static void registerBiomes(@Nonnull final INetherAPIRegistry registry) {
        registry.registerBiome((Biome)NethercraftHandler.GLOWING_GROVE, NetherAPIConfig.Nethercraft.glowingGroveWeight);
    }
    
    public static void init() {
        EntityRegistry.addSpawn((Class)EntityCamouflageSpider.class, 60, 1, 3, EnumCreatureType.MONSTER, new Biome[] { Biomes.HELL });
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityDarkZombie.class, false)).ifPresent(NethercraftHandler::setSendsVelocityUpdates);
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityLavaSlime.class, false)).ifPresent(NethercraftHandler::setSendsVelocityUpdates);
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityCamouflageSpider.class, false)).ifPresent(NethercraftHandler::setSendsVelocityUpdates);
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityImp.class, false)).ifPresent(NethercraftHandler::setSendsVelocityUpdates);
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityTribalTrainee.class, false)).ifPresent(NethercraftHandler::setSendsVelocityUpdates);
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityTribalWarrior.class, false)).ifPresent(NethercraftHandler::setSendsVelocityUpdates);
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityBloodyZombie.class, false)).ifPresent(NethercraftHandler::setSendsVelocityUpdates);
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityGhastBomb.class, false)).ifPresent(entry -> setInt(NethercraftHandler.UPDATE_FREQUENCY_FIELD, entry, 10));
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityLiniumArrow.class, false)).ifPresent(entry -> setInt(NethercraftHandler.UPDATE_FREQUENCY_FIELD, entry, 20));
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityNeridiumArrow.class, false)).ifPresent(entry -> setInt(NethercraftHandler.UPDATE_FREQUENCY_FIELD, entry, 20));
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityNetherArrow.class, false)).ifPresent(entry -> setInt(NethercraftHandler.UPDATE_FREQUENCY_FIELD, entry, 20));
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityPyridiumArrow.class, false)).ifPresent(entry -> setInt(NethercraftHandler.UPDATE_FREQUENCY_FIELD, entry, 20));
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntitySlimeEggs.class, false)).ifPresent(entry -> {
            setInt(NethercraftHandler.UPDATE_FREQUENCY_FIELD, entry, 10);
            setSendsVelocityUpdates(entry);
            return;
        });
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityLavaBoat.class, false)).ifPresent(entry -> {
            setInt(NethercraftHandler.TRACKING_RANGE_FIELD, entry, 80);
            setSendsVelocityUpdates(entry);
            return;
        });
        Optional.ofNullable(EntityRegistry.instance().lookupModSpawn((Class)EntityNPainting.class, false)).ifPresent(entry -> {
            setInt(NethercraftHandler.TRACKING_RANGE_FIELD, entry, 160);
            setInt(NethercraftHandler.UPDATE_FREQUENCY_FIELD, entry, Integer.MAX_VALUE);
        });
    }
    
    static void setInt(@Nonnull final Field field, @Nonnull final Object obj, final int value) {
        try {
            field.setInt(obj, value);
        }
        catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
    
    static void setSendsVelocityUpdates(@Nonnull final Object obj) {
        try {
            NethercraftHandler.SENDS_VELOCITY_UPDATES_FIELD.setBoolean(obj, true);
        }
        catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
    
    @SubscribeEvent
    static void registerBiomes(@Nonnull final RegistryEvent.Register<Biome> event) {
        event.getRegistry().register((IForgeRegistryEntry)(NethercraftHandler.GLOWING_GROVE = new BiomeNethercraft()));
    }
    
    @SubscribeEvent
    static void generateOres(@Nonnull final DecorateBiomeEvent.Pre event) {
        if (event.getWorld().provider.getDimensionType() == DimensionType.NETHER) {
            NethercraftHandler.GLOWING_GROVE.decorator.chunkPos = event.getPos();
            NethercraftHandler.GLOWING_GROVE.decorator.genStandardOre1(event.getWorld(), event.getRand(), NethercraftHandler.foulitePerChunk, (WorldGenerator)new NetherGenMinable(BlocksNether.foulite_ore.getDefaultState(), NethercraftHandler.fouliteOreSize), NethercraftHandler.fouliteMinHeight, NethercraftHandler.fouliteMaxHeight << (event.getWorld().getActualHeight() >> 8));
            NethercraftHandler.GLOWING_GROVE.decorator.genStandardOre1(event.getWorld(), event.getRand(), NethercraftHandler.neridiumPerChunk, (WorldGenerator)new NetherGenMinable(BlocksNether.neridium_ore.getDefaultState(), NethercraftHandler.neridiumOreSize), NethercraftHandler.neridiumMinHeight, NethercraftHandler.neridiumMaxHeight << (event.getWorld().getActualHeight() >> 8));
            NethercraftHandler.GLOWING_GROVE.decorator.genStandardOre1(event.getWorld(), event.getRand(), NethercraftHandler.liniumPerChunk, (WorldGenerator)new NetherGenMinable(BlocksNether.linium_ore.getDefaultState(), NethercraftHandler.liniumOreSize), NethercraftHandler.liniumMinHeight, NethercraftHandler.liniumMaxHeight << (event.getWorld().getActualHeight() >> 8));
            NethercraftHandler.GLOWING_GROVE.decorator.genStandardOre1(event.getWorld(), event.getRand(), NethercraftHandler.pyridiumPerChunk, (WorldGenerator)new NetherGenMinable(BlocksNether.pyridium_ore.getDefaultState(), NethercraftHandler.pyridiumOreSize), NethercraftHandler.pyridiumMinHeight, NethercraftHandler.pyridiumMaxHeight << (event.getWorld().getActualHeight() >> 8));
            NethercraftHandler.GLOWING_GROVE.decorator.genStandardOre1(event.getWorld(), event.getRand(), NethercraftHandler.wPerChunk, (WorldGenerator)new NetherGenMinable(BlocksNether.w_ore.getDefaultState(), NethercraftHandler.wOreSize), NethercraftHandler.wMinHeight, NethercraftHandler.wMaxHeight << (event.getWorld().getActualHeight() >> 8));
        }
    }
    
    @SubscribeEvent(priority = EventPriority.LOW)
    static void summonDarkZombie(@Nonnull final ZombieEvent.SummonAidEvent event) {
        if (event.getResult() == Event.Result.DEFAULT && event.getSummonChance() > 0.0 && event.getWorld().provider.getDimensionType() == DimensionType.NETHER && event.getWorld().getDifficulty() == EnumDifficulty.HARD && event.getWorld().getGameRules().getBoolean("doMobSpawning")) {
            if (event.getSummoner().getRNG().nextDouble() > event.getSummonChance()) {
                event.setResult(Event.Result.DENY);
            }
            event.setCustomSummonedAid((EntityZombie)new EntityDarkZombie(event.getWorld()));
            event.setResult(Event.Result.ALLOW);
        }
    }
    
    static {
        TRACKING_RANGE_FIELD = ObfuscationReflectionHelper.findField((Class)EntityRegistry.EntityRegistration.class, "trackingRange");
        UPDATE_FREQUENCY_FIELD = ObfuscationReflectionHelper.findField((Class)EntityRegistry.EntityRegistration.class, "updateFrequency");
        SENDS_VELOCITY_UPDATES_FIELD = ObfuscationReflectionHelper.findField((Class)EntityRegistry.EntityRegistration.class, "sendsVelocityUpdates");
        NethercraftHandler.foulitePerChunk = 20;
        NethercraftHandler.fouliteOreSize = 14;
        NethercraftHandler.fouliteMinHeight = 10;
        NethercraftHandler.fouliteMaxHeight = 118;
        NethercraftHandler.neridiumPerChunk = 8;
        NethercraftHandler.neridiumOreSize = 14;
        NethercraftHandler.neridiumMinHeight = 10;
        NethercraftHandler.neridiumMaxHeight = 118;
        NethercraftHandler.liniumPerChunk = 5;
        NethercraftHandler.liniumOreSize = 4;
        NethercraftHandler.liniumMinHeight = 10;
        NethercraftHandler.liniumMaxHeight = 118;
        NethercraftHandler.pyridiumPerChunk = 4;
        NethercraftHandler.pyridiumOreSize = 6;
        NethercraftHandler.pyridiumMinHeight = 10;
        NethercraftHandler.pyridiumMaxHeight = 118;
        NethercraftHandler.wPerChunk = 2;
        NethercraftHandler.wOreSize = 4;
        NethercraftHandler.wMinHeight = 10;
        NethercraftHandler.wMaxHeight = 118;
    }
}
