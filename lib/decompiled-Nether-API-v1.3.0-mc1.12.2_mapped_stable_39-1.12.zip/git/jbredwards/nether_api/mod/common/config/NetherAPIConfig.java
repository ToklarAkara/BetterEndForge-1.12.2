package git.jbredwards.nether_api.mod.common.config;

import net.minecraftforge.fml.common.*;
import net.minecraftforge.fml.client.event.*;
import javax.annotation.*;
import net.minecraftforge.common.config.*;
import net.minecraftforge.fml.common.eventhandler.*;

@Config(modid = "nether_api", name = "nether_api/vanilla")
@Mod.EventBusSubscriber(modid = "nether_api")
public final class NetherAPIConfig
{
    @Config.LangKey("config.nether_api.endCaves")
    public static boolean endCaves;
    @Config.LangKey("config.nether_api.hellCaves")
    public static boolean hellCaves;
    @Deprecated
    @Config.RequiresWorldRestart
    @Config.LangKey("config.nether_api.tallNether")
    public static boolean tallNether;
    @Config.RequiresWorldRestart
    @Config.LangKey("config.nether_api.endWeight")
    public static int endWeight;
    @Config.RequiresWorldRestart
    @Config.LangKey("config.nether_api.hellWeight")
    public static int hellWeight;
    
    @SubscribeEvent
    static void sync(@Nonnull final ConfigChangedEvent.OnConfigChangedEvent event) {
        if (event.getModID().equals("nether_api")) {
            ConfigManager.sync("nether_api", Config.Type.INSTANCE);
        }
    }
    
    static {
        NetherAPIConfig.endCaves = true;
        NetherAPIConfig.hellCaves = true;
        NetherAPIConfig.tallNether = false;
        NetherAPIConfig.endWeight = 100;
        NetherAPIConfig.hellWeight = 8;
    }
    
    @Config(modid = "nether_api", name = "nether_api/biomes_o_plenty")
    public static final class BOP
    {
        @Config.RequiresWorldRestart
        @Config.LangKey("config.nether_api.compat.bop.dependentHellBiomes")
        public static boolean dependentBOPHellBiomes;
        
        static {
            BOP.dependentBOPHellBiomes = true;
        }
    }
    
    @Config(modid = "nether_api", name = "nether_api/journey_into_the_light")
    public static final class JITL
    {
        @Config.RequiresWorldRestart
        @Config.LangKey("config.nether_api.compat.jitl.bloodForestWeight")
        public static int bloodForestWeight;
        @Config.RequiresWorldRestart
        @Config.LangKey("config.nether_api.compat.jitl.earthenSeepWeight")
        public static int earthenSeepWeight;
        @Config.RequiresWorldRestart
        @Config.LangKey("config.nether_api.compat.jitl.heatSandsWeight")
        public static int heatSandsWeight;
        
        static {
            JITL.bloodForestWeight = 8;
            JITL.earthenSeepWeight = 5;
            JITL.heatSandsWeight = 6;
        }
    }
    
    @Config(modid = "nether_api", name = "nether_api/nethercraft")
    public static final class Nethercraft
    {
        @Config.RequiresWorldRestart
        @Config.LangKey("config.nether_api.compat.nethercraft.glowingGroveWeight")
        public static int glowingGroveWeight;
        
        static {
            Nethercraft.glowingGroveWeight = 4;
        }
    }
    
    @Config(modid = "nether_api", name = "nether_api/stygian_end")
    public static final class StygianEnd
    {
        @Config.RequiresWorldRestart
        @Config.LangKey("config.nether_api.compat.stygian_end.endVolcanoWeight")
        public static int endVolcanoWeight;
        @Config.LangKey("config.nether_api.compat.stygian_end.endVolcanoChorusPlants")
        public static boolean endVolcanoChorusPlants;
        @Config.LangKey("config.nether_api.compat.stygian_end.endVolcanoEndCity")
        public static boolean endVolcanoEndCity;
        @Config.RequiresWorldRestart
        @Config.LangKey("config.nether_api.compat.stygian_end.endJungleWeight")
        public static int endJungleWeight;
        @Config.LangKey("config.nether_api.compat.stygian_end.endJungleChorusPlants")
        public static boolean endJungleChorusPlants;
        @Config.LangKey("config.nether_api.compat.stygian_end.endJungleEndCity")
        public static boolean endJungleEndCity;
        @Config.RequiresMcRestart
        @Config.LangKey("config.nether_api.compat.stygian_end.wideEnderCanopyGen")
        public static boolean wideEnderCanopyGen;
        
        static {
            StygianEnd.endVolcanoWeight = 100;
            StygianEnd.endVolcanoChorusPlants = false;
            StygianEnd.endVolcanoEndCity = false;
            StygianEnd.endJungleWeight = 100;
            StygianEnd.endJungleChorusPlants = false;
            StygianEnd.endJungleEndCity = false;
            StygianEnd.wideEnderCanopyGen = false;
        }
    }
}
