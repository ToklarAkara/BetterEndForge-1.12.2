package git.jbredwards.nether_api.mod.common;

import net.minecraftforge.fml.common.*;
import git.jbredwards.nether_api.api.event.*;
import javax.annotation.*;
import git.jbredwards.nether_api.mod.*;
import git.jbredwards.nether_api.mod.common.compat.stygian_end.*;
import net.minecraft.init.*;
import git.jbredwards.nether_api.mod.common.config.*;
import net.minecraftforge.fml.common.eventhandler.*;
import git.jbredwards.nether_api.mod.common.compat.betternether.*;
import git.jbredwards.nether_api.mod.common.compat.biomesoplenty.*;
import git.jbredwards.nether_api.mod.common.compat.journey_into_the_light.*;
import git.jbredwards.nether_api.mod.common.compat.nethercraft.*;
import git.jbredwards.nether_api.mod.common.compat.netherex.*;
import net.minecraftforge.event.entity.living.*;
import net.minecraft.entity.boss.*;
import net.minecraft.block.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;

@Mod.EventBusSubscriber(modid = "nether_api")
final class EventHandler
{
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    static void registerHardcodedEnd(@Nonnull final NetherAPIRegistryEvent.End event) {
        if (NetherAPI.isStygianEndLoaded) {
            StygianEndHandler.registerBiomes(event.registry);
        }
        event.registry.registerBiome(Biomes.SKY, NetherAPIConfig.endWeight);
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    static void registerHardcodedNether(@Nonnull final NetherAPIRegistryEvent.Nether event) {
        if (NetherAPI.isBetterNetherLoaded) {
            BetterNetherHandler.registerBiomes(event.registry);
        }
        if (NetherAPI.isBiomesOPlentyLoaded) {
            BiomesOPlentyHandler.registerBiomes(event.registry, event.world);
        }
        if (NetherAPI.isJourneyIntoTheLightLoaded) {
            JITLHandler.registerBiomes(event.registry);
        }
        if (NetherAPI.isNethercraftLoaded) {
            NethercraftHandler.registerBiomes(event.registry);
        }
        if (NetherAPI.isNetherExLoaded) {
            NetherExHandler.registerBiomes(event.registry);
        }
        event.registry.registerBiome(Biomes.HELL, NetherAPIConfig.hellWeight);
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    static void handleDragonResistantBlocks(@Nonnull final LivingDestroyBlockEvent event) {
        if (event.getEntity() instanceof EntityDragon) {
            if (event.getState().getBlock() instanceof BlockTorch) {
                event.setCanceled(true);
            }
            else {
                final World world = event.getEntity().getEntityWorld();
                final BlockPos pos = event.getPos();
                final Explosion explosion = new Explosion(world, event.getEntity(), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 0.5f, false, true);
                if (event.getEntity().getExplosionResistance(explosion, world, pos, event.getState()) >= 1200.0f) {
                    event.setCanceled(true);
                }
            }
        }
    }
}
